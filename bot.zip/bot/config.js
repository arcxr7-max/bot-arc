module.exports = {
    botName: '𝗔𝗥𝗖𝗘𝗡',
    version: '2.5.0',
    owner: '59271169474674',

    defaultPrefix: '.',
    prefix: '.',

    allowedGroups: [],

    messages: {
        error: '❌ حدث خطأ أثناء تنفيذ الأمر',
        noPermission: 'ليس لديك صلاحية لاستخدام هذا الأمر',
        groupOnly: 'هذا الأمر متاح فقط في المجموعات',
        ownerOnly: 'هذا الأمر متاح فقط للنخبة',
        notAllowedGroup: 'عذراً، البوت لا يعمل في هذه المجموعة'
    },

    colors: {
        success: '\\x1b[32m',
        error: '\\x1b[31m',
        info: '\\x1b[36m',
        warn: '\\x1b[33m',
        reset: '\\x1b[0m'
    }
};