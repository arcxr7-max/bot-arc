const { loadPlugins } = require('./plugins');
const config = require('../config');
const logger = require('../utils/console');
const fs = require('fs-extra');
const path = require('path');
const { isElite } = require('../haykala/elite');
const { playSound } = require('../main');

const commands = new Map();
let allPlugins = null;
let originalSend = null;

// مسارات الملفات الهامة
const pointsFile = path.join(__dirname, '../data/points.json');
const botPath = path.join(__dirname, '../data/bot.txt');
const modePath = path.join(__dirname, '../data/mode.txt');
const repliesPath = path.join(__dirname, '../database/customReplies.json');


// ========== دوال النقاط ==========
function getPoints() {
    if (!fs.existsSync(pointsFile)) return {};
    return fs.readJsonSync(pointsFile);
}

function savePoints(points) {
    fs.writeJsonSync(pointsFile, points, { spaces: 2 });
}
// ==================================

// ========== دوال النظام البنكي ==========
const banksFile = path.join(__dirname, '../data/banks.json');
const accountsFile = path.join(__dirname, '../data/bankAccounts.json');

function loadBanks() {
    if (!fs.existsSync(banksFile)) {
        const defaultBanks = [
            { id: 1, name: 'بنك النقابة السوداء', emoji: '🖤' },
            { id: 2, name: 'بنك الهوكاغي', emoji: '🔥' },
            { id: 3, name: 'بنك القراصنة', emoji: '🏴‍☠️' },
            { id: 4, name: 'بنك السينين', emoji: '🌀' },
            { id: 5, name: 'بنك الأكاتسكي', emoji: '☁️' },
            { id: 6, name: 'بنك العمالقة', emoji: '⚔️' },
            { id: 7, name: 'بنك الساموراي', emoji: '🗡️' },
            { id: 8, name: 'بنك النينجا', emoji: '🥷' },
            { id: 9, name: 'بنك التنين', emoji: '🐉' },
            { id: 10, name: 'بنك الساحرات', emoji: '🧙‍♀️' }
        ];
        fs.writeJsonSync(banksFile, defaultBanks, { spaces: 2 });
        return defaultBanks;
    }
    return fs.readJsonSync(banksFile);
}

function loadAccounts() {
    if (!fs.existsSync(accountsFile)) return {};
    return fs.readJsonSync(accountsFile);
}

function saveAccounts(data) {
    fs.writeJsonSync(accountsFile, data, { spaces: 2 });
}

function generateAccountNumber() {
    return Math.floor(Math.random() * 9000000000) + 1000000000;
}

// ==========================================
// 🤖 نظام الذكاء الاصطناعي (من plugins/ai.js)
// ==========================================
const aiPlugin = require('../plugins/ai');

/**
 * دالة جلب الإضافات مع التخزين المؤقت
 */
async function getCachedPlugins() {
    if (!allPlugins) {
        allPlugins = await loadPlugins();
    }
    return allPlugins;
}

// التأكد من تهيئة المصفوفة العامة في الهاندلر أيضاً منعاً للأخطاء
global.disabledFormattingCmds = global.disabledFormattingCmds || [];

const disabledCmdsFile = path.join(process.cwd(), 'disabled_formats.json');

// دالة لجلب الأوامر المعطلة من ملف JSON لضمان الحفظ بعد إعادة التشغيل
function getDisabledCmds() {
    try {
        if (fs.existsSync(disabledCmdsFile)) {
            return JSON.parse(fs.readFileSync(disabledCmdsFile, 'utf8'));
        }
    } catch (e) {
        console.error("خطأ في قراءة ملف التنسيقات المعطلة:", e);
    }
    return [];
}

/**
 * دالة التنسيق الآلي للرسائل (إضافة النجوم وتنظيف النص)
 */
function applyArcFormatting(text, isCmdDisabled = false) {
    if (!text || typeof text !== 'string') return text;
    
    // 🔒 إذا كان الأمر معطلاً من نظام التحكم، أرسل النص فوراً بدون نجوم
    if (isCmdDisabled) return text;

    return text.split('\n').map(line => {
        let cleanLine = line.replace(/\*/g, '').trim();
        if (cleanLine.includes('http') || cleanLine.includes('www')) return line;
        if (cleanLine.length > 0) return `*${cleanLine}*`;
        return cleanLine;
    }).join('\n');
}

/**
 * تهيئة منسق الرسائل sendMessage بطريقة محمية ومربوطة بالـ JSON
 */
function initMessageFormatter(sock) {
    if (!sock || typeof sock.sendMessage !== 'function') return;
    if (sock.isFormatted) return; 

    const currentOriginalSend = sock.sendMessage.bind(sock);
    
    sock.sendMessage = async (jid, msg, options = {}) => {
        try {
            // جلب الأوامr المعطلة حالياً
            const disabledCmds = getDisabledCmds();
            
            // تحديد إذا كان الإرسال الحالي يحتوي على سياق أمر معطل
            let isCmdDisabled = options.noFormat || false;
            
            if (msg && (msg.text || msg.caption)) {
                const fullText = (msg.text || msg.caption).toLowerCase();
                // فحص إذا كان النص يحتوي على أي كلمة من الأوامر المعطلة
                const hasDisabledWord = disabledCmds.some(cmd => fullText.includes(cmd));
                if (hasDisabledWord) isCmdDisabled = true;
            }

            if (msg && msg.text) {
                msg.text = applyArcFormatting(msg.text, isCmdDisabled);
            }
            if (msg && msg.caption) {
                msg.caption = applyArcFormatting(msg.caption, isCmdDisabled);
            }
        } catch (err) {
            console.error("❌ خطأ أثناء تنسيق النص تلقائياً:", err);
        }
        
        return await currentOriginalSend(jid, msg, options);
    };
    sock.isFormatted = true;
    originalSend = currentOriginalSend;
}

/**
 * دالة تسجيل الأوامر (تستخدم في الإضافات)
 */
function cmd(options = {}) {
    if (!options.name || !options.exec) {
        throw new Error('يجب تحديد اسم الأمر ودالة التنفيذ');
    }
    commands.set(options.name.toLowerCase(), {
        name: options.name,
        exec: options.exec,
        description: options.description || '',
        usage: options.usage || '',
        category: options.category || 'عام',
        cooldown: options.cooldown || 0,
        owner: options.owner || false,
        group: options.group || false,
    });
}

/**
 * معالج الرسائل الرئيسي
 */
async function handleMessages(sock, { messages }) {    
    initMessageFormatter(sock); 
    
    try {
        const message = messages[0];
        if (!message || message.key.fromMe) return;

        // استخراج نص الرسالة
        const body = message.message?.conversation ||
            message.message?.extendedTextMessage?.text ||
            message.message?.imageMessage?.caption ||
            message.message?.videoMessage?.caption || '';

        if (!body) return;

        const from = message.key.remoteJid;
        if (!from.endsWith('@g.us')) return;
        const senderJid = message.key.participant || from;
        const senderNumber = senderJid.split('@')[0];

        // 🛡️ [ 1. فحص المستخدمين المحظورين
const blockFile = path.join(__dirname, '../data/blockedUsers.json');
function isBlocked(userJid) {
    if (!fs.existsSync(blockFile)) return false;
    const blocked = JSON.parse(fs.readFileSync(blockFile, 'utf8'));
    return blocked.includes(userJid);
}

// داخل handleMessages بعد const senderNumber
if (isBlocked(senderJid)) {
    return; // لا يستجيب للمستخدم المحظور
}

        // 🛡️ [ 2. مستمعات الألعاب الخارجية ] 🛡️
        if (typeof global.handleGuess === 'function') await global.handleGuess(sock, message);
        if (global.handleXO) await global.handleXO(sock, message, body);

        // 🛡️ [ 3. مستمع لعبة العين - نقاط ] 🛡️
        const gameEye = global.gameEye?.[from];
        if (gameEye && gameEye.current) {
            const userAnswer = body.trim().toLowerCase();
            const isNumber = !isNaN(userAnswer) && parseInt(userAnswer) >= 1 && parseInt(userAnswer) <= 4;
            const correctName = gameEye.current.answer;
            const selectedName = isNumber ? gameEye.current.opts[parseInt(userAnswer) - 1] : userAnswer;

            if (selectedName === correctName) {
                clearTimeout(gameEye.current.timer);
                let points = fs.existsSync(pointsFile) ? fs.readJsonSync(pointsFile) : {};
                points[senderNumber] = (points[senderNumber] || 0) + 500;
                fs.writeJsonSync(pointsFile, points, { spaces: 2 });
                gameEye.current = null;
                await sock.sendMessage(from, { text: `🎉 *إجابة صحيحة!* \n\n❁ الإجابة: *${correctName.toUpperCase()}*\n❁ الجائزة: *+500 نقاط* 💰\n❁ رصيدك الآن: *${points[senderNumber]}*\n\n╰─⟡ 𝗔𝗥𝗖𝗘𝗡` }, { quoted: message });
                return;
            }
        }

        // 🛡️ [ 4. مستمع لعبة العلم - نقاط ] 🛡️
        const flagGame = global.gameFlag?.[from];
        if (flagGame) {
            const userAnswer = body.trim().toLowerCase();
            if (userAnswer === flagGame.answer) {
                clearTimeout(flagGame.timeout);
                let points = fs.existsSync(pointsFile) ? fs.readJsonSync(pointsFile) : {};
                points[senderNumber] = (points[senderNumber] || 0) + 500;
                fs.writeJsonSync(pointsFile, points, { spaces: 2 });
                const correctAns = flagGame.answer;
                delete global.gameFlag[from];
                await sock.sendMessage(from, { image: { url: flagGame.img }, caption: `🎉 *إجابة صحيحة!* \n\n❁ الدولة: *${correctAns.toUpperCase()}*\n❁ الجائزة: *+500 نقاط* 💰\n❁ رصيدك الآن: *${points[senderNumber]}*` }, { quoted: message });
                return;
            }
        }

        // 🛡️ [ 5. مستمع لعبة عكس - ذكي ] 🛡️
        if (global.gameReverse && global.gameReverse[from]) {
            const session = global.gameReverse[from];
            const userAnswer = body.trim().toLowerCase();

            if (userAnswer === session.reverse) {
                clearTimeout(session.timer); // إيقاف الوقت
                
                // إضافة نقاط (500 نقطة)
                let points = fs.existsSync(pointsFile) ? fs.readJsonSync(pointsFile) : {};
                points[senderNumber] = (points[senderNumber] || 0) + 500;
                fs.writeJsonSync(pointsFile, points, { spaces: 2 });

                const successMsg = `✅ *إجابة صحيحة يا بطل!* \n\n❁ الكلمة: *${session.word}*\n❁ عكسها: *${session.reverse}*\n❁ الجائزة: *+500 نقاط* 💰\n\n╰─⟡ 𝗔𝗥𝗖𝗘𝗡`;
                
                delete global.gameReverse[from]; // إنهاء الجلسة
                return await sock.sendMessage(from, { text: successMsg }, { quoted: message });
            }
        }

        // 🛡️ [ 5. مستمع لعبة خمن الرقم - ذكي ] 🛡️
        if (global.gameNumber && global.gameNumber[senderJid]) {
            const session = global.gameNumber[senderJid];
            const userGuess = parseInt(body.trim());

            if (!isNaN(userGuess)) {
                if (userGuess === session.target) {
                    clearTimeout(session.timeout);
                    
                    // إضافة نقاط (500 نقطة)
                    let points = fs.existsSync(pointsFile) ? fs.readJsonSync(pointsFile) : {};
                    points[senderNumber] = (points[senderNumber] || 0) + 500;
                    fs.writeJsonSync(pointsFile, points, { spaces: 2 });

                    const winMsg = `🎯 *مبروووك! جـبـتـهـا صـح* \n\n❁ الرقم هو: *${session.target}*\n❁ الجائزة: *+500 نقاط* 💰\n❁ رصيدك الآن: *${points[senderNumber]}*\n\n╰─⟡ 𝗔𝗥𝗖𝗘𝗡`;
                    delete global.gameNumber[senderJid];
                    return await sock.sendMessage(from, { text: winMsg }, { quoted: message });

                } else if (userGuess < session.target) {
                    await sock.sendMessage(from, { text: `➕ *أكبر* (الرقم اللي في مخي أكبر من ${userGuess})` }, { quoted: message });
                } else if (userGuess > session.target) {
                    await sock.sendMessage(from, { text: `➖ *أصغر* (الرقم اللي في مخي أصغر من ${userGuess})` }, { quoted: message });
                }
                return; // لضمان عدم تداخل الإجابة مع أوامر أخرى
            }
        }
        
        // 🛡️ [ 6. مستمع لعبة خمن الإيموجي المطور ] 🛡️
        if (global.animeEmojiGame && global.animeEmojiGame[from]) {
            const session = global.animeEmojiGame[from];
            const userAnswer = body.trim().toLowerCase();

            if (userAnswer === session.answer) {
                clearTimeout(session.timer); // إيقاف الوقت فورا
                
                // إضافة 500 نقطة للفائز
                let points = fs.existsSync(pointsFile) ? fs.readJsonSync(pointsFile) : {};
                points[senderNumber] = (points[senderNumber] || 0) + 500;
                fs.writeJsonSync(pointsFile, points, { spaces: 2 });

                const winText = `
*🎉 إجابة صحيحة يا بطل!*

*👤 الفائز: @${senderNumber}ِ*
*🧩 الشخصية: ${session.response}*
*💰 الجائزة: +500 نقاط*
*🪙 رصيدك الحالي: ${points[senderNumber]}*
                `.trim();

                delete global.animeEmojiGame[from]; // إنهاء اللعبة بنجاح
                return await sock.sendMessage(from, { text: winText, mentions: [senderJid] }, { quoted: message });
            }
        }

        // 🛡️ [ 7. مراقبة مغادرة الأعضاء من القروب الأساسي
const guildsFile = path.join(__dirname, '../data/guilds.json');

sock.ev.on('group-participants.update', async (update) => {
    const { id, participants, action } = update;
    
    let guilds = {};
    if (fs.existsSync(guildsFile)) guilds = JSON.parse(fs.readFileSync(guildsFile, 'utf8'));
    
    // البحث عن النقابة المرتبطة بهذا القروب
    let targetGuildId = null;
    let targetGuild = null;
    
    for (const [guildId, guild] of Object.entries(guilds)) {
        if (guild.mainGroupId === id) {
            targetGuildId = guildId;
            targetGuild = guild;
            break;
        }
    }
    
    if (!targetGuild) return;
    
    if (action === 'remove') {
        let updated = false;
        for (const participant of participants) {
            const userNumber = participant.split('@')[0];
            if (targetGuild.titles && targetGuild.titles[userNumber]) {
                delete targetGuild.titles[userNumber];
                updated = true;
            }
        }
        
        if (updated) {
            guilds[targetGuildId] = targetGuild;
            fs.writeFileSync(guildsFile, JSON.stringify(guilds, null, 2));
            
            // تحديث وصف قروب الاستقبال
            const ARABIC_LETTERS = ['ا', 'ب', 'ت', 'ث', 'ج', 'ح', 'خ', 'د', 'ذ', 'ر', 'ز', 'س', 'ش', 'ص', 'ض', 'ط', 'ظ', 'ع', 'غ', 'ف', 'ق', 'ك', 'ل', 'م', 'ن', 'ه', 'و', 'ي'];
            const titles = targetGuild.titles || {};
            const takenCount = Object.keys(titles).length;
            
            let description = `عـدد الـقـاب مـؤخـودة ⊰• ${takenCount} •⊱\n`;
            description += `ـ✢ ⊱┄ ┅━ • ${targetGuild.welcomeGroupName}┆⬪雷 • ━┅ ┈⊰ ✢\n`;
            
            for (const letter of ARABIC_LETTERS) {
                const userWithThisLetter = Object.entries(titles).find(([id, data]) => data.letter === letter);
                if (userWithThisLetter) {
                    description += `ـ• *⊰ ${letter} ⊱* ـ @${userWithThisLetter[0]}\nـ「」\n`;
                } else {
                    description += `ـ• *⊰ ${letter} ⊱*\nـ「」\n`;
                }
            }
            
            description += `ـ✢ ⊱┄ ┅━ • ┆⬪雷 • ━┅ ┈⊰ ✢\n`;
            description += `ـ◝⚜️┆• ${targetGuild.welcomeGroupName} •┆⚜️◟ـ`;
            
            try {
                await sock.groupUpdateDescription(targetGuild.welcomeGroupId, description);
            } catch (e) {}
        }
    }
});

        // 🛡️ [ 8. لعبة اكتب كلمة
if (global.writingGames && global.writingGames[senderNumber]) {
    const game = global.writingGames[senderNumber];
    const userWord = body.trim();
    const firstLetter = userWord.charAt(0);

    if (firstLetter === game.letter) {
        let points = getPoints();
        points[senderNumber] = (points[senderNumber] || 0) + 30;
        savePoints(points);
        delete global.writingGames[senderNumber];
        await sock.sendMessage(from, { text: `🎉 *إجابة صحيحة!*\nكلمة: ${userWord}\n💰 ربحت +30 نقطة\n💰 رصيدك: ${points[senderNumber]} نقطة` }, { quoted: message });
    } else {
        await sock.sendMessage(from, { text: `❌ خطأ! الكلمة يجب أن تبدأ بحرف ${game.letter}` }, { quoted: message });
        delete global.writingGames[senderNumber];
    }
    return;
}

        // 🛡️ [ 9. لعبة زنقة (أكمل المتسلسلة)
if (global.numberGames && global.numberGames[senderNumber]) {
    const game = global.numberGames[senderNumber];
    const answer = parseInt(body.trim());

    if (!isNaN(answer) && answer === game.nextNumber) {
        let points = getPoints();
        points[senderNumber] = (points[senderNumber] || 0) + 40;
        savePoints(points);
        delete global.numberGames[senderNumber];
        await sock.sendMessage(from, { text: `🎉 *إجابة صحيحة!*\n💰 ربحت +40 نقطة\n💰 رصيدك: ${points[senderNumber]} نقطة` }, { quoted: message });
    } else if (!isNaN(answer)) {
        await sock.sendMessage(from, { text: `❌ خطأ! الإجابة الصحيحة: ${game.nextNumber}` }, { quoted: message });
        delete global.numberGames[senderNumber];
    }
    return;
}

        // 🛡️ [ 9. لعبة ذاكرة
if (global.memoryGames && global.memoryGames[senderNumber]) {
    const game = global.memoryGames[senderNumber];
    const answer = parseInt(body.trim());

    if (!isNaN(answer) && answer === game.secretNumber) {
        let points = getPoints();
        points[senderNumber] = (points[senderNumber] || 0) + 100;
        savePoints(points);
        delete global.memoryGames[senderNumber];
        await sock.sendMessage(from, { text: `🎉 *إجابة صحيحة!*\n💰 ربحت +100 نقطة\n💰 رصيدك: ${points[senderNumber]} نقطة` }, { quoted: message });
    } else if (!isNaN(answer)) {
        await sock.sendMessage(from, { text: `❌ خطأ! الرقم كان: ${game.secretNumber}` }, { quoted: message });
        delete global.memoryGames[senderNumber];
    }
    return;
}

        // 🛡️ [ 10. لعبة الرياضيات ] 🛡️
if (global.mathGames && global.mathGames[senderNumber] && global.mathGames[senderNumber].active) {
    const userAnswer = parseInt(body.trim());
    const game = global.mathGames[senderNumber];
    
    // ✅ التأكد من أن الإجابة رقم صحيح
    if (!isNaN(userAnswer)) {
        if (userAnswer === game.answer) {
            let points = getPoints();
            points[senderNumber] = (points[senderNumber] || 0) + 30;
            savePoints(points);
            
            await sock.sendMessage(from, {
                text: `🎉 *إجابة صحيحة!*\n💰 ربحت +30 نقطة\n💰 رصيدك: ${points[senderNumber]} نقطة`
            }, { quoted: message });
            delete global.mathGames[senderNumber];
        } else {
            await sock.sendMessage(from, {
                text: `❌ *إجابة خاطئة!*\nالجواب الصحيح: ${game.answer}\nحاول مرة أخرى بـ .رياضيات`
            }, { quoted: message });
            delete global.mathGames[senderNumber];
        }
        return;
    }
}

        // 🛡️ [ 11.. مستمع الردود المخصصة من قاعدة البيانات ] 🛡️
        if (fs.existsSync(repliesPath)) {
            const customGroups = fs.readJsonSync(repliesPath);
            if (Array.isArray(customGroups)) {
                const userText = body.trim().toLowerCase();
                const foundGroup = customGroups.find(g => g.keywords.includes(userText));
                
                if (foundGroup) {
                    // 1️⃣ [فحص قفل الخاص]: إذا كان الشات خاص والخاص مقفل، يتجاهل الرد
                    const configPath = path.join(process.cwd(), 'data', 'private_config.json');
                    if (from.endsWith('@s.whatsapp.net') && fs.existsSync(configPath)) {
                        const privateConfig = fs.readJsonSync(configPath);
                        if (privateConfig.locked) return; // خروج صامت
                    }

                    // 2️⃣ [فحص وضع النخبة]: إذا كان وضع النخبة شغال والمرسل ليس نخبة، يتجاهل الرد
                    let eliteMode = false;
                    if (fs.existsSync(modePath)) eliteMode = fs.readFileSync(modePath, 'utf8').trim() === '[on]';
                    if (eliteMode && !isElite(senderNumber)) return; // خروج صامت

                    // 3️⃣ [فحص حالة البوت العام]: إذا كان البوت مقفل [off]، يتجاهل الرد
                    let botStatus = '[on]';
                    if (fs.existsSync(botPath)) botStatus = fs.readFileSync(botPath, 'utf8').trim();
                    if (botStatus === '[off]') return; // خروج صامت

                    // إذا مرت الرسالة من كل الفحوصات السابقة بنجاح، يتم إرسال الرد المخصص
                    const finalReply = foundGroup.replies[Math.floor(Math.random() * foundGroup.replies.length)];
                    return await sock.sendMessage(from, { text: finalReply }, { quoted: message });
                }
            }
        }

        // 🛡️ [ 12.. معالج إنشاء الحساب البنكي ] 🛡️
        if (global.waitingForBank && global.waitingForBank[senderNumber]) {
            const waiting = global.waitingForBank[senderNumber];
            
            if (waiting.step === 'waiting_bank') {
                const userInput = body.trim();
                const bankIndex = parseInt(userInput) - 1;
                const currentBanks = loadBanks();
                
                if (isNaN(bankIndex) || bankIndex < 0 || bankIndex >= currentBanks.length) {
                    await sock.sendMessage(from, { text: '❌ رقم غير صحيح. أعد استخدام .انشاء' }, { quoted: message });
                    delete global.waitingForBank[senderNumber];
                    return;
                }
                
                const selectedBank = currentBanks[bankIndex];
                const accountNumber = generateAccountNumber();
                
                let points = fs.existsSync(pointsFile) ? fs.readJsonSync(pointsFile) : {};
                let accounts = loadAccounts();
                
                accounts[senderNumber] = {
                    accountNumber: accountNumber,
                    bankId: selectedBank.id,
                    bankName: selectedBank.name,
                    bankEmoji: selectedBank.emoji,
                    createdAt: new Date().toISOString()
                };
                
                if (!points[senderNumber]) points[senderNumber] = 0;
                saveAccounts(accounts);
                fs.writeJsonSync(pointsFile, points, { spaces: 2 });
                
                await sock.sendMessage(from, {
                    text: `✅ *تم إنشاء حسابك بنجاح!*\n\n🏦 البنك: ${selectedBank.emoji} ${selectedBank.name}\n🔢 رقم الحساب: *${accountNumber}*\n💰 الرصيد الحالي: ${points[senderNumber]} نقطة\n\nاستخدم .بنكي لعرض أوامر البنك`
                }, { quoted: message });
                
                try {
                    await sock.sendMessage(from, { delete: { remoteJid: from, id: waiting.msgId, fromMe: true } });
                } catch(e) {}
                
                delete global.waitingForBank[senderNumber];
                return;
            }
        }

        // 🛡️ [ 13.. أمر الذكاء الاصطناعي (ارك) ] 🛡️
        
        if (body.startsWith('.ارك')) {
            const text = body.slice(4).trim();
            
            if (!text) {
                return sock.sendMessage(from, { 
                    text: `_💙 ~ حط نص جنب الأمر ~ ❤️_` 
                }, { quoted: message });
            }
            
            // 🛡️ أمر مسح الذاكرة (للمطورين والنخبة فقط)
            if (text.toLowerCase() === 'مسح') {
                // التحقق من الصلاحيات
                const isDev = require('../devs').isDev(senderNumber);
                const isElite = require('../haykala/elite').isElite(senderNumber);
                
                if (!isDev && !isElite) {
                    return sock.sendMessage(from, { 
                        text: `🚫 *غير مسموح*

هذا الأمر مخصص للمطورين والنخبة فقط.` 
                    }, { quoted: message });
                }
                
                aiPlugin.clearHistory(senderNumber);
                return sock.sendMessage(from, { 
                    text: `🗑️ *تم مسح ذاكرتي* 
        
لقد نسيت كل شيء، يمكنك البدء من جديد ✨` 
                }, { quoted: message });
            }
            
            await sock.sendPresenceUpdate('composing', from);
            
            const result = await aiPlugin.AiChat({ 
                text: text, 
                senderId: senderNumber 
            });
            
            await sock.sendMessage(from, { 
                text: `${result}\n╰─⟡ 𝗔𝗥𝗖𝗘𝗡` 
            }, { quoted: message });
            return;
        }

        // 🛡️ [ 14.. معالجة الأوامر بالبادئة Prefix ] 🛡️
        const currentPrefix = config.prefix;
        if (!body.toLowerCase().startsWith(currentPrefix.toLowerCase())) return;

        const parts = body.slice(currentPrefix.length).trim().split(/\s+/);
        const commandName = parts[0]?.toLowerCase();
        const args = parts.slice(1);
        if (!commandName) return;

        // فحص حالة البوت (on/off)
        let botStatus = '[on]';
        if (fs.existsSync(botPath)) botStatus = fs.readFileSync(botPath, 'utf8').trim();
        if (botStatus === '[off]' && commandName !== 'bot') {
            return;
        }

        // فحص وضع النخبة (mode.txt)
        let eliteMode = false;
        if (fs.existsSync(modePath)) eliteMode = fs.readFileSync(modePath, 'utf8').trim() === '[on]';
        if (eliteMode && !isElite(senderNumber)) return;

        const plugins = await getCachedPlugins();
        const handler = plugins[commandName];

        if (handler) {
            // 🌟 [ تحديث الحالة: يكتب أو يسجل ] 🌟
            const audioCmds = ['y', 'mp3', 'صوت', 'اغنية', 'أغنية'];
            const isAudio = audioCmds.includes(commandName) || (handler.category === 'audio');
            await sock.sendPresenceUpdate(isAudio ? 'recording' : 'composing', from);

            // 🚀 [ اللوجر المطور ]
            const isEliteUser = await isElite(senderJid);
            logger.info(`Command: ${commandName} | From: ${senderNumber} | Elite: ${isEliteUser ? 'Yes' : 'No'}`);

            message.args = args;
            message.command = commandName;
            message.prefix = currentPrefix;

            // تحققات الصلاحيات
            if (handler.elite && !config.owners.includes(senderNumber)) {
                await sock.sendMessage(from, { text: config.messages.ownerOnly });
                return;
            }
            if (handler.group && !from.endsWith('@g.us')) {
                await sock.sendMessage(from, { text: config.messages.groupOnly });
                return;
            }

            // تنفيذ الأمر
            if (typeof handler === 'function') {
                await handler(sock, message);
            } else if (typeof handler.execute === 'function') {
                await handler.execute(sock, message);
            }
            
            logger.success(`تم تنفيذ الأمر: ${commandName}`);
        }

    } catch (error) {
        logger.error(`✗ خطأ في الهاندلر: ${error.stack}`);
        playSound('ERROR');
    }
}

/**
 * تنفيذ أمر يدوي (للتوافق)
 */
async function handleCommand(sock, msg, command, args) {
    const cmdData = commands.get(command.toLowerCase());
    if (!cmdData) return;
    try {
        if (cmdData.owner && !config.owners.includes(msg.sender)) return;
        await cmdData.exec(sock, msg, args);
    } catch (error) {
        logger.error(`✗ خطأ في تنفيذ الأمر ${command}:`, error);
        playSound('ERROR');
    }
}

/**
 * منشئ معالج الإضافات
 */
function createPluginHandler(options = {}) {
    const pluginHandler = options.execute || (() => {});
    pluginHandler.elite = options.elite || false;
    pluginHandler.group = options.group || false;
    pluginHandler.desc = options.desc || 'لا يوجد وصف';
    pluginHandler.command = options.command || options.name || 'غير محدد';
    return pluginHandler;
}

function handleMessagesLoader() {
    logger.info("✅ 𝙄𝙣𝙞𝙩𝙞𝙖𝙡𝙞𝙯𝙚𝙙 𝙨𝙪𝙘𝙘𝙚𝙨𝙨𝙛𝙪𝙡𝙡𝙮");
}

module.exports = {
    handleMessages,
    handleCommand,
    cmd,
    commands,
    createPluginHandler,
    handleMessagesLoader
};