const { fork } = require('child_process');
const { join } = require('path');
const fs = require('fs-extra');
const logger = require('./utils/console');

const maxRetries = 3;
const retryDelay = 5000;

let isRunning = false;
let retryCount = 0;

function handleConnection(retry = 0) {
    const currentPath = process.cwd();
    const connectionFolder = join(currentPath, 'ملف_الاتصال');

    if (!fs.existsSync(connectionFolder)) {
        logger.warn('⚠️ 𝚂𝚎𝚜𝚜𝚒𝚘𝚗 𝚏𝚒𝚕𝚎 𝚖𝚒𝚜𝚜𝚒𝚗𝚐, 𝚙𝚛𝚘𝚌𝚎𝚎𝚍𝚒𝚗𝚐 𝚊𝚗𝚢𝚠𝚊𝚢...');
    }

    if (isRunning) return;
    isRunning = true;
    logger.info('🚀 𝙻𝚘𝚊𝚍𝚒𝚗𝚐 𝙱𝚘𝚝...');

    const child = fork(join(__dirname, 'main.js'), [], {
        stdio: ['inherit', 'inherit', 'inherit', 'ipc'],
        env: {
            ...process.env,
            CONNECTION_FOLDER: connectionFolder
        }
    });

    child.on('message', (data) => {
        if (data === 'ready') {
            retryCount = 0;
            logger.success('✅ 𝘽𝙤𝙩 𝙞𝙨 𝙣𝙤𝙬 𝙤𝙣𝙡𝙞𝙣𝙚!');
        } else if (data === 'reset') {
            logger.warn('🔄 𝘽𝙤𝙩 𝙧𝙚𝙨𝙩𝙖𝙧𝙩𝙞𝙣𝙜...');
            child.kill();
            setTimeout(() => handleConnection(0), 2000);
        } else if (data === 'uptime') {
            child.send(process.uptime());
        }
    });

    child.on('exit', async (code) => {
        isRunning = false;

        if (code === 0) {
            logger.info('✅ 𝘽𝙤𝙩 𝙨𝙩𝙤𝙥𝙥𝙚𝙙 𝙨𝙪𝙘𝙘𝙚𝙨𝙨𝙛𝙪𝙡𝙡𝙮.');
            return;
        }

        if (code === 429) {
            logger.warn('⚠️ 𝚁𝚎𝚚𝚞𝚎𝚜𝚝 𝚕𝚒𝚖𝚒𝚝 𝚛𝚎𝚊𝚌𝚑𝚎𝚍, 𝚠𝚊𝚒𝚝 𝟷𝟶𝚜...');
            await delay(10000);
            return handleConnection(retry);
        }

        if (retry < maxRetries) {
            retry++;
            logger.warn(`⚠️ 𝙍𝙚𝙨𝙩𝙖𝙧𝙩𝙞𝙣𝙜 (${retry}/${maxRetries}) 𝙞𝙣 ${retryDelay / 1000} 𝙨𝙚𝙘𝙤𝙣𝙙𝙨...`);
            await delay(retryDelay);
            handleConnection(retry);
        } else {
            logger.error('❌ 𝙼𝚊𝚡𝚒𝚖𝚞𝚖 𝚛𝚎𝚝𝚛𝚒𝚎𝚜 𝚛𝚎𝚊𝚌𝚑𝚎𝚍. 𝚂𝚝𝚘𝚙𝚙𝚒𝚗𝚐...');
            process.exit(1);
        }
    });

    child.on('error', (err) => {
        isRunning = false;
        logger.error(`❌ 𝚂𝚞𝚋𝚙𝚛𝚘𝚌𝚎𝚜𝚜 𝚎𝚛𝚛𝚘𝚛: ${err}`);
        if (retry < maxRetries) {
            retry++;
            setTimeout(() => handleConnection(retry), retryDelay);
        }
    });

    
    setTimeout(() => {
        if (!child.connected) {
            logger.error('❌ 𝙲𝚘𝚗𝚗𝚎𝚌𝚝𝚒𝚘𝚗 𝚝𝚘 𝚋𝚘𝚝 𝚝𝚒𝚖𝚎𝚍 𝚘𝚞𝚝 (𝟷𝟶𝚜)');
            child.kill();
            handleConnection(retry + 1);
        }
    }, 10000);
}

function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}


process.on('SIGINT', () => process.exit());

process.on('uncaughtException', (err) => {
    if (err.code === 'ECONNRESET' || err.code === 'rate-overlimit') {
        logger.warn('⚠️ 𝙵𝚊𝚖𝚒𝚕𝚒𝚊𝚛 𝚎𝚛𝚛𝚘𝚛 𝚜𝚔𝚒𝚙𝚙𝚎𝚍.');
        return;
    }
    logger.error('❌ 𝙴𝚛𝚛𝚘𝚛 𝚗𝚘𝚝 𝚑𝚊𝚗𝚍𝚕𝚎𝚍:', err);
});

process.on('unhandledRejection', (reason) => {
    if (reason?.code === 429) {
        logger.warn('⚠️ 𝚁𝚊𝚝𝚎 𝚕𝚒𝚖𝚒𝚝 𝚑𝚒𝚝, 𝚠𝚊𝚒𝚝𝚒𝚗𝚐...');
        return;
    }
    logger.error('❌ 𝚄𝚗𝚑𝚊𝚗𝚍𝚕𝚎𝚍 𝚙𝚛𝚘𝚖𝚒𝚜𝚎:', reason);
});

logger.info('📦 𝙸𝚗𝚒𝚝𝚒𝚊𝚕𝚒𝚣𝚒𝚗𝚐...');
handleConnection();