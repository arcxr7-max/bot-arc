const { default: makeWASocket, useMultiFileAuthState, DisconnectReason } = require('@whiskeysockets/baileys');
const fs = require('fs-extra');
const pino = require('pino');
const path = require('path');
const chalk = require('chalk');
const readline = require('readline');
const { exec } = require('child_process');
const logger = require('./utils/console');

const question = text => new Promise(resolve => {
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });
    rl.question(text, answer => {
        rl.close();
        resolve(answer);
    });
});

const asciiArt = `
${chalk.hex('#FF4500')(' █████╗ ██████╗  ██████╗███████╗███╗   ██╗')}
${chalk.hex('#FF4500')('██╔══██╗██╔══██╗██╔════╝██╔════╝████╗  ██║')}
${chalk.hex('#FF4500')('███████║██████╔╝██║     █████╗  ██╔██╗ ██║')}
${chalk.hex('#FF4500')('██╔══██║██╔══██╗██║     ██╔══╝  ██║╚██╗██║')}
${chalk.hex('#FF4500')('██║  ██║██║  ██║╚██████╗███████╗██║ ╚████║')}
${chalk.hex('#FF4500')('╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚══════╝╚═╝  ╚═══╝')}
`;

console.log(asciiArt);


function playSound(name) {
    const controlPath = path.join(__dirname, 'sounds', 'sound.txt');
    const status = fs.existsSync(controlPath) ? fs.readFileSync(controlPath, 'utf-8').trim() : 'off';
    if (status !== '{on}') return;
    const filePath = path.join(__dirname, 'sounds', name);
    if (fs.existsSync(filePath)) exec(`mpv --no-terminal --really-quiet "${filePath}"`);
}

async function startBot() {
    try {
        console.clear();
        console.log(asciiArt);
        console.log(chalk.hex('#FF4500').bold('\n   𝘼 𝙍 𝘾 𝙀 𝙉  𝙒 𝙀 𝙇 𝘾 𝙊 𝙈 𝙀 𝙎  𝙔 𝙊 𝙐\n'));

        playSound('ANASTASIA.mp3');

        const sessionDir = path.join(__dirname, 'ملف_الاتصال');
        await fs.ensureDir(sessionDir);

        const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

        const sock = makeWASocket({
            auth: state,
            printQRInTerminal: false,
            browser: ['MacOs', 'Chrome', '1.0.0'],
            logger: pino({ level: 'silent' }),
            markOnlineOnConnect: true,
            generateHighQualityLinkPreview: true
        });

        
        sock.ev.on('groups.upsert', async (groups) => {
            for (const group of groups) {
                try {
                    await sock.groupMetadata(group.id);
                    console.log(`[+] تم تحميل بيانات مجموعة: ${group.subject}`);
                } catch (err) {
                    console.warn(`[-] فشل في تحميل بيانات مجموعة: ${group.id}`);
                }
            }
        });

        if (!sock.authState.creds.registered) {
            console.log(chalk.bold('\n[ 𝑆𝐸𝑇𝑈𝑃 ] 𝑃𝑙𝑒𝑎𝑠𝑒 𝑒𝑛𝑡𝑒𝑟 𝑦𝑜𝑢𝑟 𝑝ℎ𝑜𝑛𝑒 𝑛𝑢𝑚𝑏𝑒𝑟 𝑡𝑜 𝑟𝑒𝑐𝑒𝑖𝑣𝑒 𝑡ℎ𝑒 𝑝𝑎𝑖𝑟𝑖𝑛𝑔 𝑐𝑜𝑑𝑒:'));
            console.log(chalk.dim('          (𝙿𝚛𝚎𝚜𝚜 "#" 𝚝𝚘 𝚌𝚊𝚗𝚌𝚎𝚕)\n'));

            let phoneNumber = await question(chalk.bgHex('#FFD700').black(' 𝗣𝗛𝗢𝗡𝗘 𝗡𝗨𝗠𝗕𝗘𝗥 : '));
            if (phoneNumber.trim() === '#') process.exit();

            phoneNumber = phoneNumber.replace(/[^0-9]/g, '');
            if (!phoneNumber.match(/^\d{10,15}$/)) {
                console.log("\n[ 𝑬𝑹𝑹𝑶𝑹 ] 𝑰𝒏𝒗𝒂𝒍𝒊𝒅 𝒑𝒉𝒐𝒏𝒆 𝒏𝒖𝒎𝒃𝒆𝒓.\n");
                process.exit(1);
            }

            try {
                const code = await sock.requestPairingCode(phoneNumber);
                console.log('\n────────── Pairing Information ──────────');
                console.log(`𝘗𝘢𝘪𝘳𝘪𝘯𝘨 𝘊𝘰𝘥𝘦: ${code}`);
                console.log(`𝘗𝘩𝘰𝘯𝘦 𝘕𝘶𝘮𝘣𝘦𝘳: ${phoneNumber}`);
                console.log('─────────────────────────────────────────\n');
            } catch (error) {
                console.log("\n[ 𝑬𝑹𝑹𝑶𝑹 ] 𝑭𝒂𝒊𝒍𝒆𝒅 𝒕𝒐 𝒈𝒆𝒕 𝒑𝒂𝒊𝒓𝒊𝒏𝒈 𝒄𝒐𝒅𝒆.\n");
                process.exit(1);
            }
        }

        sock.ev.on('connection.update', async (update) => {
            const { connection, lastDisconnect } = update;

            if (connection === 'connecting') {
                logger.info('𝘾𝙤𝙣𝙣𝙚𝙘𝙩𝙞𝙣𝙜 𝙩𝙤 𝙒𝙝𝙖𝙩𝙨𝘼𝙥𝙥...');
            }

            if (connection === 'open') {
                logger.success(`✅ 𝘾𝙤𝙣𝙣𝙚𝙘𝙩𝙚𝙙 𝙐𝙨𝙚𝙧: ${sock.user.id}`);

                try {
const { addEliteNumber } = require('./haykala/elite');
const botNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
await addEliteNumber(botNumber);
                } catch (e) {
                    logger.error('فشل في إضافة رقم البوت إلى النخبة:', e.message);
                }

                require('./handlers/handler').handleMessagesLoader();
                listenToConsole(sock);
            }

            if (connection === 'close') {
                const isLoggedOut = lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut;
                logger.warn(`Disconnected: ${lastDisconnect?.error?.message || 'Unknown reason'}`);

                if (isLoggedOut) {
                    playSound('LOGGOUT.mp3');
                    logger.error('You have been logged out.');
                    process.exit(1);
                } else {
                    logger.info('Reconnecting...');
                    setTimeout(startBot, 3000);
                }
            }
        });

        sock.ev.on('messages.upsert', async (m) => {
            try {
                const { handleMessages } = require('./handlers/handler');
                await handleMessages(sock, m);
            } catch (err) {
                logger.error('Error while handling message:', err);
                playSound('ERROR.mp3');
            }
        });

        sock.ev.on('creds.update', saveCreds);

    } catch (err) {
        logger.error('Startup error:', err);
        playSound('ERROR.mp3');
        setTimeout(startBot, 3000);
    }
}

function listenToConsole(sock) {
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });

    rl.on('line', (line) => {
        console.log('[ CMD ] Unknown command.');
    });
}

startBot();