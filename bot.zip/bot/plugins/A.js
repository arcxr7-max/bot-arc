const axios = require('axios');
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');

/* 🧠 نظام منع التكرار الذكي لضمان تنوع الإيديت */
const sentVideos = new Map();
const MAX_HISTORY = 100;

function rememberVideo(id) {
  sentVideos.set(id, Date.now());
  if (sentVideos.size > MAX_HISTORY) {
    const oldestKey = [...sentVideos.entries()]
      .sort((a, b) => a[1] - b[1])[0][0];
    sentVideos.delete(oldestKey);
  }
}

module.exports = {
    category: 'media',
  command: 'a', // الأمر المطلوب .a
    description: '🎬 يرسل فيديو إيديت (أنمي، كرة، مشاهير) بصيغة دائرية فخمة',
  usage: '.a [الموضوع]',

  async execute(sock, msg) {

            const chatId = msg.key.remoteJid;
    
    // استخراج النص بعد الأمر .a
    const body = msg.message?.extendedTextMessage?.text || msg.message?.conversation || '';
    const args = body.trim().split(/\s+/).slice(1);
    const query = args.join(' ');
    
    // إذا لم يكتب موضوع، يرسل إيديت أنمي عشوائي فخم
    // إذا كتب موضوع، يبحث عنه مع إضافة كلمات لضمان أنه "إيديت فخم"
    const searchText = query ? `${query} edit badass 4k` : 'anime edit badass cold moments 4k';

    // تفاعل البدء
    await sock.sendMessage(chatId, { react: { text: '🫧', key: msg.key } });

    /* 🔴 المصدر الأول: TikTok (الأفضل للإيديت) */
    try {
      const apiUrl = `https://www.tikwm.com/api/feed/search?keywords=${encodeURIComponent(searchText)}`;
      const { data } = await axios.get(apiUrl);

      if (data.code === 0 && data.data?.videos?.length) {
        // تصفية الفيديوهات لعدم التكرار
        const fresh = data.data.videos.filter(v => {
          const id = v.video_id || v.id || v.play;
          return id && !sentVideos.has(id);
        });

        const selected = fresh.length > 0 
          ? fresh[Math.floor(Math.random() * fresh.length)] 
          : data.data.videos[Math.floor(Math.random() * data.data.videos.length)];

        const vidId = selected.video_id || selected.id || selected.play;
        rememberVideo(vidId);

        return await sock.sendMessage(chatId, {
          video: { url: selected.play },
          mimetype: 'video/mp4',
          ptv: true, // إرسال كفيديو دائري
          caption: `> *🎬 ARC-SYSTEM EDITS* \n> _الهدف:_ *${query || 'عشوائي'}* \n> _النوع:_ *Badass PTV* ⦿`
        }, { quoted: msg });
      }
    } catch (err) {
      console.warn('⚠️ تيك توك لم يستجب، ننتقل للمصدر البديل..');
    }

    /* 🟡 المصدر الثاني: YouTube (الاحتياطي) */
    try {
      const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'arc-ptv-'));
      const outPath = path.join(tmpDir, 'result.mp4');
      
      // تحميل فيديو قصير (Short/Edit) من يوتيوب
      const command = `yt-dlp "ytsearch1:${searchText}" -f "mp4" -o "${outPath}" --quiet --no-warnings`;
      execSync(command);

      if (fs.existsSync(outPath)) {
        await sock.sendMessage(chatId, {
          video: fs.readFileSync(outPath),
          mimetype: 'video/mp4',
          ptv: true, // إرسال كفيديو دائري
        }, { quoted: msg });

        fs.rmSync(tmpDir, { recursive: true, force: true });
        return;
      }
    } catch (err) {
      console.error('❌ فشل النظام بالكامل:', err.message);
      await sock.sendMessage(chatId, {
        text: "*✖️ ┋ ARC-ERROR:* تعذر العثور على إيديت فخم لهذا الموضوع حالياً. ⦿",
        quoted: msg
      });
    }
  }
};