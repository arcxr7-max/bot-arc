// plugins/tools/qr.js
const axios = require('axios');

module.exports = {
  command: 'qr',
  category: 'tools',
  description: '📱 تحويل النص إلى كود QR',
  usage: '.qr [النص]',

  async execute(sock, msg, args) {
    const from = msg.key.remoteJid;
    
    // ✅ استخراج النص من الرسالة مباشرة
    let text = '';
    
    // 1️⃣ محاولة من args
    if (args && Array.isArray(args) && args.length > 0) {
      text = args.join(' ');
    }
    
    // 2️⃣ محاولة من body
    if (!text) {
      const body = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
      const parts = body.trim().split(/\s+/);
      if (parts.length > 1) {
        text = parts.slice(1).join(' ');
      }
    }

    if (!text) {
      return sock.sendMessage(from, {
        text: `📱 *طريقة الاستخدام:*\n.qr [النص]\n\nمثال: .qr https://wa.me/201028489465`
      }, { quoted: msg });
    }

    await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

    try {
      // ✅ API مجاني لإنشاء QR
      const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=${encodeURIComponent(text)}`;
      
      // ✅ تحميل الصورة
      const response = await axios.get(qrUrl, { responseType: 'arraybuffer' });
      const imageBuffer = Buffer.from(response.data, 'utf-8');

await sock.sendMessage(from, {
  image: imageBuffer
}, { quoted: msg });

      await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

    } catch (error) {
      console.error('❌ خطأ في QR:', error);
      await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
      await sock.sendMessage(from, {
        text: '❌ حدث خطأ أثناء إنشاء الكود.'
      }, { quoted: msg });
    }
  }
};