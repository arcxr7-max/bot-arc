const fs = require('fs');
const path = require('path');

module.exports = {
category: 'control',
command: ['add'],
description: 'إضافة أوامر جديدة للبوت عند منشن الرسالة وتحديث الذاكرة تلقائياً.',

async execute(sock, msg, args = []) {
// [ARCEN-SECURITY-START]
const senderNum = (msg.key.participant || msg.key.remoteJid).split('@')[0];
const { isDev } = require('../utils/devs');
if (!isDev(senderNum)) return sock.sendMessage(msg.key.remoteJid, { text: '⚠️ ┋ عذراً، هذا الأمر مخصص للمطور الأساسي فقط!' }, { quoted: msg });
// [ARCEN-SECURITY-END]

const quotedMessage = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;

if (!quotedMessage) {
return await sock.sendMessage(msg.key.remoteJid, {
text: '❌ يرجى منشن الرسالة التي تحتوي على الكود بعد كتابة ".add اسم".',
}, { quoted: msg });
}

let pluginCode = quotedMessage.conversation ||
quotedMessage.extendedTextMessage?.text ||
quotedMessage.imageMessage?.caption ||
quotedMessage.videoMessage?.caption || '';

pluginCode = pluginCode.trim();

if (!pluginCode) {
return await sock.sendMessage(msg.key.remoteJid, {
text: '❌ لم يتم العثور على أي كود في الرسالة المقتبسة لإضافته كأمر للبوت.',
}, { quoted: msg });
}

if (!pluginCode.includes('category')) {
pluginCode = pluginCode.replace(
'module.exports = {',
`module.exports = {\n  category: 'download',`
);
}

const fullText = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
let pluginFileName = '';
const parts = fullText.trim().split(/\s+/);

if (parts.length > 1) {
const rawName = parts.slice(1).join('-').replace(/[^a-zA-Z0-9-_أ-ي]/g, '');
pluginFileName = `${rawName}.js`;
} else {
const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
pluginFileName = `plugin_${timestamp}.js`;
}

const pluginsDir = path.resolve('./plugins');
const pluginFilePath = path.join(pluginsDir, pluginFileName);

try {
fs.writeFileSync(pluginFilePath, pluginCode, 'utf8');

// 🔄 [التحديث التلقائي الذكي للـ Cache]
try {
const files = fs.readdirSync(pluginsDir);
for (const file of files) {
if (file.endsWith('.js')) {
delete require.cache[require.resolve(path.join(pluginsDir, file))];
}
}
const handlerPath = path.join(__dirname, '../handlers/handler.js');
if (fs.existsSync(handlerPath)) delete require.cache[require.resolve(handlerPath)];
if (global.loadPlugins) await global.loadPlugins(true);
} catch (e) { console.error('خطأ أثناء التحديث التلقائي:', e); }

await sock.sendMessage(msg.key.remoteJid, {
text: `✔️ تم إنشاء البلجن وحفظه بنجاح باسم:\n📁 \`plugins/${pluginFileName}\`\n\n🔄 [نظام حركي]: تم إعادة تحميل الذاكرة وتفعيل الأمر الجديد تلقائياً حياً!`,
}, { quoted: msg });

} catch (error) {
console.error('خطأ أثناء كتابة البلجن:', error);
await sock.sendMessage(msg.key.remoteJid, {
text: '❌ حدث خطأ داخلي أثناء حفظ البلجن في السيرفر.',
}, { quoted: msg });
}
}
};