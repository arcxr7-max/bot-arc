// • Feature : تحميل تطبيقات الأندرويد APK مباشرة
// • Developers : ARCEN Team

module.exports = {
  command: ['apk'],
  description: 'تحميل تطبيقات الأندرويد بصيغة APK مباشرة.',
  category: 'media',

  async execute(sock, message, args) {
    const from = message.key.remoteJid;

    // جلب اسم التطبيق من الحجج (args) أو النص المصاحب
    let appName = args && args.length > 0 ? args.join(' ').trim() : '';
    if (!appName) {
      const msgText = message.message?.conversation || message.message?.extendedTextMessage?.text || '';
      appName = msgText.split(' ').slice(1).join(' ').trim();
    }

    // إذا لم يتم كتابة اسم التطبيق
    if (!appName) {
      return await sock.sendMessage(from, {
        text: `🤔 *ماذا تريد تحميله؟*\n- أدخل اسم التطبيق بعد الأمر.\n\n💡 *مثال:*\n.apk Free Fire`
      }, { quoted: message });
    }

    const apiUrl = `https://api-streamline.vercel.app/dlapk?search=${encodeURIComponent(appName)}`;

    try {
      // جلب البيانات باستخدام fetch المدمج في بيئة Node.js الحديثة
      const response = await fetch(apiUrl);
      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

      const data = await response.json();

      // التحقق من وجود التطبيق في نتيجة الـ API
      if (!data || !data.id || !data.file || !data.file.path) {
        return await sock.sendMessage(from, { text: '❌ لم يتم العثور على التطبيق المطلوب، تأكد من كتابة الاسم الصحيح.' }, { quoted: message });
      }

      let { name, file, icon } = data;

      // 1. إرسال أيقونة التطبيق كرسالة تمهيدية
      if (icon) {
        await sock.sendMessage(from, {
          image: { url: icon },
          caption: `📦 *جاري جلب ملف الـ APK لتطبيق: "${name}"...*\n\n⏳ انتظر ثواني لرفع الملف بالكامل.`
        }, { quoted: message });
      }

      // 2. إرسال ملف الـ APK الفعلي للمجموعة أو الخاص
      await sock.sendMessage(from, {
        document: { url: file.path },
        mimetype: 'application/vnd.android.package-archive',
        fileName: `${name}.apk`,
        caption: `✅ *تم تحميل وتجهيز التطبيق بنجاح*\n\n📦 *الاسم:* ${name}\n🔗 *المصدر:* Uptodown\n\n𝗔𝗥𝗖𝗘𝗡 🪶`
      }, { quoted: message });

    } catch (error) {
      console.error('Error fetching APK:', error);
      await sock.sendMessage(from, { 
        text: '❌ حدث خطأ غير متوقع أثناء محاولة تحميل التطبيق، قد يكون السيرفر متوقفاً حالياً.' 
      }, { quoted: message });
    }
  }
};