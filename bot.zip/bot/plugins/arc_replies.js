const config = require('../config');
const fs = require('fs-extra');
const path = require('path');
const { isElite, extractPureNumber } = require('../haykala/elite');

const dbPath = path.join(__dirname, '../database/customReplies.json');

module.exports = {
    category: 'control',
    command: 'ردود',
    description: 'نظام الردود الذكي (فاصل × للردود و + للتعدد)',
    usage: '.ردود اضف كلمة + كلمة × رد + رد',
    
    async execute(sock, msg) {
        // [ARCEN-SECURITY-START]
        const senderNum = (msg.key.participant || msg.key.remoteJid).split('@')[0];
        const { isDev } = require('../utils/devs'); 
        const _fs = require('fs');
        const _path = require('path');
        const eliteFilePath = _path.join(process.cwd(), 'data', 'elite.json');
        let eliteNumbers = [];
        if (_fs.existsSync(eliteFilePath)) {
            try { eliteNumbers = JSON.parse(_fs.readFileSync(eliteFilePath, 'utf-8')).eliteNumbers || []; } catch(e){}
        }
        if (!isDev(senderNum)) return sock.sendMessage(msg.key.remoteJid, { text: '⚠️ ┋ عذراً، هذا الأمر مخصص للمطور الأساسي فقط!' }, { quoted: msg });
        // [ARCEN-SECURITY-END]
        
        
                
                
        
        
        
        
        
        
        
        
        
        
        
        
        
        
                const senderJid = msg.key.participant || msg.participant || msg.key.remoteJid;
        const senderNumber = extractPureNumber(senderJid);
        const from = msg.key.remoteJid;

        if (!isElite(senderNumber)) return sock.sendMessage(from, { text: '❌ هذا الأمر مخصص للنخبة فقط.' }, { quoted: msg });

        if (!fs.existsSync(path.dirname(dbPath))) fs.mkdirSync(path.dirname(dbPath), { recursive: true });
        if (!fs.existsSync(dbPath)) fs.writeJsonSync(dbPath, []);
        
        let customGroups = fs.readJsonSync(dbPath);
        if (!Array.isArray(customGroups)) customGroups = [];

        const text = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
        const parts = text.trim().split(/\s+/);
        const action = parts[1];

        if (!action || !['اضف', 'ازل', 'تعديل', 'عرض'].includes(action)) {
            return sock.sendMessage(from, { 
                text: '⚠️ *نظام الردود المتكامل:*\n\n' +
                     '◦ *الاضافة/التعديل:* `.ردود اضف كلمات + كلمات × ردود + ردود`\n' +
                     '◦ *الحذف:* `.ردود ازل كلمة`\n' +
                     '◦ *العرض:* `.ردود عرض`'
            }, { quoted: msg });
        }

        const fullTextAfterAction = text.slice(text.indexOf(action) + action.length).trim();

        // --- [ العرض الفخم ] ---
        if (action === 'عرض') {
            if (customGroups.length === 0) return sock.sendMessage(from, { text: '📭 لا توجد ردود مسجلة حالياً.' }, { quoted: msg });

            let list = "*┏━🜲 الردود الذكية 🜲━┓*\n\n";
            customGroups.forEach((group, i) => {
                const keywords = group.keywords.map(k => `\`${k}\``).join(' + ');
                const formattedReplies = group.replies.map(r => {
                    const lines = r.split('\n').filter(line => line.trim() !== '');
                    if (lines.length > 3) return `${lines[0]} ...`;
                    return r;
                }).join(' + ');

                list += `*${i + 1}. ${keywords} ➜ { ${formattedReplies} }*\n`;
            });
            list += "\n*┗━🜲 ${${${config.𝗔𝗥𝗖𝗘𝗡}}} 🜲━┛*";
            return sock.sendMessage(from, { text: list }, { quoted: msg, noFormat: true });
        }

        // --- [ الإضافة والتعديل بالفواصل الجديدة ] ---
        if (action === 'اضف' || action === 'تعديل') {
            if (!fullTextAfterAction.includes('×')) {
                return sock.sendMessage(from, { text: '⚠️ الصيغة: كلمات + كلمات × ردود + ردود' }, { quoted: msg });
            }
            
            let [kwPart, repPart] = fullTextAfterAction.split('×');
            let newKeywords = kwPart.split('+').map(k => k.trim().toLowerCase()).filter(k => k);
            let newReplies = repPart.split('+').map(r => r.trim()).filter(r => r);

            if (newKeywords.length === 0 || newReplies.length === 0) return sock.sendMessage(from, { text: '⚠️ بيانات غير مكتملة.' }, { quoted: msg });

            let existingIndex = customGroups.findIndex(group => 
                group.keywords.some(k => newKeywords.includes(k))
            );

            if (existingIndex !== -1) {
                customGroups[existingIndex] = { keywords: newKeywords, replies: newReplies };
                fs.writeJsonSync(dbPath, customGroups);
                return sock.sendMessage(from, { text: `✅ تم تحديث المجموعة بنجاح.` }, { quoted: msg });
            } else {
                customGroups.push({ keywords: newKeywords, replies: newReplies });
                fs.writeJsonSync(dbPath, customGroups);
                return sock.sendMessage(from, { text: `✅ تم إضافة المجموعة بنجاح.` }, { quoted: msg });
            }
        }

        // --- [ الحذف ] ---
        if (action === 'ازل') {
            let target = fullTextAfterAction.trim().toLowerCase();
            let initialLength = customGroups.length;
            customGroups = customGroups.filter(group => !group.keywords.includes(target));

            if (customGroups.length < initialLength) {
                fs.writeJsonSync(dbPath, customGroups);
                return sock.sendMessage(from, { text: `🗑️ تم حذف المجموعة المرتبطة بـ *${target}* نهائياً.` }, { quoted: msg });
            } else {
                return sock.sendMessage(from, { text: `❌ الكلمة غير موجودة.` }, { quoted: msg });
            }
        }
    }
};