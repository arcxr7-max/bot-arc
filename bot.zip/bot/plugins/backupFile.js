const fs = require('fs');
const path = require('path');
const { isDev } = require('../utils/devs');

// دالة ذكية لإنشاء بافر ZIP برمجياً وسريعاً بدون مكاتب خارجية
function createSimpleZip(dirPath, excludeDirs = []) {
    const filesList = [];
    function getFilesRecursively(currentDir) {
        const files = fs.readdirSync(currentDir);
        for (const file of files) {
            const fullPath = path.join(currentDir, file);
            const relativePath = path.relative(dirPath, fullPath).replace(/\\/g, '/');
            if (excludeDirs.some(exclude => relativePath === exclude || relativePath.startsWith(exclude + '/'))) {
                continue;
            }
            const stat = fs.statSync(fullPath);
            if (stat.isDirectory()) {
                getFilesRecursively(fullPath);
            } else {
                filesList.push({ name: relativePath, content: fs.readFileSync(fullPath) });
            }
        }
    }
    getFilesRecursively(dirPath);

    let offset = 0;
    const localHeaders = [];
    const centralDirectory = [];

    for (const file of filesList) {
        const nameBuffer = Buffer.from(file.name);
        const contentBuffer = file.content;
        const crc = 0;

        const lfh = Buffer.alloc(30 + nameBuffer.length);
        lfh.writeUint32LE(0x04034b50, 0);
        lfh.writeUint16LE(10, 4);
        lfh.writeUint16LE(0, 6);
        lfh.writeUint16LE(0, 8);
        lfh.writeUint32LE(0, 10);
        lfh.writeUint32LE(crc, 14);
        lfh.writeUint32LE(contentBuffer.length, 18);
        lfh.writeUint32LE(contentBuffer.length, 22);
        lfh.writeUint16LE(nameBuffer.length, 26);
        lfh.writeUint16LE(0, 28);
        nameBuffer.copy(lfh, 30);

        localHeaders.push(lfh, contentBuffer);

        const cdfh = Buffer.alloc(46 + nameBuffer.length);
        cdfh.writeUint32LE(0x02014b50, 0);
        cdfh.writeUint16LE(20, 4);
        cdfh.writeUint16LE(10, 6);
        cdfh.writeUint16LE(0, 8);
        cdfh.writeUint16LE(0, 10);
        cdfh.writeUint32LE(0, 12);
        cdfh.writeUint32LE(crc, 16);
        cdfh.writeUint32LE(contentBuffer.length, 20);
        cdfh.writeUint32LE(contentBuffer.length, 24);
        cdfh.writeUint16LE(nameBuffer.length, 28);
        cdfh.writeUint16LE(0, 30);
        cdfh.writeUint16LE(0, 32);
        cdfh.writeUint16LE(0, 34);
        cdfh.writeUint16LE(0, 36);
        cdfh.writeUint32LE(0, 38);
        cdfh.writeUint32LE(offset, 42);
        nameBuffer.copy(cdfh, 46);

        centralDirectory.push(cdfh);
        offset += lfh.length + contentBuffer.length;
    }

    const cdBuffer = Buffer.concat(centralDirectory);
    const eocd = Buffer.alloc(22);
    eocd.writeUint32LE(0x06054b50, 0);
    eocd.writeUint16LE(0, 4);
    eocd.writeUint16LE(0, 6);
    eocd.writeUint16LE(filesList.length, 8);
    eocd.writeUint16LE(filesList.length, 10);
    eocd.writeUint32LE(cdBuffer.length, 12);
    eocd.writeUint32LE(offset, 16);
    eocd.writeUint16LE(0, 20);

    return Buffer.concat([...localHeaders, cdBuffer, eocd]);
}

module.exports = {
category: 'control',
command: 'backup',
description: '📦 إنشاء نسخة احتياطية كاملة للسورس وضغطها تلقائياً وإرسالها للمطور',

async execute(sock, msg) {
try {
const chatId = msg.key.remoteJid;
const sender = (msg.key.participant || msg.key.remoteJid).split('@')[0];

// ⚠️ رسالة التحقق والحماية للمطورين
if (!isDev(sender)) {
return sock.sendMessage(chatId, {
text: '⚠️ ┋ عذراً، هذا الأمر مخصص للمطور الأساسي فقط!'
}, { quoted: msg });
}

await sock.sendMessage(chatId, { text: '⏳ جاري الآن تجميع وضغط ملفات السورس تلقائياً بصيغة ZIP...' }, { quoted: msg });

// المجلدات والملفات الثقيلة المستبعدة من الضغط لتسريع الإرسال وتقليل المساحة
const excludes = ['node_modules', '.git', '.npm', 'bot.zip', '.zip'];

// توليد النسخة الاحتياطية مباشرة في الذاكرة كـ Buffer
const zipBuffer = createSimpleZip(process.cwd(), excludes);

// إرسال الملف المضغوط الجديد مباشرة إلى الشات
await sock.sendMessage(chatId, {
document: zipBuffer,
mimetype: 'application/zip',
fileName: 'bot_backup.zip'
}, { quoted: msg });

} catch (error) {
console.error('❌ خطأ في أمر النسخ الاحتياطي والتوليد الآلي:', error);
await sock.sendMessage(msg.key.remoteJid, {
text: `❌ فشل إنشاء وإرسال النسخة الاحتياطية.\n⚠️ السبب: ${error.message}`
}, { quoted: msg });
}
}
};