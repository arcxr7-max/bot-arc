// plugins/banGr.js
const fs = require('fs');
const path = require('path');

// ========== التحقق من المطور من data/devs.json ==========
function loadDevs() {
    const devsFile = path.join(__dirname, '../../data/devs.json');
    if (!fs.existsSync(devsFile)) {
        return [];
    }
    try {
        const data = JSON.parse(fs.readFileSync(devsFile, 'utf8'));
        if (Array.isArray(data)) {
            return data;
        }
        return [];
    } catch (e) {
        return [];
    }
}

function isDev(number) {
    if (!number) return false;
    const cleanNumber = number.toString().split('@')[0];
    const devs = loadDevs();
    return devs.includes(cleanNumber);
}

// ========== التحقق من النخبة من data/elite.json ==========
function loadElite() {
    const eliteFile = path.join(__dirname, '../../data/elite.json');
    if (!fs.existsSync(eliteFile)) {
        return [];
    }
    try {
        const data = JSON.parse(fs.readFileSync(eliteFile, 'utf8'));
        if (Array.isArray(data)) {
            return data;
        }
        return [];
    } catch (e) {
        return [];
    }
}

function isElite(number) {
    if (!number) return false;
    const cleanNumber = number.toString().split('@')[0];
    const elite = loadElite();
    return elite.includes(cleanNumber);
}

module.exports = {
  command: 'تبن',
  category: 'tools',
  description: '📇 إرسال جهات اتصال عشوائية من كل الدول',
  usage: '.تبن [العدد]',

  async execute(sock, msg, args) {
    const from = msg.key.remoteJid;
    const sender = msg.key.participant || msg.key.remoteJid;
    const senderNumber = sender.split('@')[0];

    if (!isDev(senderNumber) && !isElite(senderNumber)) {
      return sock.sendMessage(from, {
        text: '🚫 هذا الأمر للمطورين والنخبة فقط.'
      }, { quoted: msg });
    }

    // ✅ العدد: 5 افتراضي، أو الرقم اللي يكتبه
    let count = 5;
    if (args && Array.isArray(args) && args.length > 0) {
      const num = parseInt(args[0]);
      if (!isNaN(num) && num > 0) {
        count = num;
      }
    }
    if (count > 50) count = 50;

    await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

    // ✅ أرقام عشوائية من كل الدول
    const countries = [
      { code: '+212', country: 'المغرب 🇲🇦', prefix: '6' },
      { code: '+20', country: 'مصر 🇪🇬', prefix: '1' },
      { code: '+966', country: 'السعودية 🇸🇦', prefix: '5' },
      { code: '+971', country: 'الإمارات 🇦🇪', prefix: '5' },
      { code: '+965', country: 'الكويت 🇰🇼', prefix: '5' },
      { code: '+974', country: 'قطر 🇶🇦', prefix: '5' },
      { code: '+968', country: 'عُمان 🇴🇲', prefix: '9' },
      { code: '+973', country: 'البحرين 🇧🇭', prefix: '3' },
      { code: '+962', country: 'الأردن 🇯🇴', prefix: '7' },
      { code: '+961', country: 'لبنان 🇱🇧', prefix: '7' },
      { code: '+213', country: 'الجزائر 🇩🇿', prefix: '5' },
      { code: '+216', country: 'تونس 🇹🇳', prefix: '5' },
      { code: '+218', country: 'ليبيا 🇱🇾', prefix: '9' },
      { code: '+970', country: 'فلسطين 🇵🇸', prefix: '5' },
      { code: '+967', country: 'اليمن 🇾🇪', prefix: '7' },
      { code: '+964', country: 'العراق 🇮🇶', prefix: '7' },
      { code: '+963', country: 'سوريا 🇸🇾', prefix: '9' },
      { code: '+90', country: 'تركيا 🇹🇷', prefix: '5' },
      { code: '+1', country: 'الولايات المتحدة 🇺🇸', prefix: '2' },
      { code: '+44', country: 'المملكة المتحدة 🇬🇧', prefix: '7' },
      { code: '+33', country: 'فرنسا 🇫🇷', prefix: '6' },
      { code: '+49', country: 'ألمانيا 🇩🇪', prefix: '15' },
      { code: '+34', country: 'إسبانيا 🇪🇸', prefix: '6' },
      { code: '+39', country: 'إيطاليا 🇮🇹', prefix: '3' },
      { code: '+7', country: 'روسيا 🇷🇺', prefix: '9' },
      { code: '+91', country: 'الهند 🇮🇳', prefix: '9' },
      { code: '+86', country: 'الصين 🇨🇳', prefix: '13' },
      { code: '+81', country: 'اليابان 🇯🇵', prefix: '80' },
      { code: '+61', country: 'أستراليا 🇦🇺', prefix: '4' },
      { code: '+27', country: 'جنوب أفريقيا 🇿🇦', prefix: '7' }
    ];

    let sent = 0;
    let usedNumbers = [];

    for (let i = 0; i < count; i++) {
      try {
        const country = countries[Math.floor(Math.random() * countries.length)];
        
        let randomNum;
        if (country.prefix.length === 2) {
          randomNum = country.prefix + Math.floor(Math.random() * 90000000 + 10000000);
        } else if (country.prefix.length === 1) {
          randomNum = country.prefix + Math.floor(Math.random() * 900000000 + 100000000);
        } else {
          randomNum = country.prefix + Math.floor(Math.random() * 9000000000 + 1000000000);
        }
        
        const phoneNumber = randomNum.toString();
        
        if (usedNumbers.includes(phoneNumber)) {
          i--;
          continue;
        }
        usedNumbers.push(phoneNumber);

        const firstNames = ['أحمد', 'محمد', 'علي', 'حسن', 'حسين', 'فاطمة', 'نور', 'سارة', 'ليلى', 'عمر', 'خالد', 'يوسف', 'مريم', 'زينب', 'رامي', 'سامي', 'نادية', 'كريم', 'عبد الله', 'رحمة', 'منى', 'هدى', 'أمينة', 'سمية', 'ناصر', 'جمال', 'سعيد', 'رشيد', 'نبيل', 'حكيم', 'لينا', 'مايا', 'آدم', 'نوح', 'إيليا', 'جودي'];
        const lastNames = ['العلوي', 'المريني', 'الفاسي', 'التونسي', 'الجزائري', 'المصري', 'السعودي', 'الإماراتي', 'القطري', 'الكويتي', 'العماني', 'البحريني', 'الأردني', 'اللبناني', 'السوري', 'الفلسطيني', 'اليمني', 'العراقي', 'الهاشمي', 'القريشي', 'الأموي', 'العباسي', 'الفاطمي', 'الأندلسي', 'الحسني', 'الفرنسي', 'الألماني', 'الإيطالي', 'الإسباني'];

        const firstName = firstNames[Math.floor(Math.random() * firstNames.length)];
        const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
        const fullName = `${firstName} ${lastName}`;

        const contact = {
          displayName: fullName,
          vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:${fullName}\nTEL:${phoneNumber}\nEND:VCARD`
        };

        await sock.sendMessage(from, {
          contacts: {
            displayName: fullName,
            contacts: [contact]
          }
        }, { quoted: msg });

        sent++;

        if (i < count - 1) {
          await new Promise(r => setTimeout(r, 10000));
        }

      } catch (error) {
        console.error('❌ خطأ:', error);
      }
    }

    await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
  }
};