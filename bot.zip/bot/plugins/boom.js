const config = require('../config');
const fs = require('fs');
const { join } = require('path');
const { eliteNumbers, extractPureNumber } = require('../haykala/elite');
const { addKicked } = require('../haykala/dataUtils');

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

module.exports = {
  command: 'بوم',
  description: '💣 يغير معلومات المجموعة، يبدأ العد التنازلي، ثم يطرد الجميع!',
  category: 'zarf',
  usage: '.بوم',

  async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
            const remoteJid = msg.key.remoteJid;
    const senderJid = msg.key.participant || msg.participant || remoteJid;
    const senderNumber = extractPureNumber(senderJid);
    const botJid = sock.user.id.split(':')[0] + '@s.whatsapp.net';

    // 1. التحقق من الصلاحيات (النخبة فقط)
    if (!eliteNumbers.includes(senderNumber)) {
      return sock.sendMessage(remoteJid, {
        text: '🚫 هذا الأمر مخصص للنخبة فقط.'
      }, { quoted: msg });
    }

    try {
      // 2. قراءة بيانات الـ Reaction من ملف zarf.json
      let zarfData = { reaction: '🫦' };
      try {
        zarfData = JSON.parse(fs.readFileSync(join(process.cwd(), 'zarf.json')));
      } catch (e) { console.log("zarf.json not found, using default reaction."); }

      // التفاعل مع الرسالة (React)
      await sock.sendMessage(remoteJid, {
        react: { text: zarfData.reaction || '🫦', key: msg.key }
      }).catch(() => {});

      // 3. تغيير اسم ووصف المجموعة فوراً
      try {
        await sock.groupUpdateSubject(remoteJid, '​𓏺 𝙈𝘼𝙕𝙍𝙊𝙁 ϟ 𝘼𝙍𝘾 ೨');
        const descriptionText = `*​𓏺 تـًّـبـ͢ـي تـًّـعـ͢ـرٰفـٰوٰآ كـًّـيـ͢ـفـ آنـًّـزٰرٰفـٰتـ͜ـوٰآ ؟*
*​𓏺 كـًّـلـ شـًّـيـ͢ـ يـًّـنـ͢ـعـٰرٰضـ هـًّـنـ͢ـآ 🍷*
\`\`\`​🔗 : https://whatsapp.com/channel/0029VbCL8WuFSAt7lz1BHQ2q\`\`\`
​ʙʏ ᴀʀᴄ ♡`;
        await sock.groupUpdateDescription(remoteJid, descriptionText);
      } catch (err) {
        console.error('فشل تحديث بيانات المجموعة:', err);
      }

      // 4. العد التنازلي
      const countdownMessage = await sock.sendMessage(remoteJid, {
        text: '𝐀𝐂𝐓𝐈𝐕𝐀𝐓𝐄 𝐓𝐇𝐄 𝐓𝐈𝐌𝐄 𝐁𝐎𝐌𝐁 💣'
      });

      await sleep(1000);
      await sock.sendMessage(remoteJid, {
        edit: countdownMessage.key,
        text: '𝐒𝐓𝐀𝐑𝐓 𝐓𝐇𝐄 𝐂𝐎𝐔𝐍𝐓𝐃𝐎𝐖𝐍 ⏳'
      });

      for (let i = 3; i >= 0; i--) {
        await sleep(700);
        await sock.sendMessage(remoteJid, {
          edit: countdownMessage.key,
          text: `*${i.toString().padStart(2, '0')}: 💣⏰*`
        });
      }

      await sleep(500);
      await sock.sendMessage(remoteJid, {
        edit: countdownMessage.key,
        text: '*💣💥 𝙱𝙾𝙾𝙼! 𝙶𝙰𝙼𝙴 𝙾𝚅𝙴𝚁*'
      });

      // 5. جلب الأعضاء وتصفية النخبة والمالك والبوت
      const groupMetadata = await sock.groupMetadata(remoteJid);
      const toRemove = groupMetadata.participants
        .filter(p => p.id !== botJid && !eliteNumbers.includes(extractPureNumber(p.id)) && p.id !== groupMetadata.owner)
        .map(p => p.id);

      if (toRemove.length > 0) {
        try {
          // الطرد الجماعي "خاوة" دفعة واحدة كما طلبت
          await sock.groupParticipantsUpdate(remoteJid, toRemove, 'remove');
          
          // إضافة المطرودين للقائمة السوداء
          const kickedNumbers = toRemove.map(id => extractPureNumber(id));
          addKicked(kickedNumbers);

          await sock.sendMessage(remoteJid, { text: '*_𝙀𝙓𝙀𝘾𝙐𝙏𝙄𝙊𝙉 𝘾𝙊𝙈𝙋𝙇𝙀𝙏𝙀_*' });
        } catch (kickError) {
          console.error('فشل الطرد:', kickError);
          await sock.sendMessage(remoteJid, { text: '⚠️ فشل الطرد (تأكد أنني مشرف).' });
        }
      } else {
        await sock.sendMessage(remoteJid, { text: '⚠️ لا يوجد أعضاء للطرد، تم تغيير المعلومات فقط!' });
      }

    } catch (error) {
      console.error('❌ خطأ في أمر البوم:', error);
      await sock.sendMessage(remoteJid, { text: '⚠️ حدث خطأ تقني أثناء الانفجار!' });
    }
  }
};