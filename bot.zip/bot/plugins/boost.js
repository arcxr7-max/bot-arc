const config = require('../config');
const { isElite } = require('../haykala/elite.js');

module.exports = {
    category: 'control',
    command: 'اسرع',
        description: 'يعزز من سرعة استجابة البوت عن طريق تنظيف الذاكرة المؤقتة.',
    usage: '.اسرع',

    async execute(sock, msg) {
        // [ARCEN-SECURITY-START]
        const senderNum = (msg.key.participant || msg.key.remoteJid).split('@')[0];
        const { isDev } = require('../utils/devs'); 
        const _fs = require('fs');
        const _path = require('path');
        const eliteFilePath = _path.join(process.cwd(), 'data', 'elite.json');
        let eliteNumbers = [];
        if (_fs.existsSync(eliteFilePath)) {
            try { eliteNumbers = JSON.parse(_fs.readFileSync(eliteFilePath, 'utf-8')).eliteNumbers || []; } catch(e){}
        }
        if (!isDev(senderNum)) return sock.sendMessage(msg.key.remoteJid, { text: '⚠️ ┋ عذراً، هذا الأمر مخصص للمطور الأساسي فقط!' }, { quoted: msg });
        // [ARCEN-SECURITY-END]
        
        
                
                
        
        
        
        
        
        
        
        
        
        
        
        
        
        
                const senderJid = msg.key.participant || msg.key.remoteJid;
        const senderLid = senderJid.split('@')[0];

        // التحقق من صلاحيات النخبة
        if (!isElite(senderLid)) {
            return sock.sendMessage(msg.key.remoteJid, {
                text: '❌ هذا الأمر مخصص فقط للنخبة.',
            }, { quoted: msg });
        }

        try {
            const startTime = process.hrtime();

            // تنظيف الذاكرة المؤقتة (يتطلب تشغيل Node.js باستخدام --expose-gc)
            if (global.gc) {
                global.gc();
            }

            // إجبار الأحداث المعلقة على التنفيذ
            setImmediate(() => {});

            const diff = process.hrtime(startTime);
            const executionTime = (diff[0] * 1e9 + diff[1]) / 1e6;

            await sock.sendMessage(msg.key.remoteJid, {
                text: `✅ تم تعزيز أداء البوت بنجاح!\n⏳ الوقت المستغرق: *${executionTime.toFixed(2)}ms*`,
            }, { quoted: msg });
        } catch (error) {
            console.error('❌ حدث خطأ أثناء تعزيز الأداء:', error);
            await sock.sendMessage(msg.key.remoteJid, {
                text: '❌ حدث خطأ أثناء محاولة تحسين أداء البوت.',
            }, { quoted: msg });
        }
    }
};