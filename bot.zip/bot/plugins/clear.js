const fs = require('fs');
const path = require('path');
const { isDev } = require('../utils/devs');

// المجلدات اللي بننظفها من الملفات المؤقتة
const foldersToClean = [
    'plugins',
    'handlers',
    'utils',
    'haykala',
    'data',
    'temp'
];

// الامتدادات اللي بنحذفها
const extensionsToDelete = [
    '.bak', '.js.bak',        // ملفات النسخ الاحتياطي المفرطة
    '.jpg', '.jpeg', '.png', '.gif', '.webp', '.ico',  // الصور
    '.mp4', '.avi', '.mkv', '.mov', '.wmv', '.flv',    // الفيديو
    '.mp3', '.wav', '.ogg', '.m4a', '.flac', '.aac',   // الصوتيات
    '.zip', '.rar', '.7z', '.tar', '.gz',               // الملفات المضغوطة
    '.log', '.md',                              // الملفات النصية
    '.exe', '.msi', '.apk', '.dmg'                     // الملفات التنفيذية
];

function formatSize(bytes) {
    if (bytes >= 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
    if (bytes >= 1024) return (bytes / 1024).toFixed(2) + ' KB';
    return bytes + ' B';
}

module.exports = {
    category: 'control',
    command: 'تنظيف',
    description: '🧹 حذف ملفات bak، الصور، الميديا، وتفريغ مجلد النسخ الاحتياطية بالكامل',
    usage: '.تنظيف',
    
    async execute(sock, msg) {

        const chatId = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;
        const senderNumber = sender.split('@')[0];

        if (!isDev(senderNumber)) {
            return sock.sendMessage(chatId, { text: '🚫 للمطور فقط' }, { quoted: msg });
        }

        await sock.sendMessage(chatId, { react: { text: '🧹', key: msg.key } });

        let totalDeleted = 0;
        let totalSize = 0;
        let deletedFiles = [];

        // 1️⃣ الجزء الأول: تنظيف الملفات المؤقتة بالامتدادات من المجلدات العادية
        for (const folder of foldersToClean) {
            const folderPath = path.join(process.cwd(), folder);
            if (!fs.existsSync(folderPath)) continue;

            try {
                const files = fs.readdirSync(folderPath);
                for (const file of files) {
                    const ext = path.extname(file).toLowerCase();
                    if (extensionsToDelete.includes(ext)) {
                        const filePath = path.join(folderPath, file);
                        const stats = fs.statSync(filePath);
                        if (fs.lstatSync(filePath).isFile()) {
                            totalSize += stats.size;
                            fs.unlinkSync(filePath);
                            totalDeleted++;
                            deletedFiles.push(`${folder}/${file} (${formatSize(stats.size)})`);
                        }
                    }
                }
            } catch (e) {}
        }

        // 2️⃣ الجزء الثاني: إبادة وتفريغ مجلد الباك اب بالكامل (ملفات ومجلدات)
        const backupDir = path.join(process.cwd(), 'backups');
        if (fs.existsSync(backupDir)) {
            try {
                const backupFiles = fs.readdirSync(backupDir);
                for (const file of backupFiles) {
                    const filePath = path.join(backupDir, file);
                    const stats = fs.statSync(filePath);
                    
                    // حساب الحجم قبل الحذف
                    totalSize += stats.size;
                    
                    if (fs.lstatSync(filePath).isDirectory()) {
                        fs.rmSync(filePath, { recursive: true, force: true });
                    } else {
                        fs.unlinkSync(filePath);
                    }
                    totalDeleted++;
                    deletedFiles.push(`backups/${file} (مستند/مجلد)`);
                }
            } catch (e) {}
        }

        if (totalDeleted === 0) {
            return sock.sendMessage(chatId, {
                text: '📭 النظام نظيف تماماً! لا توجد ملفات مؤقتة أو نسخ احتياطية للتنظيف حالياً.'
            }, { quoted: msg });
        }

        // 📜 زخرفة وتنسيق التقرير النهائي
        const successMessage = 
`*┏━🜲 𝗕𝗢𝗧 🜲━┓*
*╭───❒ 『 SYSTEM CLEANED 』*
> 🧹 تم تشغيل التنظيف الشامل وتصفير المستودعات بنجاح!
*───────────────────────*
- \`إجمالي الملفات والنسخ محذوفة:\` *${totalDeleted}*
- \`المساحة الإجمالية المحررة:\` *${formatSize(totalSize)}*
*───────────────────────*
*📁 تفاصيل العمليات الأخيرة:*
${deletedFiles.slice(0, 15).map(f => `▫️ ${f}`).join('\n')}
${deletedFiles.length > 15 ? `▫️ ...و ${deletedFiles.length - 15} ملفات أخرى تم إبادتها.` : ''}
*───────────────────────*
*> ✨ تم تفريغ مجلد backups ومسح الميديا التالفة بنجاح ⦿*
*╰──────────────*
*┗━🜲 𝗕𝗢𝗧 🜲━┛*`;

        await sock.sendMessage(chatId, { text: successMessage }, { quoted: msg });
    }
};