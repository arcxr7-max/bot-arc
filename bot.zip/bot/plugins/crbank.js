const config = require('../config');
const fs = require('fs');
const path = require('path');

const pointsFile = path.join(__dirname, '../data/points.json');
const banksFile = path.join(__dirname, '../data/banks.json');
const accountsFile = path.join(__dirname, '../data/bankAccounts.json');

// قائمة البنوك الافتراضية
let banks = [
    { id: 1, name: 'بنك النقابة السوداء', emoji: '🖤' },
    { id: 2, name: 'بنك الهوكاغي', emoji: '🔥' },
    { id: 3, name: 'بنك القراصنة', emoji: '🏴‍☠️' },
    { id: 4, name: 'بنك السينين', emoji: '🌀' },
    { id: 5, name: 'بنك الأكاتسكي', emoji: '☁️' },
    { id: 6, name: 'بنك العمالقة', emoji: '⚔️' },
    { id: 7, name: 'بنك الساموراي', emoji: '🗡️' },
    { id: 8, name: 'بنك النينجا', emoji: '🥷' },
    { id: 9, name: 'بنك التنين', emoji: '🐉' },
    { id: 10, name: 'بنك الساحرات', emoji: '🧙‍♀️' }
];

// تحميل قائمة البنوك من الملف
function loadBanks() {
    if (!fs.existsSync(banksFile)) {
        fs.writeFileSync(banksFile, JSON.stringify(banks, null, 2));
        return banks;
    }
    return JSON.parse(fs.readFileSync(banksFile, 'utf8'));
}

function saveBanks(data) {
    fs.writeFileSync(banksFile, JSON.stringify(data, null, 2));
}

// تحميل الحسابات
function loadAccounts() {
    if (!fs.existsSync(accountsFile)) return {};
    return JSON.parse(fs.readFileSync(accountsFile, 'utf8'));
}

function saveAccounts(data) {
    fs.writeFileSync(accountsFile, JSON.stringify(data, null, 2));
}

function loadPoints() {
    if (!fs.existsSync(pointsFile)) return {};
    return JSON.parse(fs.readFileSync(pointsFile, 'utf8'));
}

function savePoints(data) {
    fs.writeFileSync(pointsFile, JSON.stringify(data, null, 2));
}

// توليد رقم حساب عشوائي (10 أرقام)
function generateAccountNumber() {
    return Math.floor(Math.random() * 9000000000) + 1000000000;
}

module.exports = {
    command: 'انشاء',
    description: '🏦 إنشاء حساب بنكي جديد',
    usage: '.انشاء',
    category: 'bank',

    async execute(sock, msg) {
        const chatId = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;
        const senderNumber = sender.split('@')[0];

        // التحقق من وجود حساب مسبق
        let accounts = loadAccounts();
        if (accounts[senderNumber]) {
            const account = accounts[senderNumber];
            const createdAt = account.createdAt ? new Date(account.createdAt).toLocaleDateString('ar-EG') : 'غير معروف';
            
            return sock.sendMessage(chatId, {
                text: `❌ لديك حساب بالفعل!\n\n🔢 رقم الحساب: ${account.accountNumber}\n🏦 البنك: ${account.bankName}\n📅 تاريخ الإنشاء: ${createdAt}`
            }, { quoted: msg });
        }

        // عرض قائمة البنوك
        const currentBanks = loadBanks();
        let banksList = '';
        currentBanks.forEach((bank, idx) => {
            banksList += `${idx + 1}. ${bank.emoji} ${bank.name}\n`;
        });

        const bankMessage = await sock.sendMessage(chatId, {
            text: `🏦 *اختر بنكك:*\n\n${banksList}\n\n*🔹 اكتب رقم البنك فقط (1-${currentBanks.length})*`
        }, { quoted: msg });

        // تخزين مؤقت لانتظار رد المستخدم
        global.waitingForBank = global.waitingForBank || {};
        global.waitingForBank[senderNumber] = {
            step: 'waiting_bank',
            msgId: bankMessage.key.id,
            timestamp: Date.now()
        };

        // مهلة 30 ثانية
        setTimeout(() => {
            if (global.waitingForBank[senderNumber]) {
                delete global.waitingForBank[senderNumber];
                sock.sendMessage(chatId, { text: '⌛ انتهى الوقت. أعد استخدام .انشاء' });
            }
        }, 30000);
    },

    // معالج الردود (يجب إضافته في handler.js)
    async handleResponse(sock, msg) {
        const chatId = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;
        const senderNumber = sender.split('@')[0];
        const body = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';

        if (!global.waitingForBank?.[senderNumber]) return false;

        const waiting = global.waitingForBank[senderNumber];
        
        if (waiting.step === 'waiting_bank') {
            const bankIndex = parseInt(body) - 1;
            const currentBanks = loadBanks();
            
            if (isNaN(bankIndex) || bankIndex < 0 || bankIndex >= currentBanks.length) {
                await sock.sendMessage(chatId, { text: '❌ رقم غير صحيح. أعد استخدام .انشاء' });
                delete global.waitingForBank[senderNumber];
                return true;
            }

            const selectedBank = currentBanks[bankIndex];
            const accountNumber = generateAccountNumber();
            
            // إنشاء الحساب
            let points = loadPoints();
            let accounts = loadAccounts();
            
            accounts[senderNumber] = {
                accountNumber: accountNumber,
                bankId: selectedBank.id,
                bankName: selectedBank.name,
                bankEmoji: selectedBank.emoji,
                createdAt: new Date().toISOString()
            };
            
            if (!points[senderNumber]) points[senderNumber] = 0;
            saveAccounts(accounts);
            savePoints(points);
            
            await sock.sendMessage(chatId, {
                text: `✅ *تم إنشاء حسابك بنجاح!*\n\n🏦 البنك: ${selectedBank.emoji} ${selectedBank.name}\n🔢 رقم الحساب: *${accountNumber}*\n💰 الرصيد الحالي: ${points[senderNumber]} نقطة\nاستخدم .بنكي لعرض أوامر البنك`
            }, { quoted: msg });
            
            // حذف رسالة القائمة
            try {
                await sock.sendMessage(chatId, { delete: { remoteJid: chatId, id: waiting.msgId, fromMe: true } });
            } catch(e) {}
            
            delete global.waitingForBank[senderNumber];
            return true;
        }
        
        return false;
    }
};