const fs = require('fs');
const path = require('path');
const { isDev } = require('../utils/devs');

const folders = ['plugins', 'handlers', 'utils', 'haykala', 'data'];

module.exports = {
category: 'control',
command: 'dell',
description: '🗑️ حذف جميع ملفات .bak من كل المجلدات',
usage: '.dell',

async execute(sock, msg) {
const chatId = msg.key.remoteJid;
const sender = msg.key.participant || msg.key.remoteJid;
const senderNumber = sender.split('@')[0];

// ⚠️ رسالة التحقق والحماية المعدلة بناءً على طلبك
if (!isDev(senderNumber)) {
return sock.sendMessage(chatId, { 
text: '⚠️ ┋ عذراً، هذا الأمر مخصص للمطور الأساسي فقط!' 
}, { quoted: msg });
}

let totalDeleted = 0;
let allFiles = [];

for (const folder of folders) {
const folderPath = path.join(__dirname, '..', folder);
if (!fs.existsSync(folderPath)) continue;

const files = fs.readdirSync(folderPath);
const bakFiles = files.filter(f => f.endsWith('.bak') || f.endsWith('.js.bak'));

for (const file of bakFiles) {
try {
fs.unlinkSync(path.join(folderPath, file));
totalDeleted++;
allFiles.push(`${folder}/${file}`);
} catch(e) {}
}
}

if (totalDeleted === 0) {
return sock.sendMessage(chatId, { text: '📭 لا توجد ملفات باك اب' }, { quoted: msg });
}

await sock.sendMessage(chatId, {
text: `🗑️ تم حذف ${totalDeleted} ملف باك اب\n\n📁 الملفات:\n${allFiles.map(f => `▫️ ${f}`).join('\n')}`
}, { quoted: msg });
}
};