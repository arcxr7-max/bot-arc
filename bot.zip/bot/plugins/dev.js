// plugins/dev.js
const { isDev, addDev, removeDev, getDevs } = require('../utils/devs');

module.exports = {
    command: 'مطور',
    category: 'system',
    description: '👑 إدارة المطورين (للمطورين فقط)',
    usage: '.مطور [اضف|ازل] [الرقم أو منشن]',

    async execute(sock, msg, args) {
        const from = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;
        const senderNumber = sender ? sender.split('@')[0] : null;

        if (!senderNumber) {
            return sock.sendMessage(from, {
                text: '❌ حدث خطأ في التعرف على المرسل.'
            }, { quoted: msg });
        }

        // ✅ التحقق من المطور
        if (!isDev(senderNumber)) {
            return sock.sendMessage(from, {
                text: '🚫 هذا الأمر للمطورين فقط.'
            }, { quoted: msg });
        }

        const body = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
        const parts = body.trim().split(/\s+/);
        
        const action = parts[1]?.toLowerCase();
        
        // ✅ استخراج الرقم المستهدف
        let targetNumber = null;

        // 1️⃣ منشن
        if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
            const mentioned = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];
            if (mentioned) {
                targetNumber = mentioned.split('@')[0];
            }
        }
        
        // 2️⃣ رد على رسالة
        if (!targetNumber && msg.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
            const participant = msg.message.extendedTextMessage.contextInfo.participant;
            if (participant) {
                targetNumber = participant.split('@')[0];
            }
        }
        
        // 3️⃣ كتابة رقم
        if (!targetNumber && parts.length > 2) {
            const possibleNumber = parts[2].replace(/[^0-9]/g, '');
            if (possibleNumber.length >= 10) {
                targetNumber = possibleNumber;
            }
        }

        let devs = getDevs();

        // ===== عرض المطورين =====
        if (!action || action === 'عرض') {
            const list = devs.map((num, i) => `${i + 1}. ${num}`).join('\n');
            return sock.sendMessage(from, {
                text: `👑 *قائمة المطورين:*\n\n${list || 'لا يوجد مطورين'}\n\n📌 *العدد:* ${devs.length}`
            }, { quoted: msg });
        }

        // ===== إضافة مطور =====
        if (action === 'اضف') {
            if (!targetNumber) {
                return sock.sendMessage(from, {
                    text: `❌ اكتب الرقم أو رد على رسالة الشخص أو منشنه.\nمثال: .مطور اضف @شخص`
                }, { quoted: msg });
            }

            if (devs.includes(targetNumber)) {
                return sock.sendMessage(from, {
                    text: `❌ الرقم ${targetNumber} موجود بالفعل`
                }, { quoted: msg });
            }

            addDev(targetNumber);
            
            const newDevs = getDevs();
            return sock.sendMessage(from, {
                text: `✅ تم إضافة المطور:\n📱 ${targetNumber}\n\n📌 *القائمة الجديدة:*\n${newDevs.map((num, i) => `${i + 1}. ${num}`).join('\n')}`
            }, { quoted: msg });
        }

        // ===== إزالة مطور =====
        if (action === 'ازل') {
            if (!targetNumber) {
                return sock.sendMessage(from, {
                    text: `❌ اكتب الرقم أو رد على رسالة الشخص أو منشنه.\nمثال: .مطور ازل @شخص`
                }, { quoted: msg });
            }

            if (!devs.includes(targetNumber)) {
                return sock.sendMessage(from, {
                    text: `❌ الرقم ${targetNumber} غير موجود`
                }, { quoted: msg });
            }

            removeDev(targetNumber);

            const newDevs = getDevs();
            return sock.sendMessage(from, {
                text: `✅ تم إزالة المطور:\n📱 ${targetNumber}\n\n📌 *القائمة الجديدة:*\n${newDevs.map((num, i) => `${i + 1}. ${num}`).join('\n')}`
            }, { quoted: msg });
        }

        return sock.sendMessage(from, {
            text: '❌ أمر غير معروف.\nاستخدم: .مطور [اضف|ازل] [الرقم أو منشن]'
        }, { quoted: msg });
    }
};