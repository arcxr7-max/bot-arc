const fs = require('fs');
const path = require('path');

module.exports = {
category: 'control',
command: ['edit'],
description: '✏️ تعديل بلوجن موجود وتحديثه في الذاكرة فوراً بمجرد الرد.',
usage: '.edit [اسم الملف] (رد على الكود الجديد)',

async execute(sock, msg) {
// [ARCEN-SECURITY-START]
const senderNum = (msg.key.participant || msg.key.remoteJid).split('@')[0];
const { isDev } = require('../utils/devs');
if (!isDev(senderNum)) return sock.sendMessage(msg.key.remoteJid, { text: '⚠️ ┋ عذراً، هذا الأمر مخصص للمطور الأساسي فقط!' }, { quoted: msg });
// [ARCEN-SECURITY-END]

let fullText = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
const parts = fullText.trim().split(/\s+/);
let fileName = parts[1];

if (!fileName) {
return sock.sendMessage(msg.key.remoteJid, {
text: '❌ استخدم: .edit [اسم الملف]\nمثال: .edit نرد\n(رد على رسالة تحتوي على الكود الجديد)',
}, { quoted: msg });
}

fileName = fileName.replace(/[^a-zA-Z0-9-_أ-ي]/g, '');
if (!fileName.endsWith('.js')) fileName += '.js';

const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
let newCode = quoted?.conversation || quoted?.extendedTextMessage?.text;

if (!newCode) {
return sock.sendMessage(msg.key.remoteJid, {
text: '❌ رد على رسالة تحتوي على الكود الجديد للبلوجن',
}, { quoted: msg });
}

newCode = newCode.trim();
const filePath = path.join(process.cwd(), 'plugins', fileName);

if (!fs.existsSync(filePath)) {
return sock.sendMessage(msg.key.remoteJid, {
text: `❌ الملف ${fileName} غير موجود في مجلد plugins`,
}, { quoted: msg });
}

const backupsDir = path.join(process.cwd(), 'backups');
if (!fs.existsSync(backupsDir)) fs.mkdirSync(backupsDir, { recursive: true });
const backupPath = path.join(backupsDir, `${Date.now()}_${fileName}`);
fs.copyFileSync(filePath, backupPath);

try {
fs.writeFileSync(filePath, newCode, 'utf8');

// 🔄 [التحديث التلقائي الذكي للـ Cache]
try {
const pluginsDir = path.join(process.cwd(), 'plugins');
const files = fs.readdirSync(pluginsDir);
for (const file of files) {
if (file.endsWith('.js')) {
delete require.cache[require.resolve(path.join(pluginsDir, file))];
}
}
const handlerPath = path.join(process.cwd(), 'handlers', 'handler.js');
if (fs.existsSync(handlerPath)) delete require.cache[require.resolve(handlerPath)];
if (global.loadPlugins) await global.loadPlugins(true);
} catch (e) { console.error(e); }

// 📝 الرسالة المختصرة الجديدة بناءً على طلبك
await sock.sendMessage(msg.key.remoteJid, {
text: `*✅ تم تعديل البلوجن بنجاح!*\n*📁 plugins/${fileName}*\n*💾 تم حفظ نسخة احتياطية وتحديث النظام*`,
}, { quoted: msg });

} catch (error) {
console.error(error);
await sock.sendMessage(msg.key.remoteJid, {
text: '❌ فشل تعديل الملف',
}, { quoted: msg });
}
}
};