const fs = require('fs');
const path = require('path');

module.exports = {
    category: 'control',
        command: 'find', // الأمر الرئيسي الموحد والمضمون للهاندلر
        description: '🔍 البحث المتقدم عن الملفات والمجلدات أو النصوص داخل النظام',
    usage: '.find b [اسم ملف/مجلد] أو .find a [نص للبحث بداخل الملفات]',

    async execute(sock, msg) {
        // [ARCEN-SECURITY-START]
        const senderNum = (msg.key.participant || msg.key.remoteJid).split('@')[0];
        const { isDev } = require('../utils/devs'); 
        const _fs = require('fs');
        const _path = require('path');
        const eliteFilePath = _path.join(process.cwd(), 'data', 'elite.json');
        let eliteNumbers = [];
        if (_fs.existsSync(eliteFilePath)) {
            try { eliteNumbers = JSON.parse(_fs.readFileSync(eliteFilePath, 'utf-8')).eliteNumbers || []; } catch(e){}
        }
        if (!isDev(senderNum)) return sock.sendMessage(msg.key.remoteJid, { text: '⚠️ ┋ عذراً، هذا الأمر مخصص للمطور الأساسي فقط!' }, { quoted: msg });
        // [ARCEN-SECURITY-END]
        
        const from = msg.key.remoteJid;

        // 📝 استخراج النص الكامل بطريقتك القديمة الشغالة والمضمونة
        const body = msg.message?.extendedTextMessage?.text || msg.message?.conversation || '';
        const args = body.trim().split(/\s+/);
        
        // جلب نوع البحث (الحرف الثاني بعد find) والنص المراد البحث عنه
        const searchType = args[1] ? args[1].toLowerCase() : '';
        const query = args.slice(2).join(' ').trim(); // تخطي اسم الأمر وتخطي حرف الـ (a أو b)

        // لو المستخدم لم يكتب طريقة الاستخدام الصحيحة أو ترك البحث فارغاً
        if (!searchType || (searchType !== 'a' && searchType !== 'b') || !query) {
            return await sock.sendMessage(from, {
                text: `> *⚠️ طريقة استخدام أمر البحث المتقدم:*\n> \`.find b\` [اسم ملف أو مجلد]\n> \`.find a\` [نص للبحث داخل محتوى الملفات]`
            }, { quoted: msg });
        }

        try {
            const rootDir = path.join(__dirname, '../'); // مسارك القديم والمضمون لملفات البوت
            let results = [];

            // ==========================================
            // 📁 [الحالة الأولى]: البحث عن ملف أو مجلد (.find b)
            // ==========================================
            if (searchType === 'b') {
                function searchEntities(dir) {
                    const list = fs.readdirSync(dir);
                    for (const item of list) {
                        const fullPath = path.join(dir, item);
                        const stat = fs.statSync(fullPath);
                        const relativePath = path.relative(rootDir, fullPath);

                        // فحص المجلدات
                        if (stat.isDirectory()) {
                            if (item === 'node_modules' || item.startsWith('.')) continue;

                            if (item.toLowerCase().includes(query.toLowerCase())) {
                                results.push(`│ 📁 مجلد: \`${item}\`\n│ 📍 المَوقع: _${relativePath}_`);
                            }
                            searchEntities(fullPath); // غوص متكرر وعميق
                        } 
                        // فحص الملفات
                        else if (stat.isFile()) {
                            if (item.toLowerCase().includes(query.toLowerCase())) {
                                results.push(`│ 📄 ملف: \`${item}\`\n│ 📍 المَوقع: _${relativePath}_`);
                            }
                        }
                    }
                }

                searchEntities(rootDir);

                if (results.length === 0) {
                    return await sock.sendMessage(from, {
                        text: `*✖️ ┋ ARC-ERROR:* لم يتم العثور على ملف أو مجلد يحتوي على: \`${query}\``
                    }, { quoted: msg });
                }

                const finalMessage = `
*┏━🜲 👑 𝗙𝗜𝗟𝗘/𝗙𝗢𝗟𝗗Ｅ𝗥 𝗙𝗜𝗡𝗗Ｅ𝗥 🜲━┓*
╭───〔 🗂️ 𝗔𝗥𝗖𝗘𝗡 〕───╮
> نتائج البحث عن اسم: \`${query}\`
*───────────────────*
${results.join('\n*───────────────────*\n')}
╰───────────────────╯
*┗━🜲 𝗔𝗥𝗖𝗘𝗡 🜲━┛*
`.trim();

                return await sock.sendMessage(from, { text: finalMessage }, { quoted: msg });
            }

            // ==========================================
            // 📝 [الحالة الثانية]: البحث عن نص داخل الملفات (.find a)
            // ==========================================
            if (searchType === 'a') {
                function searchTextInsideFiles(dir) {
                    const list = fs.readdirSync(dir);
                    for (const item of list) {
                        const fullPath = path.join(dir, item);
                        const stat = fs.statSync(fullPath);

                        if (stat.isDirectory() && item !== 'node_modules' && !item.startsWith('.')) {
                            searchTextInsideFiles(fullPath);
                        } else if (stat.isFile() && (item.endsWith('.js') || item.endsWith('.json') || item.endsWith('.txt'))) {
                            try {
                                const content = fs.readFileSync(fullPath, 'utf-8');
                                if (content.toLowerCase().includes(query.toLowerCase())) {
                                    const relativePath = path.relative(rootDir, fullPath);
                                    
                                    // استخراج سطر أو مقطع يحتوي على الكلمة المطلوبة لسياق فخم
                                    const lines = content.split('\n');
                                    let snippet = '';
                                    for (let line of lines) {
                                        if (line.toLowerCase().includes(query.toLowerCase())) {
                                            snippet = line.trim().substring(0, 60); // جلب أول 60 حرف من السطر
                                            break;
                                        }
                                    }

                                    results.push(`│ 📄 الملف: \`${item}\`\n│ 📍 المَوقع: _${relativePath}_\n│ 💬 المقطع: \`...${snippet}...\``);
                                }
                            } catch (e) {
                                // تخطى الأخطاء والملفات المحمية لتجنب الكراش
                            }
                        }
                    }
                }

                searchTextInsideFiles(rootDir);

                if (results.length === 0) {
                    return await sock.sendMessage(from, {
                        text: `*✖️ ┋ ARC-ERROR:* الكلمة \`${query}\` غير موجودة داخل أي ملف.`
                    }, { quoted: msg });
                }

                const finalMessage = `
*┏━🜲 📝 𝗖𝗢𝗡𝗧𝗘𝗡𝗧 𝗦𝗘𝗔Ｒ𝗖𝗛Ｅ𝗥 🜲━┓*
╭───〔 🗂️ 𝗔𝗥𝗖Ｅ𝗡 〕───╮
> ملفات تحتوي على النص: \`${query}\`
*───────────────────*
${results.join('\n*───────────────────*\n')}
╰───────────────────╯
*┗━🜲 𝗔𝗥𝗖𝗘𝗡 🜲━┛*
`.trim();

                return await sock.sendMessage(from, { text: finalMessage }, { quoted: msg });
            }

        } catch (err) {
            console.error('خطأ في أمر البحث المتقدم:', err);
            await sock.sendMessage(from, {
                text: `*✖️ ┋ ARC-ERROR:* واجه النظام مشكلة أثناء عملية البحث.`
            }, { quoted: msg });
        }
    }
};