const config = require('../config');
const fs = require('fs');
const path = require('path');

// مسارات الملفات
const pointsFile = path.join(__dirname, '../data/points.json');
const giftDataFile = path.join(__dirname, '../data/giftData.json');

// وقت التهدئة (5 دقائق = 300000 مللي ثانية)
const COOLDOWN_TIME = 300000;

// دالة قراءة النقاط
function getPoints() {
    if (!fs.existsSync(pointsFile)) return {};
    return JSON.parse(fs.readFileSync(pointsFile, 'utf8'));
}

// دالة حفظ النقاط
function savePoints(points) {
    fs.writeFileSync(pointsFile, JSON.stringify(points, null, 2), 'utf8');
}

// دالة قراءة بيانات البقشيش
function getGiftData() {
    if (!fs.existsSync(giftDataFile)) return {};
    return JSON.parse(fs.readFileSync(giftDataFile, 'utf8'));
}

// دالة حفظ بيانات البقشيش
function saveGiftData(data) {
    fs.writeFileSync(giftDataFile, JSON.stringify(data, null, 2), 'utf8');
}

// دالة حساب الوقت المتبقي (لـ 5 دقائق)
function getRemainingTime(lastTime) {
    if (!lastTime || lastTime === 0) return null;
    
    const now = Date.now();
    const timePassed = now - lastTime;
    const timeLeft = COOLDOWN_TIME - timePassed;
    
    if (timeLeft <= 0) return null;
    
    const minutes = Math.floor(timeLeft / 60000);
    const seconds = Math.floor((timeLeft % 60000) / 1000);
    
    if (minutes > 0) {
        return `${minutes} دقيقة ${seconds} ثانية`;
    }
    return `${seconds} ثانية`;
}

module.exports = {
    category: 'fun',
    command: 'بقشيش',
    description: '🎁 احصل على نقاط إضافية بين 100 و 550 (مرة كل 5 دقائق)',
    usage: '.بقشيش',
    
    async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
                const chatId = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;
        const senderNumber = sender.split('@')[0];

        // قراءة بيانات البقشيش
        let giftData = getGiftData();
        const lastGiftTime = giftData[senderNumber] || 0;
        const timeSinceLast = Date.now() - lastGiftTime;

        // التحقق من فترة التهدئة (5 دقائق)
        if (lastGiftTime && timeSinceLast < COOLDOWN_TIME) {
            const remaining = getRemainingTime(lastGiftTime);
            if (remaining) {
                return sock.sendMessage(chatId, {
                    text: `⏳ استنى ${remaining}`
                }, { quoted: msg });
            }
        }

        // حساب المبلغ العشوائي بين 100 و 550
        const giftAmount = Math.floor(Math.random() * (550 - 100 + 1)) + 100;

        // تحديث النقاط
        let points = getPoints();
        points[senderNumber] = (points[senderNumber] || 0) + giftAmount;
        savePoints(points);

        // تحديث وقت آخر بقشيش
        giftData[senderNumber] = Date.now();
        saveGiftData(giftData);

        // الرسالة النهائية
        await sock.sendMessage(chatId, {
            text: `خد يامطفر ${giftAmount} 💸`
        }, { quoted: msg });
    }
};