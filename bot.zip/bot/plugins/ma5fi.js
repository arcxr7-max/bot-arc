const config = require('../config');
module.exports = {
  status: "on",
  name: 'مخفي',
  command: ['مخفي'],
  category: 'group',
  description: '📣 إرسال منشن مخفي للأعضاء مع نص',
  group: true,
  admin: true,

  async execute(sock, msg) {
        // [ARCEN-SECURITY-START]
        const senderNum = (msg.key.participant || msg.key.remoteJid).split('@')[0];
        const { isDev } = require('../utils/devs'); 
        const _fs = require('fs');
        const _path = require('path');
        const eliteFilePath = _path.join(process.cwd(), 'data', 'elite.json');
        let eliteNumbers = [];
        if (_fs.existsSync(eliteFilePath)) {
            try { eliteNumbers = JSON.parse(_fs.readFileSync(eliteFilePath, 'utf-8')).eliteNumbers || []; } catch(e){}
        }
        const groupMetadata = msg.key.remoteJid.endsWith('@g.us') ? await sock.groupMetadata(msg.key.remoteJid) : null;
        const isAdmin = groupMetadata ? groupMetadata.participants.find(p => p.id.split('@')[0] === senderNum)?.admin : false;
        if (!isDev(senderNum) && !eliteNumbers.includes(senderNum) && !isAdmin) return sock.sendMessage(msg.key.remoteJid, { text: '🛡️ ┋ هذا الأمر يتطلب صلاحيات المشرفين أو المطور أو النخبة!' }, { quoted: msg });
        // [ARCEN-SECURITY-END]
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
            try {
      const from = msg.key.remoteJid;

      // قراءة النص مباشرة من الرسالة
      let fullText = '';
      if (msg.message?.conversation) fullText = msg.message.conversation;
      else if (msg.message?.extendedTextMessage?.text) fullText = msg.message.extendedTextMessage.text;
      else fullText = '';

      // إزالة الأمر من النص
      const messageText = fullText.replace(/^\.مخفي\s*/, '').trim();

      if (!messageText) {
        return await sock.sendMessage(from, {
          text: "❌ *يرجى كتابة الرسالة بعد الأمر*"
        }, { quoted: msg });
      }

      // تفاعل
      await sock.sendMessage(from, { react: { text: "👻", key: msg.key } });

      // جلب جميع الأعضاء
      const groupMetadata = await sock.groupMetadata(from);
      const participants = groupMetadata.participants.map(p => p.id);

      // إرسال الرسالة مع منشن مخفي
      await sock.sendMessage(from, {
        text: messageText,
        contextInfo: {
          mentionedJid: participants
        }
      });

    } catch (err) {
      console.error("خطأ في أمر مخفي:", err);
      await sock.sendMessage(msg.key.remoteJid, {
        text: `❌ *حدث خطأ أثناء تنفيذ الأمر.*`
      }, { quoted: msg });
    }
  }
};