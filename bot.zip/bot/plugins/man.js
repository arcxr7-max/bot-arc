const config = require('../config');
const { getPlugins } = require('../handlers/plugins.js');
const { jidDecode } = require('@whiskeysockets/baileys');
const { isDev } = require('../utils/devs');
const { isElite } = require('../haykala/elite');

const decode = jid => (jidDecode(jid)?.user || jid.split('@')[0]) + '@s.whatsapp.net';

module.exports = {
  command: 'ب',
  description: 'عرض المجموعات أو تنفيذ أمر في مجموعة أخرى',
  category: 'tools',

  async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
            const chatId = msg.key.remoteJid;
    const sender = decode(msg.key.participant || msg.participant || chatId);
    const senderLid = sender.split('@')[0];

    // ✅ السماح فقط للمطور أو النخبة
    if (!isDev(senderLid) && !isElite(senderLid)) {
      return sock.sendMessage(chatId, {
        text: '🚫 هذا الأمر مخصص فقط للنخبة أو المطور.'
      }, { quoted: msg });
    }

    const text = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
    const input = text.trim().split(' ').slice(1);
    const indexOrCommand = input[0];
    const commandText = input.slice(1).join(' ');

    const allChats = await sock.groupFetchAllParticipating();
    const groups = Object.values(allChats);

    if (!indexOrCommand || indexOrCommand === 'عرض') {
      let list = '📋 *قائمة المجموعات:*\n\n';
      let i = 1;

      for (const group of groups) {
        try {
          const metadata = await sock.groupMetadata(group.id);
          const memberCount = metadata.participants.length;

          list += `${i}. ${metadata.subject}\n`;
          list += `┗━━ 👥 ${memberCount} عضو\n\n`;
          i++;
        } catch (err) {
          list += `${i}. ${group.subject}\n`;
          list += `┗━━ ❌ خطأ\n\n`;
          i++;
        }
      }

      list += `🔹 للاستخدام:\nب [رقم] [أمر]\nمثال: ب 2 .اوامر`;

      return sock.sendMessage(chatId, {
        text: list
      }, { quoted: msg });
    }

    const index = parseInt(indexOrCommand);
    if (isNaN(index) || !commandText) {
      return sock.sendMessage(chatId, {
        text: `⚠️ الاستخدام:\nب [رقم] [أمر]\nمثال: ب 2 .منشن`
      }, { quoted: msg });
    }

    const group = groups[index - 1];
    if (!group) {
      return sock.sendMessage(chatId, {
        text: `❌ لا يوجد مجموعة بهذا الرقم: ${index}`
      }, { quoted: msg });
    }

    const contextInfo = msg.message?.extendedTextMessage?.contextInfo || {};

    const fakeMsg = {
      key: {
        remoteJid: group.id,
        participant: sender,
        fromMe: false,
        id: msg.key.id
      },
      message: {
        extendedTextMessage: {
          text: commandText,
          contextInfo: {
            ...contextInfo,
            participant: sender,
            mentionedJid: [sender]
          }
        }
      }
    };

    const allPlugins = getPlugins();
    const cmdName = commandText.trim().split(' ')[0].replace('.', '').toLowerCase();
    const cmdArgs = commandText.trim().split(/\s+/).slice(1);

    const plugin = Object.values(allPlugins).find(p => {
      if (!p.command) return false;
      const commands = Array.isArray(p.command) ? p.command : [p.command];
      return commands.some(c => c.replace(/^\./, '').toLowerCase() === cmdName);
    });

    if (!plugin) {
      return await sock.sendMessage(chatId, {
        text: `❌ لم يتم العثور على الأمر: ${cmdName}`
      }, { quoted: msg });
    }

    try {
      await plugin.execute(sock, fakeMsg, cmdArgs);
      await sock.sendMessage(chatId, {
        text: `✅ تم تنفيذ الأمر *${cmdName}* داخل المجموعة *${group.subject}*`
      }, { quoted: msg });
    } catch (err) {
      console.error('⛔ خطأ أثناء تنفيذ الأمر:', err);
      await sock.sendMessage(chatId, {
        text: `❌ حدث خطأ أثناء تنفيذ الأمر داخل المجموعة المحددة.`
      }, { quoted: msg });
    }
  }
};