const config = require('../config');
const { isElite, extractPureNumber } = require('../haykala/elite');
const { downloadMediaMessage } = require('@whiskeysockets/baileys');

module.exports = {
  command: 'ا',
  category: 'tools',
  description: '📢 منشن جماعي خفي أو معلن (مخصص لنخبة 𝘼𝙍𝘾 فقط)',

  async execute(sock, msg, args = []) {
    try {
      const groupJid = msg.key.remoteJid;
      const senderJid = msg.key.participant || msg.participant || groupJid;
      const senderNumber = extractPureNumber(senderJid);

      if (!groupJid.endsWith('@g.us')) {
        return sock.sendMessage(groupJid, {
          text: '🚫 هذا الأمر يعمل فقط داخل *المجموعات*.'
        }, { quoted: msg });
      }

      // التحقق من النخبة بحقوق 𝘼𝙍𝘾
      if (!isElite(senderNumber)) {
        return sock.sendMessage(groupJid, {
          text: 'هذا الأمر مخصص لنخبة *${${${config.𝗔𝗥𝗖𝗘𝗡}}}* فقط. 🔒'
        }, { quoted: msg });
      }

      const metadata = await sock.groupMetadata(groupJid);
      const mentions = metadata.participants.map(p => p.id);

      const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      const quotedMsgKey = msg.message?.extendedTextMessage?.contextInfo?.stanzaId;
      const quotedParticipant = msg.message?.extendedTextMessage?.contextInfo?.participant;

      if (quoted) {
        const messageType = Object.keys(quoted)[0];

        // التعامل مع الوسائط (صور، فيديو، إلخ) بمنشن خفي
        if (['imageMessage', 'videoMessage', 'audioMessage', 'documentMessage', 'stickerMessage'].includes(messageType)) {
          const stream = await downloadMediaMessage(
            {
              key: { remoteJid: groupJid, id: quotedMsgKey, fromMe: false, participant: quotedParticipant },
              message: quoted
            },
            'buffer',
            {},
            { logger: console }
          );

          const sendObj = {
            mimetype: quoted[messageType].mimetype,
            contextInfo: { mentionedJid: mentions }, // المنشن الخفي هنا
          };

          if (messageType === 'imageMessage') sendObj.image = stream;
          else if (messageType === 'videoMessage') sendObj.video = stream;
          else if (messageType === 'audioMessage') sendObj.audio = stream;
          else if (messageType === 'documentMessage') sendObj.document = stream;
          else if (messageType === 'stickerMessage') sendObj.sticker = stream;

          return await sock.sendMessage(groupJid, sendObj, { quoted: msg });

        } else if (quoted.conversation || quoted.extendedTextMessage?.text) {
          // التعامل مع النصوص المردود عليها
          const text = quoted.conversation || quoted.extendedTextMessage.text;
          return sock.sendMessage(groupJid, {
            text: `${text}`,
            mentions
          }, { quoted: msg });

        } else {
          return sock.sendMessage(groupJid, {
            text: '⚠️ النوع المطلوب غير مدعوم في بروتوكول 𝘼𝙍𝘾.',
          }, { quoted: msg });
        }

      } else {
        // المنشن العادي في حال عدم وجود رد
        return sock.sendMessage(groupJid, {
          text: `_*ᴍᴇɴᴛɪᴏɴ ʙʏ : ᴀʀᴄ.*_`,
          mentions
        }, { quoted: msg });
      }

    } catch (err) {
      return sock.sendMessage(msg.key.remoteJid, {
        text: `❌ *خطأ في النظام:*\n\`\`\`${err.message || err.toString()}\`\`\``
      }, { quoted: msg });
    }
  }
};
