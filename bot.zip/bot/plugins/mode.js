const config = require('../config');
const fs = require('fs');
const { join } = require('path');
const { eliteNumbers } = require('../haykala/elite.js');
const { jidDecode } = require('@whiskeysockets/baileys');

const decode = jid => (jidDecode(jid)?.user || jid.split('@')[0]) + '@s.whatsapp.net';

// ========== جلب المطورين من data/devs.json ==========
function loadDevs() {
    const devsFile = join(process.cwd(), 'data', 'devs.json');
    if (!fs.existsSync(devsFile)) {
        return [];
    }
    try {
        const data = JSON.parse(fs.readFileSync(devsFile, 'utf8'));
        if (Array.isArray(data)) {
            return data;
        }
        return [];
    } catch (e) {
        return [];
    }
}

function isDev(number) {
    if (!number) return false;
    const cleanNumber = number.toString().split('@')[0];
    const devs = loadDevs();
    return devs.includes(cleanNumber);
}

module.exports = {
    command: 'مود',
    description: '🔒 تفعيل أو إيقاف وضع الصيانة (للمطورين فقط)',
    usage: '.مود',

    async execute(sock, msg) {
        try {
            const groupJid = msg.key.remoteJid;
            const sender = decode(msg.key.participant || groupJid);
            const senderLid = sender.split('@')[0];

            // ✅ التحقق من المطور
            if (!isDev(senderLid) && !eliteNumbers.includes(senderLid)) {
                return await sock.sendMessage(groupJid, { 
                    text: '🚫 هذا الأمر للمطورين فقط.' 
                }, { quoted: msg });
            }

            const modePath = join(process.cwd(), 'data', 'mode.txt');

            // ✅ قراءة الوضع الحالي
            let currentMode = 'off';
            try {
                if (fs.existsSync(modePath)) {
                    const readMode = fs.readFileSync(modePath, 'utf8').trim();
                    if (readMode === '[on]') currentMode = 'on';
                    else if (readMode === '[off]') currentMode = 'off';
                }
            } catch (err) {
                console.error('فشل قراءة وضع النخبة:', err.message);
            }

            // ✅ التبديل بين on و off
            const newMode = currentMode === 'on' ? 'off' : 'on';
            
            // ✅ حفظ الوضع الجديد
            fs.writeFileSync(modePath, `[${newMode}]`);
            
            const statusText = newMode === 'on' ? '_تم تفعيل مود الصيانة ☑️_' : '_تم تعطيل مود الصيانة ✖️_';
            
            await sock.sendMessage(groupJid, {
                text: `${statusText}`
            }, { quoted: msg });

        } catch (error) {
            console.error('❌ خطأ في أمر مود:', error);
            await sock.sendMessage(msg.key.remoteJid, {
                text: `❌ حدث خطأ أثناء تنفيذ الأمر:\n\n${error.message || error.toString()}`
            }, { quoted: msg });
        }
    },

    // ========== دالة التحقق من الصلاحية ==========
    isAllowed(senderNumber) {
        const modePath = join(process.cwd(), 'data', 'mode.txt');
        let currentMode = 'off';
        try {
            if (fs.existsSync(modePath)) {
                const readMode = fs.readFileSync(modePath, 'utf8').trim();
                if (readMode === '[on]') currentMode = 'on';
                else if (readMode === '[off]') currentMode = 'off';
            }
        } catch (err) {
            console.error('فشل قراءة وضع النخبة:', err.message);
        }

        // ✅ إذا الوضع off، الكل مسموح
        if (currentMode !== 'on') return true;
        
        // ✅ إذا الوضع on، فقط المطورين مسموح
        return isDev(senderNumber);
    }
};