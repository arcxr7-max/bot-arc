const config = require('../config');
const fs = require('fs');
const path = require('path');

module.exports = {
    command: 'move',
    category: 'control',
    description: '📦 تعديل فئة الأوامر داخلياً مع ترك حماية الوصول لنظام الصلاحيات الموحد',
    usage: '.move [الأمر1/الفئة_القديمة] [الأمر2] ... [الفئة_الجديدة]',

    async execute(sock, msg) {
        // [ARCEN-SECURITY-START]
        const senderNum = (msg.key.participant || msg.key.remoteJid).split('@')[0];
        const { isDev } = require('../utils/devs'); 
        const _fs = require('fs');
        const _path = require('path');
        const eliteFilePath = _path.join(process.cwd(), 'data', 'elite.json');
        let eliteNumbers = [];
        if (_fs.existsSync(eliteFilePath)) {
            try { eliteNumbers = JSON.parse(_fs.readFileSync(eliteFilePath, 'utf-8')).eliteNumbers || []; } catch(e){}
        }
        if (!isDev(senderNum)) return sock.sendMessage(msg.key.remoteJid, { text: '⚠️ ┋ عذراً، هذا الأمر مخصص للمطور الأساسي فقط!' }, { quoted: msg });
        // [ARCEN-SECURITY-END]
        
        
                
                
        
        
        
        
        const chatId = msg.key.remoteJid;
        const body = msg.message?.extendedTextMessage?.text || msg.message?.conversation || '';
        const args = body.trim().split(/\s+/).slice(1);

        if (args.length < 2) {
            return sock.sendMessage(chatId, { text: '💡 *الاستخدام:* \n• أمر فردي أو متعدد: `.move أمر1 أمر2 فئة_جديدة` \n• فئة كاملة: `.move فئة_قديمة فئة_جديدة`' }, { quoted: msg });
        }

        const newCat = args.pop().toLowerCase().trim();
        const targets = args.map(t => t.toLowerCase().trim());

        const pluginsDir = path.join(process.cwd(), 'plugins');
        
        let allJsFiles = fs.readdirSync(pluginsDir)
            .filter(item => item.endsWith('.js'))
            .map(item => ({
                path: path.join(pluginsDir, item),
                name: item.replace('.js', '').toLowerCase(),
                fullName: item
            }));

        function updateCategoryInsideFile(filePath, folderName) {
            try {
                let content = fs.readFileSync(filePath, 'utf-8');
                content = content.replace(/category\s*:\s*['"`][^'"`]+['"`]\s*,?\n?/gi, '');

                if (/(module\.exports\s*=\s*\{)/i.test(content)) {
                    content = content.replace(/(module\.exports\s*=\s*\{)/i, `$1\n    category: '${folderName}',`);
                } else if (/(exports\s*=\s*\{)/i.test(content)) {
                    content = content.replace(/(exports\s*=\s*\{)/i, `$1\n    category: '${folderName}',`);
                } else {
                    content = `// category: '${folderName}'\n` + content;
                }

                fs.writeFileSync(filePath, content, 'utf-8');
                return true;
            } catch (e) {
                return false;
            }
        }

        let updatedFiles = [];
        let notFoundTargets = [];

        for (const target of targets) {
            let filesToUpdate = [];

            for (const file of allJsFiles) {
                try {
                    const content = fs.readFileSync(file.path, 'utf-8');
                    const catRegex = new RegExp(`category\\s*:\\s*['"\\\`]${target}['"\\\`]`, 'i');
                    if (catRegex.test(content)) {
                        filesToUpdate.push(file);
                    }
                } catch (e) {}
            }

            if (filesToUpdate.length === 0) {
                let singleFile = allJsFiles.find(f => f.name === target || f.fullName.toLowerCase() === `${target}.js`);
                if (singleFile) {
                    filesToUpdate.push(singleFile);
                } else {
                    for (const file of allJsFiles) {
                        try {
                            const content = fs.readFileSync(file.path, 'utf-8');
                            if (content.includes(`'${target}'`) || content.includes(`"${target}"`) || content.includes(target)) {
                                filesToUpdate.push(file);
                                break;
                            }
                        } catch (e) {}
                    }
                }
            }

            if (filesToUpdate.length > 0) {
                for (const file of filesToUpdate) {
                    const success = updateCategoryInsideFile(file.path, newCat);
                    if (success && !updatedFiles.includes(file.fullName)) {
                        updatedFiles.push(file.fullName);
                    }
                }
            } else {
                notFoundTargets.push(target);
            }
        }

        let resultMsg = `*┏━🜲 𝗔𝗥𝗖𝗘𝗡 🜲━┓*\n\n`;
        resultMsg += `*╭───❒ 『 نقل الفئات 』*\n`;
        resultMsg += `*> 📦 الفئة الجديدة:* \`${newCat}\`\n`;
        resultMsg += `*> 📊 عدد الأوامر المنقولة:* \`${updatedFiles.length}\`\n`;
        resultMsg += `*╰───────────────────*\n\n`;

        if (updatedFiles.length > 0) {
            resultMsg += `*╭───❒ 『 الملفات الناجحة 』*\n`;
            updatedFiles.forEach(file => {
                resultMsg += `*- \`${file.replace('.js', '')}\`*\n`;
                resultMsg += `*> ✅ تم تحديث الكاتاغوري داخلياً بنجاح*\n\n`;
            });
            resultMsg = resultMsg.trim() + `\n*╰───────────────────*\n\n`;
        }

        if (notFoundTargets.length > 0) {
            resultMsg += `*╭───❒ 『 أخطاء العثور 』*\n`;
            notFoundTargets.forEach(target => {
                resultMsg += `*- \`${target}\`*\n`;
                resultMsg += `*> ❌ لم يتم العثور على ملف أو فئة بهذا الاسم*\n\n`;
            });
            resultMsg = resultMsg.trim() + `\n*╰───────────────────*\n\n`;
        }

        resultMsg += `*┗━🜲 𝗔𝗥𝗖𝗘𝗡 🜲━┛*`;

        await sock.sendMessage(chatId, { text: resultMsg }, { quoted: msg });
    }
};