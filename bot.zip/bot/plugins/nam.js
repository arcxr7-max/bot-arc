const config = require('../config');
const fs = require('fs');
const path = require('path');
const { isElite, extractPureNumber } = require('../haykala/elite');

module.exports = {
    category: 'control',
    command: 'nam',
    description: '📂 تغيير اسم أي ملف داخل مجلدات البوت (للنخبة فقط)',
    usage: '.nam [الاسم_القديم] الى [الاسم_الجديد]',

    async execute(sock, msg) {
        // [ARCEN-SECURITY-START]
        const senderNum = (msg.key.participant || msg.key.remoteJid).split('@')[0];
        const { isDev } = require('../utils/devs'); 
        const _fs = require('fs');
        const _path = require('path');
        const eliteFilePath = _path.join(process.cwd(), 'data', 'elite.json');
        let eliteNumbers = [];
        if (_fs.existsSync(eliteFilePath)) {
            try { eliteNumbers = JSON.parse(_fs.readFileSync(eliteFilePath, 'utf-8')).eliteNumbers || []; } catch(e){}
        }
        if (!isDev(senderNum)) return sock.sendMessage(msg.key.remoteJid, { text: '⚠️ ┋ عذراً، هذا الأمر مخصص للمطور الأساسي فقط!' }, { quoted: msg });
        // [ARCEN-SECURITY-END]
        
        
                
                
        
        
        
        
        try {
            const from = msg.key.remoteJid;
            const senderJid = msg.key.participant || msg.participant || from;
            const senderNumber = extractPureNumber(senderJid);

            // 🔒 نظام حماية النخبة المماثل لأمر كود
            if (!isElite(senderNumber)) {
                return sock.sendMessage(from, { text: '🚫 هذا الأمر مخصص للنخبة فقط.' }, { quoted: msg });
            }

            const body = msg.message?.extendedTextMessage?.text || msg.message?.conversation || '';

            // استخراج النص بعد الأمر مباشرة
            const input = body.trim().split(/\s+/).slice(1).join(' ');

            // التحقق من الصيغة (يجب أن تحتوي على كلمة "الى")
            if (!input || !input.includes(' الى ')) {
                return await sock.sendMessage(from, {
                    text: '> ⚠️ الصيغة خاطئة، اكتب الأمر هكذا: .nam القديم الى الجديد ⦿'
                }, { quoted: msg });
            }

            // فصل الاسم القديم عن الاسم الجديد
            const parts = input.split(' الى ');
            let oldName = parts[0].trim();
            let newName = parts[1].trim();

            // مسار البحث التلقائي (يبحث في المجلد الرئيسي للبوت ومجلد البلوجينز)
            const possiblePaths = [
                path.join(__dirname, oldName),
                path.join(__dirname, '../', oldName),
                path.join(__dirname, oldName + '.js'),
                path.join(__dirname, '../', oldName + '.js')
            ];

            let targetOldPath = null;
            let targetNewPath = null;

            // البحث عن مكان الملف القديم للتأكد من وجوده
            for (let p of possiblePaths) {
                if (fs.existsSync(p)) {
                    targetOldPath = p;
                    const ext = p.endsWith('.js') && !newName.endsWith('.js') ? '.js' : '';
                    targetNewPath = path.join(path.dirname(p), newName + ext);
                    break;
                }
            }

            // إذا لم يعثر النظام على الملف القديم
            if (!targetOldPath) {
                return await sock.sendMessage(from, {
                    text: `✖️ ┋ ARC-ERROR: تعذر العثور على الملف \`${oldName}\` داخل البوت.`
                }, { quoted: msg });
            }

            // تنفيذ عملية إعادة التسمية فوراً
            fs.renameSync(targetOldPath, targetNewPath);

            // القالب النهائي لرسالة النجاح
            const successMessage = 
                `─── 📂 ┋ ARC FILE MANAGER ┋ 📂 ───\n\n` +
                `*> ✅ تم تغيير اسم الملف بنجاح.*\n` +
                `*───────────────────────*\n` +
                `*> 📁 الاسم القديم: \`${path.basename(targetOldPath)}\`*\n` +
                `*> 🆕 الاسم الجديد: \`${path.basename(targetNewPath)}\`*\n` +
                `*───────────────────────*\n` +
                `*> ✨ ┋ يرجى كتابة .تحديث لتفعيل التعديل في النظام. ⦿*`;

            await sock.sendMessage(from, { text: successMessage }, { quoted: msg });

        } catch (err) {
            console.error('خطأ في تغيير اسم الملف:', err);
            await sock.sendMessage(msg.key.remoteJid, {
                text: `✖️ ┋ ARC-ERROR: فشل تعديل الاسم، تأكد من صلاحيات الملفات.\n> _${err.message || err.toString()}_`
            }, { quoted: msg });
        }
    }
};