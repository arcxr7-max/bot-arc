const fs = require('fs');
const path = require('path');

module.exports = {
category: 'control',
command: ['فتح'],
description: '📂 عرض الملفات داخل مجلد معين.',

async execute(sock, msg) {
// [ARCEN-SECURITY-START]
const senderNum = (msg.key.participant || msg.key.remoteJid).split('@')[0];
const { isDev } = require('../utils/devs');
const _fs = require('fs');
const _path = require('path');
const eliteFilePath = _path.join(process.cwd(), 'data', 'elite.json');
let eliteNumbers = [];
if (_fs.existsSync(eliteFilePath)) {
try { eliteNumbers = JSON.parse(_fs.readFileSync(eliteFilePath, 'utf-8')).eliteNumbers || []; } catch(e){}
}
// ⚠️ رسالة الحماية المحدثة والمثبتة بناءً على طلبك
if (!isDev(senderNum)) return sock.sendMessage(msg.key.remoteJid, { text: '⚠️ ┋ عذراً، هذا الأمر مخصص للمطور الأساسي فقط!' }, { quoted: msg });
// [ARCEN-SECURITY-END]

const baseDir = path.resolve('./');
const inputText = msg.message?.conversation?.split(' ').slice(1).join(' ').trim() ||
msg.message?.extendedTextMessage?.text?.split(' ').slice(1).join(' ').trim();

const folders = fs.readdirSync(baseDir).filter(f => fs.statSync(path.join(baseDir, f)).isDirectory() && !['node_modules', '.git', 'ملف_الاتصال'].includes(f));
let selectedFolder = '';

// عرض قائمة المجلدات المتاحة إذا لم يتم إدخال اسم مجلد
if (!inputText) {
const folderList = folders.map((f, i) => `│ ${i + 1}. 📁 ${f}`).join('\n');
return sock.sendMessage(msg.key.remoteJid, {
text: `📁 يرجى تحديد مجلد لفتحه:\n\n${folderList}\n\n📌 مثال: .فتح 1 أو .فتح plugins`
}, { quoted: msg });
}

if (/^\d+$/.test(inputText)) {
const index = parseInt(inputText) - 1;
if (index >= 0 && index < folders.length) selectedFolder = folders[index];
} else {
selectedFolder = folders.find(f => f.toLowerCase().includes(inputText.toLowerCase()));
}

if (!selectedFolder) return sock.sendMessage(msg.key.remoteJid, { text: `❌ لم يتم العثور على المجلد.` }, { quoted: msg });

const files = fs.readdirSync(path.join(baseDir, selectedFolder)).filter(f => f.endsWith('.js') || f.endsWith('.json'));
if (files.length === 0) return sock.sendMessage(msg.key.remoteJid, { text: '📁 لا يوجد ملفات صالحة في هذا المجلد.' }, { quoted: msg });

const fileList = files.map((f, i) => `│ ${i + 1}. 📄 ${selectedFolder}/${f}`).join('\n');
return sock.sendMessage(msg.key.remoteJid, {
text: `📄 ملفات داخل مجلد ${selectedFolder}:\n${fileList}`
}, { quoted: msg });
}
};