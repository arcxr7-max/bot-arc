// plugins/p.js
const axios = require('axios');
const cheerio = require('cheerio');
const fs = require('fs');
const path = require('path');

module.exports = {
  command: 'p',
  description: '🔍 بحث عن صورة/GIF عشوائي وإرسالها مباشرة (متوافق مع أندرويد وترمكس)',
  usage: '.p [كلمة البحث]',
  category: 'media',

  async execute(sock, message) {
    const chatId = message.key.remoteJid;

    // تفاعل فوري بالرموز التعبيرية للهيبة
    await sock.sendMessage(chatId, { react: { text: '🎴', key: message.key } });

    // قراءة النص بشكل آمن
    let fullText = '';
    if (message.message?.conversation) fullText = message.message.conversation;
    else if (message.message?.extendedTextMessage?.text) fullText = message.message.extendedTextMessage.text;
    else fullText = '';

    const query = fullText.replace(/^\.p\s/, '').trim();

    if (!query) {
      return sock.sendMessage(chatId, {
        text: '❌ اكتب كلمة البحث\n📌 مثال: `.p ناروتو`'
      }, { quoted: message });
    }

    try {
      // 1. جلب نتائج البحث من Bing (صور + GIF)
      const url = `https://www.bing.com/images/search?q=${encodeURIComponent(query)}&FORM=HDRSC2`;
      const { data } = await axios.get(url, {
        headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' },
        timeout: 10000
      });

      const $ = cheerio.load(data);
      let allMedia = [];

      $('a.iusc').each((i, el) => {
        const m = $(el).attr('m');
        if (m) {
          try {
            const meta = JSON.parse(m);
            if (meta.murl) {
              const url = meta.murl;
              const isGif = url.toLowerCase().endsWith('.gif') || (meta.ct === 'GIF');
              const width = meta.w || 0;
              const height = meta.h || 0;
              let isSquare = false;
              if (width && height && !isGif) {
                const ratio = Math.min(width, height) / Math.max(width, height);
                isSquare = ratio > 0.8;
              }
              allMedia.push({ url, isGif, isSquare });
            }
          } catch(e) {}
        }
      });

      if (allMedia.length === 0) {
        return sock.sendMessage(chatId, { text: '❌ لم يتم العثور على نتائج.' }, { quoted: message });
      }

      // 2. ترتيب عشوائي للنتائج المجلوبة
      allMedia = allMedia.sort(() => Math.random() - 0.5);
      let squareMedia = allMedia.filter(m => !m.isGif && m.isSquare);
      let finalList = squareMedia.length ? squareMedia : allMedia;
      const selected = finalList[Math.floor(Math.random() * finalList.length)];
      const mediaUrl = selected.url;
      const isGif = selected.isGif;

      // 3. تحميل الميديا كـ Buffer آمن
      const response = await axios({
        url: mediaUrl,
        method: 'GET',
        responseType: 'arraybuffer',
        timeout: 15000
      });
      const mediaBuffer = Buffer.from(response.data);

      // 4. الإرسال الذكي والمباشر لتفادي كراش Sharp بالترمكس
      if (isGif) {
        // إذا كان ملف متحرك يتم إرساله كفيديو قصير متحرك وسريع جداً في الواتساب
        return await sock.sendMessage(chatId, { 
          video: mediaBuffer, 
          gifPlayback: true,
          caption: `🎞️ النتيجة المتحركة لـ: *${query}*` 
        }, { quoted: message });
      } else {
        // إذا كانت صورة ثابتة يتم إرسالها فوراً بجودة خارقة
        return await sock.sendMessage(chatId, { 
          image: mediaBuffer, 
          caption: `🖼️ النتيجة الصورية لـ: *${query}*` 
        }, { quoted: message });
      }

    } catch (err) {
      console.error('❌ خطأ في أمر البحث:', err.message);
      await sock.sendMessage(chatId, { text: '❌ حدث خطأ داخلي أثناء استخراج الميديا.' }, { quoted: message });
    }
  }
};
