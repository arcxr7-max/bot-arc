const fs = require('fs');
const path = require('path');
const { isDev } = require('../utils/devs'); // جلب دالة فحص المطور المعتمدة عندك

module.exports = {
command: 'perm',
category: 'control',
description: '⚙️ التحكم في جدران حماية الأوامر والفئات (حقن أو حذف الحماية حياً)',
usage: '.perm cmd [الأمر] [dev/both/admin/all/del] أو .perm cat [الفئة] [dev/both/admin/all/del]',

async execute(sock, msg) {
const chatId = msg.key.remoteJid;
const sender = (msg.key.participant || msg.key.remoteJid).split('@')[0];

// 🛡️ رسالة الحماية المحدثة للمطور الأساسي فقط بناءً على طلبك
if (!isDev(sender)) {
return sock.sendMessage(chatId, { text: '⚠️ ┋ عذراً، هذا الأمر مخصص للمطور الأساسي فقط!' }, { quoted: msg });
}

const body = msg.message?.extendedTextMessage?.text || msg.message?.conversation || '';
const args = body.trim().split(/\s+/);

const permIndex = args.findIndex(arg => arg.toLowerCase().includes('perm'));
const baseIndex = permIndex !== -1 ? permIndex : 0;

const type = args[baseIndex + 1] ? args[baseIndex + 1].toLowerCase().trim() : '';      // cmd أو cat
const target = args[baseIndex + 2] ? args[baseIndex + 2].toLowerCase().trim() : '';    // اسم الأمر أو الفئة
let level = args[baseIndex + 3] ? args[baseIndex + 3].toLowerCase().trim() : '';       // dev, both, admin, all, del

// تحويل خيار الحذف 'del' إلى 'all' برمجياً لأنهما يقومان بنفس عملية تنظيف الكود
const isDeleteAction = level === 'del';
if (isDeleteAction) level = 'all';

if (!type || !target || !level || (type !== 'cmd' && type !== 'cat')) {
let helpMsg = `┏━🜲 نظام الصلاحيات المطور 🜲━┓\n`;
helpMsg += `╭───❒ 『 DIRECT PERM SYSTEM 』\n`;
helpMsg += `───────────────────────\n`;
helpMsg += `▫️ .perm cmd [الأمر] dev -> المطور فقط 🛡️\n`;
helpMsg += `▫️ .perm cmd [الأمر] both -> المطور والنخبة ⭐\n`;
helpMsg += `▫️ .perm cmd [الأمر] admin -> المشرفين والمطور 🔰\n`;
helpMsg += `▫️ .perm cmd [الأمر] del -> 🗑️ حذف الحماية نهائياً\n\n`;
helpMsg += `▫️ .perm cat [الفئة] [المستوى/del] -> لتطبيق الإجراء على فئة كاملة 📁\n`;
helpMsg += `───────────────────────\n`;
helpMsg += `┗━🜲 𝗔𝗥𝗖𝗘𝗡 🜲━┛`;
return sock.sendMessage(chatId, { text: helpMsg }, { quoted: msg });
}

const validLevels = ['dev', 'both', 'admin', 'all'];
if (!validLevels.includes(level)) {
return sock.sendMessage(chatId, { text: '❌ مستوى حماية غير صالح! اختر من: (dev, both, admin, del)' }, { quoted: msg });
}

const pluginsDir = path.join(process.cwd(), 'plugins');
if (!fs.existsSync(pluginsDir)) {
return sock.sendMessage(chatId, { text: '❌ تعذر تحديد موقع مجلد الأوامر (plugins).' }, { quoted: msg });
}

let allJsFiles = fs.readdirSync(pluginsDir).filter(item => item.endsWith('.js'));
let filesToUpdate = [];
let targetType = '';

// 🛡️ تجهيز جدار الحماية المستقل الآمن (يقرأ من مجلد data الموحد)
let protectionCode = '';
if (level !== 'all') {
protectionCode = `// [ARCEN-SECURITY-START]
const senderNum = (msg.key.participant || msg.key.remoteJid).split('@')[0];
const { isDev } = require('../utils/devs');
const _fs = require('fs');
const _path = require('path');
const eliteFilePath = _path.join(process.cwd(), 'data', 'elite.json');
let eliteNumbers = [];
if (_fs.existsSync(eliteFilePath)) {
try { eliteNumbers = JSON.parse(_fs.readFileSync(eliteFilePath, 'utf-8')).eliteNumbers || []; } catch(e){}
}
`;
if (level === 'dev') {
protectionCode += `if (!isDev(senderNum)) return sock.sendMessage(msg.key.remoteJid, { text: '⚠️ ┋ عذراً، هذا الأمر مخصص للمطور الأساسي فقط!' }, { quoted: msg });\n        `;
} else if (level === 'both') {
protectionCode += `if (!isDev(senderNum) && !eliteNumbers.includes(senderNum)) return sock.sendMessage(msg.key.remoteJid, { text: '⚠️ ┋ هذا الأمر مخصص للمطورين والنخبة فقط!' }, { quoted: msg });\n        `;
} else if (level === 'admin') {
protectionCode += `const groupMetadata = msg.key.remoteJid.endsWith('@g.us') ? await sock.groupMetadata(msg.key.remoteJid) : null;
const isAdmin = groupMetadata ? groupMetadata.participants.find(p => p.id.split('@')[0] === senderNum)?.admin : false;
if (!isDev(senderNum) && !eliteNumbers.includes(senderNum) && !isAdmin) return sock.sendMessage(msg.key.remoteJid, { text: '🛡️ ┋ هذا الأمر يتطلب صلاحيات المشرفين أو المطور أو النخبة!' }, { quoted: msg });\n        `;
}
protectionCode += `// [ARCEN-SECURITY-END]\n        `;
}

// ================= [ فحص الفئات بالكامل ] =================
if (type === 'cat') {
for (const file of allJsFiles) {
try {
const filePath = path.join(pluginsDir, file);
const content = fs.readFileSync(filePath, 'utf-8');
const catRegex = new RegExp(`category\\s*:\\s*['"\\\`]${target}['"\\\`]`, 'i');

if (catRegex.test(content)) {
filesToUpdate.push(filePath);
}
} catch (e) {}
}
targetType = `الفئة كاملة (Category: ${target}) 📁`;
}
// ================= [ فحص الأوامر الفردية ] =================
else if (type === 'cmd') {
for (const file of allJsFiles) {
try {
const filePath = path.join(pluginsDir, file);
const content = fs.readFileSync(filePath, 'utf-8');

const cmdRegex = new RegExp(`command\\s*:\\s*['"\\\`]${target}['"\\\`]`, 'i');
const arrayRegex = new RegExp(`command\\s*:\\s*\\[[^\\]]*['"\\\`]${target}['"\\\`][^\\]]*\\]`, 'i');

if (file.replace('.js', '').toLowerCase() === target || cmdRegex.test(content) || arrayRegex.test(content)) {
filesToUpdate.push(filePath);
targetType = `الأمر الفردي (.${target}) 📄`;
break;
}
} catch (e) {}
}
}

if (filesToUpdate.length === 0) {
return sock.sendMessage(chatId, { text: `❌ عذراً، لم يتم العثور على أي ملفات تطابق المستهدف (${target}).` }, { quoted: msg });
}

// 💉 تعديل الأكواد وحقن الحماية أو تنظيفها حياً
let successCount = 0;
for (const filePath of filesToUpdate) {
try {
let fileContent = fs.readFileSync(filePath, 'utf-8');

// 🪓 1. تنظيف جدار الحماية المحقون سابقاً الـ Tags تماماً
const cleanRegex = /\/\/\s\[ARCEN-SECURITY-START\][\s\S]*?\/\/\s\[ARCEN-SECURITY-END\]\n?/g;
fileContent = fileContent.replace(cleanRegex, '');

// 🪓 2. تنظيف الأكواد القديمة المتعارضة
const oldEliteRegex = /if\s*\(\s*!eliteNumbers\.includes[\s\S]*?\}\s*\}\n?/gi;
const oldDevRegex = /if\s*\(\s*!isDev[\s\S]*?\}\s*\}\n?/gi;
const oldRequireElite = /const\s*\{\s*eliteNumbers\s*\}\s*=\s*require\([\s\S]*?\);\n?/gi;

fileContent = fileContent.replace(oldEliteRegex, '').replace(oldDevRegex, '').replace(oldRequireElite, '');

// 🎯 3. إذا لم يكن الإجراء حذفاً، نقوم بحقن الحماية الجديدة
if (level !== 'all') {
const executeRegex = /(async\s+execute\s*\([\s\S]*?\)\s*\{)/i;
if (executeRegex.test(fileContent)) {
fileContent = fileContent.replace(executeRegex, `$1\n        ${protectionCode}`);
}
}

fs.writeFileSync(filePath, fileContent, 'utf-8');
successCount++;
} catch (err) {
console.error(`خطأ أثناء معالجة الملف ${filePath}:`, err);
}
}

// تحديد نص الحالة النهائي للعرض الفخم
let levelText = '';
if (isDeleteAction) {
levelText = 'تم حذف جدار الحماية والعودة للوضع الافتراضي 🗑️❌';
} else {
if (level === 'dev') levelText = 'المطور فقط ⚙️';
if (level === 'both') levelText = 'المطور والنخبة ⭐';
if (level === 'admin') levelText = 'المشرفين والمطور والنخبة 🛡️';
}

// 📊 قالب النتيجة المتناسق والمستقر
let resultMsg = `┏━🜲 نظام الصلاحيات المطور 🜲━┓\n`;
resultMsg += `╭───❒ 『 SYSTEM UPDATED 』\n`;
resultMsg += `> ⚙️ تم تعديل كود النظام بنجاح وتحديث جدار الحماية! \n`;
resultMsg += `───────────────────────\n`;
resultMsg += `- \`المستهدف:\` ${targetType}\n`;
resultMsg += `- \`الحالة الجديدة:\` ${levelText}\n`;
resultMsg += `- \`الملفات المحدثة:\` ${successCount} ملف\n`;
resultMsg += `───────────────────────\n`;
resultMsg += `> 💡 تم إجراء التعديل حياً، يرجى كتابة .تحديث لتفعيل الخيارات. ⦿\n`;
resultMsg += `╰──────────────\n`;
resultMsg += `┗━🜲 𝗔𝗥𝗖𝗘𝗡 🜲━┛`;

await sock.sendMessage(chatId, { text: resultMsg }, { quoted: msg });
}
};