const fs = require('fs');
const path = require('path');
const { isDev } = require('../utils/devs');
const { isElite } = require('../haykala/elite');

const configPath = path.join(__dirname, '../config.js');

// قراءة الكونفغ الحالي بأمان لتجنب التكرار
let currentConfig = {};
try {
    currentConfig = require('../config.js');
} catch(e) {
    currentConfig = { botName: '𝗔𝗥𝗖𝗘𝗡', prefix: '.', defaultPrefix: '.' };
}

module.exports = {
  command: 'بريفكس',
  description: '🔧 تغيير البريفكس الخاص بالأوامر (للمطورين والنخبة فقط)',
  usage: '.بريفكس [الرمز الجديد]',
  category: 'control',

  async execute(sock, msg) {
    const chatId = msg.key.remoteJid;
    const senderJid = msg.key.participant || msg.key.remoteJid;
    const sender = senderJid.split('@')[0];

    // ✅ التحقق من الصلاحيات
    if (!isDev(sender) && !isElite(sender)) {
      return sock.sendMessage(chatId, {
        text: '🚫 هذا الأمر متاح فقط للمطورين والنخبة'
      }, { quoted: msg });
    }

    // قراءة النص
    let fullText = '';
    if (msg.message?.conversation) fullText = msg.message.conversation;
    else if (msg.message?.extendedTextMessage?.text) fullText = msg.message.extendedTextMessage.text;

    // ✅ استخراج النص بعد الأمر
    const withoutCommand = fullText.replace(/^\.بريفكس\s*/, '').trim();
    
    // عرض البريفكس الحالي
    if (!withoutCommand) {
      const currentPrefix = currentConfig.prefix || currentConfig.defaultPrefix || '.';
      const display = currentPrefix === '' ? '(فارغ)' : currentPrefix;
      return sock.sendMessage(chatId, {
        text: `🔧 البريفكس الحالي لـ *${currentConfig.botName || 'البوت'}* هو: *${display}*\n\nاستخدم:\n.بريفكس [الرمز]\nمثال: .بريفكس /\n\n.بريفكس فارغ (لإزالته)`
      }, { quoted: msg });
    }

    // ✅ معالجة حالة "فارغ"
    if (withoutCommand === 'فارغ') {
      const updatedContent = `module.exports = {
    botName: '${currentConfig.botName || '𝗔𝗥𝗖𝗘𝗡'}',
    version: '${currentConfig.version || '2.5.0'}',
    owner: '${currentConfig.owner || '212612969896', '270527776174265'}',

    defaultPrefix: '.',
    prefix: '',

    allowedGroups: [],

    messages: {
        error: '❌ حدث خطأ أثناء تنفيذ الأمر',
        noPermission: 'ليس لديك صلاحية لاستخدام هذا الأمر',
        groupOnly: 'هذا الأمر متاح فقط في المجموعات',
        ownerOnly: 'هذا الأمر متاح فقط للنخبة',
        notAllowedGroup: 'عذراً، البوت لا يعمل في هذه المجموعة'
    },

    colors: {
        success: '\\\\x1b[32m',
        error: '\\\\x1b[31m',
        info: '\\\\x1b[36m',
        warn: '\\\\x1b[33m',
        reset: '\\\\x1b[0m'
    }
};`;
      fs.writeFileSync(configPath, updatedContent, 'utf8');
      currentConfig.prefix = '';
      
      return sock.sendMessage(chatId, {
        text: `✅ تم إزالة البريفكس بنجاح\n⚠️ يرجى كتابة *.تحديث* لتفعيل التغيير حياً.`
      }, { quoted: msg });
    }

    // ✅ أخذ آخر حرف فقط من النص كبريفكس جديد
    const newPrefix = withoutCommand.charAt(withoutCommand.length - 1);
    
    // تحذير إذا كان هناك أكثر من حرف
    if (withoutCommand.length > 1) {
      await sock.sendMessage(chatId, {
        text: `⚠️ تم استخدام آخر حرف: *${newPrefix}* (تجاهل "${withoutCommand.slice(0, -1)}")`
      }, { quoted: msg });
    }

    // تحديث البريفكس في ملف config الصحيح والثابت
    const updatedContent = `module.exports = {
    botName: '${currentConfig.botName || '𝗔𝗥𝗖𝗘𝗡'}',
    version: '${currentConfig.version || '2.5.0'}',
    owner: '${currentConfig.owner || '212612969896', '270527776174265'}',

    defaultPrefix: '.',
    prefix: '${newPrefix}',

    allowedGroups: [],

    messages: {
        error: '❌ حدث خطأ أثناء تنفيذ الأمر',
        noPermission: 'ليس لديك صلاحية لاستخدام هذا الأمر',
        groupOnly: 'هذا الأمر متاح فقط في المجموعات',
        ownerOnly: 'هذا الأمر متاح فقط للنخبة',
        notAllowedGroup: 'عذراً، البوت لا يعمل في هذه المجموعة'
    },

    colors: {
        success: '\\\\x1b[32m',
        error: '\\\\x1b[31m',
        info: '\\\\x1b[36m',
        warn: '\\\\x1b[33m',
        reset: '\\\\x1b[0m'
    }
};`;

    fs.writeFileSync(configPath, updatedContent, 'utf8');
    currentConfig.prefix = newPrefix;

    await sock.sendMessage(chatId, {
      text: `✅ تم تغيير البريفكس بنجاح إلى *${newPrefix}*\n💡 اكتب *.تحديث* الآن لتفعيله حياً.`
    }, { quoted: msg });
  }
};