const config = require('../config');
module.exports = {
    command: 'm',
    description: '📝 استخراج وقراءة النص الكامل من الروابط مع تنظيف شامل',
    usage: '.m [رابط الموقع]',

    async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
                const from = msg.key.remoteJid;
        const body = msg.message?.extendedTextMessage?.text || msg.message?.conversation || '';
        const args = body.trim().split(/\s+/).slice(1);
        const url = args[0];

        // التنبيه المباشر والمعدل على طريقتك وبدون عناوين
        if (!url || (!url.startsWith('http://') && !url.startsWith('https://'))) {
            return await sock.sendMessage(from, {
                text: '> *⚠️ اكتب الرابط هكذا: .m + الرابط ⦿*'
            }, { quoted: msg });
        }

        try {
            // استخدام خادم القراءة لجلب النص
            const readerUrl = `https://r.jina.ai/${encodeURIComponent(url)}`;
            
            const res = await fetch(readerUrl, {
                headers: { 'Accept': 'application/json' }
            });

            if (!res.ok) {
                return await sock.sendMessage(from, {
                    text: '*✖️ ┋ ARC-ERROR:* عذراً، لم أتمكن من قراءة محتويات هذا الرابط حالياً.'
                }, { quoted: msg });
            }

            const data = await res.json();
            
            const title = data.data?.title || 'مقال غير معنون';
            let content = data.data?.content || data.data?.description || '';

            if (!content || content.length < 20) {
                return await sock.sendMessage(from, {
                    text: '*✖️ ┋ ARC-ERROR:* الرابط لا يحتوي على نصوص مقروءة كافية.'
                }, { quoted: msg });
            }

            // === 🛠️ نظام تنظيف النصوص المطور (ARC ADVANCED CLEANER) 🛠️ ===
            let cleanContent = content
                // 1. إزالة الروابط المخفية خلف الكلمات المكتوبة بصيغة [الكلمة](الرابط)
                .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
                // 2. إزالة أي روابط عادية تبدأ بـ http أو https ومحاطة بأقواس
                .replace(/\((http|https):\/\/[^\s)]+\)/g, '')
                // 3. تنظيف مراجع الويب المعقدة وأكواد الهوامش المخرومة
                .replace(/\[\]\(#cite_note[^)]+\)/g, '')
                .replace(/#cite_note[^\s)]+/g, '')
                .replace(/#cite_ref[^\s)]+/g, '')
                // 4. مسح مخلفات النصوص المرمزة بالنسبة المئوية والأرقام والحروف التابعة للمراجع
                .replace(/%[A-F0-9]{2}/g, '')
                .replace(/\^[#a-zA-Z0-9_-]+/g, '')
                // 5. مسح الأقواس المربعة والدائرية الفارغة الناتجة عن التصفية
                .replace(/\[\s*\]/g, '')
                .replace(/\(\s*\)/g, '')
                // 6. مسح أرقام المراجع البسيطة مثل [1] و [2]
                .replace(/\[\d+\]/g, '');

            // القالب النهائي الفخم
            const finalMessage = 
`*─── 📝 ┋ ARC WEB READER ┋ 📝 ───*

> *📌 العنوان:* ${title}
*───────────────────────*

${cleanContent.trim()}

*───────────────────────*
> *✨ ┋ تم استخراج النص الصافي كاملاً بواسطة نظام ARC. ⦿*`;

            // إرسال النص النقي بالكامل
            await sock.sendMessage(from, { text: finalMessage }, { quoted: msg });

        } catch (err) {
            console.error('خطأ في قارئ ARC:', err);
            await sock.sendMessage(from, {
                text: '*✖️ ┋ ARC-ERROR:* واجه النظام مشكلة أثناء محاولة معالجة وتصفية الرابط.'
            }, { quoted: msg });
        }
    }
};