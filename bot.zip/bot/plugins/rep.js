const fs = require('fs');
const path = require('path');

module.exports = {
    command: ['rep'],
    category: 'control',
    description: '🔄 استبدال نصوص الأوامر حياً وبشكل مباشر لجميع المستخدمين',
    usage: '.rep [القديم] [الجديد]',
  
    async execute(sock, msg) {
        // [ARCEN-SECURITY-START]
        const senderNum = (msg.key.participant || msg.key.remoteJid).split('@')[0];
        const { isDev } = require('../utils/devs'); 
        const _fs = require('fs');
        const _path = require('path');
        const eliteFilePath = _path.join(process.cwd(), 'data', 'elite.json');
        let eliteNumbers = [];
        if (_fs.existsSync(eliteFilePath)) {
            try { eliteNumbers = JSON.parse(_fs.readFileSync(eliteFilePath, 'utf-8')).eliteNumbers || []; } catch(e){}
        }
        if (!isDev(senderNum)) return sock.sendMessage(msg.key.remoteJid, { text: '⚠️ ┋ عذراً، هذا الأمر مخصص للمطور الأساسي فقط!' }, { quoted: msg });
        // [ARCEN-SECURITY-END]
        
        const chatId = msg.key.remoteJid;

        const body = msg.message?.extendedTextMessage?.text || msg.message?.conversation || '';
        const args = body.trim().split(/\s+/);
        
        let oldText = args[1];
        let newText = args[2];

        if (!oldText || !newText) {
            return sock.sendMessage(chatId, { text: '⚠️ الاستخدام: `.rep [القديم] [الجديد]`' }, { quoted: msg });
        }

        // تحويل تلقائي ذكي لضمان الحقن الصحيح للمتغير داخل النصوص
        if (newText === '𝗔𝗥𝗖𝗘𝗡') {
            newText = '${${${${config.𝗔𝗥𝗖𝗘𝗡}}}}';
        }

        await sock.sendMessage(chatId, { react: { text: '🔄', key: msg.key } }).catch(() => {});

        const pluginsDir = path.join(process.cwd(), 'plugins');
        try {
            const files = fs.readdirSync(pluginsDir).filter(f => f.endsWith('.js'));
            let updatedCount = 0;

            for (const file of files) {
                const filePath = path.join(pluginsDir, file);
                let content = fs.readFileSync(filePath, 'utf-8');

                if (content.includes(oldText)) {
                    // استبدال النص القديم بالنص الجديد مباشرة
                    content = content.replace(new RegExp(oldText, 'g'), newText);
                    fs.writeFileSync(filePath, content, 'utf-8');
                    updatedCount++;
                }
            }

            await sock.sendMessage(chatId, { 
                text: `✅ *تم الاستبدال بنجاح في:* \`${updatedCount} ملف\`\n💡 *اكتب الآن:* \`.تحديث\` لتفعيل الهوية.` 
            }, { quoted: msg });

        } catch (error) {
            await sock.sendMessage(chatId, { text: `❌ خطأ: ${error.message}` }, { quoted: msg });
        }
    }
};