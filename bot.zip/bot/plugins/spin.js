const config = require('../config');
const fs = require('fs');
const path = require('path');

// مسار ملفات التخزين
const pointsFile = path.join(__dirname, '../data/points.json');
const cooldownFile = path.join(__dirname, '../data/lastSpin.json');

// الوقت بين كل أمر وساعة (5400000 مللي ثانية = ساعة ونصف)
const COOLDOWN_TIME = 300000; // خمس دقايق 

// قائمة الجوائز (من 10 إلى 5000)
const PRIZES = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 200, 300, 400, 500, 600, 700, 800, 900, 1000, 2000, 3000, 4000, 5000];

// وزن كل جائزة (كلما زاد الوزن، زادت نسبة الظهور)
const getWeight = (value) => {
    if (value <= 100) return 10;   // شائعة
    if (value <= 500) return 5;    // نادرة
    if (value <= 1000) return 2;   // نادرة جداً
    return 1;                       // أسطورية
};

// إيموجي الندرة
const getRarityEmoji = (value) => {
    if (value >= 2000) return '🔥';
    if (value >= 600) return '🟣';
    if (value >= 200) return '🔵';
    return '🟢';
};

// اختيار جائزة عشوائية حسب الوزن
function getRandomPrize() {
    // بناء مصفوفة مرجحة
    let weightedPrizes = [];
    for (const prize of PRIZES) {
        const weight = getWeight(prize);
        for (let i = 0; i < weight; i++) {
            weightedPrizes.push(prize);
        }
    }
    return weightedPrizes[Math.floor(Math.random() * weightedPrizes.length)];
}

// دوال النقاط
function getPoints() {
    if (!fs.existsSync(pointsFile)) return {};
    return JSON.parse(fs.readFileSync(pointsFile, 'utf8'));
}

function savePoints(points) {
    fs.writeFileSync(pointsFile, JSON.stringify(points, null, 2), 'utf8');
}

// دوال وقت التهدئة
function getLastSpin() {
    if (!fs.existsSync(cooldownFile)) return {};
    return JSON.parse(fs.readFileSync(cooldownFile, 'utf8'));
}

function saveLastSpin(data) {
    fs.writeFileSync(cooldownFile, JSON.stringify(data, null, 2), 'utf8');
}

// دالة حساب الوقت المتبقي
function getRemainingTime(lastTime) {
    const now = Date.now();
    const diff = lastTime + COOLDOWN_TIME - now;
    if (diff <= 0) return null;
    const hours = Math.floor(diff / 3600000);
    const minutes = Math.floor((diff % 3600000) / 60000);
    const seconds = Math.floor((diff % 60000) / 1000);
    return `${hours > 0 ? hours + ' ساعة ' : ''}${minutes > 0 ? minutes + ' دقيقة ' : ''}${seconds} ثانية`;
}

// النص الذي يظهر مع الجائزة
const WIN_TEXT = 'ربحت';

module.exports = {
    command: 'لف',
    description: '🎡 جرب حظك واكسب نقاط (مرة كل ساعة ونص)',
    usage: '.لف',
    category: 'game',

    async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
                const chatId = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;
        const senderNumber = sender.split('@')[0];

        // ✅ تفاعل فوري على رسالة المستخدم 🎡
        await sock.sendMessage(chatId, {
            react: { text: '🎡', key: msg.key }
        }).catch(() => {});

        // ⏰ التحقق من وقت التهدئة
        let lastSpin = getLastSpin();
        const lastTime = lastSpin[senderNumber] || 0;
        
        if (lastTime && (Date.now() - lastTime) < COOLDOWN_TIME) {
            const remaining = getRemainingTime(lastTime);
            return sock.sendMessage(chatId, {
                text: `⏳ استنى ${remaining} قبل ما تستخدم .لف مرة ثانية`
            }, { quoted: msg });
        }

        // 🎁 اختيار جائزة عشوائية
        const prizeValue = getRandomPrize();
        const rarityEmoji = getRarityEmoji(prizeValue);
        
        // تحديث النقاط
        let points = getPoints();
        points[senderNumber] = (points[senderNumber] || 0) + prizeValue;
        savePoints(points);
        
        // تحديث وقت آخر لف
        lastSpin[senderNumber] = Date.now();
        saveLastSpin(lastSpin);
        
        // تحديد نوع الجائزة للرسالة
        let message = '';
        if (prizeValue >= 2000) {
            message = `🔥🎉 *جائزة أسطورية!* 🎉🔥\n${WIN_TEXT} ${prizeValue} 💸`;
        } else if (prizeValue >= 600) {
            message = `${rarityEmoji} *جائزة نادرة جداً!*\n${WIN_TEXT} ${prizeValue} 💸`;
        } else if (prizeValue >= 200) {
            message = `${rarityEmoji} ${WIN_TEXT} ${prizeValue} 💸`;
        } else {
            message = `${WIN_TEXT} ${prizeValue} 💸`;
        }
        
        await sock.sendMessage(chatId, { text: message }, { quoted: msg });
    }
};