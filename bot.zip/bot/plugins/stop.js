// plugins/stop.js
const fs = require('fs');
const path = require('path');

// ========== التحقق من المطور ==========
function isDev(number) {
    const devsFile = path.join(__dirname, '../data/devs.json');
    if (!fs.existsSync(devsFile)) return false;
    const devs = JSON.parse(fs.readFileSync(devsFile, 'utf8'));
    return devs.includes(number);
}

module.exports = {
    command: 'وقف',
    category: 'system',
    description: '⛔ إيقاف تشغيل البوت نهائياً (للمطورين فقط)',
    usage: '.وقف',
    
    async execute(sock, msg) {
        const from = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;
        const senderNumber = sender.split('@')[0];

        // ✅ التحقق من المطور
        if (!isDev(senderNumber)) {
            return sock.sendMessage(from, {
                text: '🚫 هذا الأمر للمطورين فقط.'
            }, { quoted: msg });
        }

        // ✅ تأكيد الإيقاف
        await sock.sendMessage(from, {
            text: `𝘿𝙤𝙣'𝙩 𝙬𝙤𝙧𝙧𝙮, 𝙄'𝙫𝙚 𝙗𝙚𝙚𝙣 𝙨𝙪𝙘𝙘𝙚𝙨𝙨𝙛𝙪𝙡𝙡𝙮 𝙩𝙪𝙧𝙣𝙚𝙙 𝙤𝙛𝙛. 🫦`
        }, { quoted: msg });

        // ✅ إيقاف البوت حقيقياً
        setTimeout(() => {
            console.log('');
            process.exit(0);
        }, 2000);
    }
};