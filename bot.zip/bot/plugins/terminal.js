const cp = require('child_process');
const { promisify } = require('util');
const { isElite } = require('../haykala/elite.js');
const { jidDecode } = require('@whiskeysockets/baileys');

const exec = promisify(cp.exec).bind(cp);
const decode = jid => (jidDecode(jid)?.user || jid.split('@')[0]) + '@s.whatsapp.net';

module.exports = {
category: 'control',
command: ['$'],
description: '💻 تشغيل أوامر الترمينال مع تعديل الرسالة تلقائياً.',

async execute(sock, msg) {
try {
const groupId = msg.key.remoteJid;
const sender = decode(msg.key.participant || groupId);
const senderLid = sender.split('@')[0];

// 🛡️ فحص الصلاحية
if (!isElite(senderLid)) {
return await sock.sendMessage(groupId, {
text: '❌ ليس لديك صلاحية لاستخدام أمر الترمينال المخفي.'
}, { quoted: msg });
}

// جلب النص الكامل للرسالة
const body = msg.message?.extendedTextMessage?.text ||
msg.message?.conversation || '';

// تقسيم النص لأخذ الأمر النقي
const args = body.trim().split(/ +/);
const cleanText = args.slice(1).join(' ');

// إذا أرسلت الرمز فارغاً
if (!cleanText) {
return await sock.sendMessage(groupId, {
text: '⚠️ يرجى كتابة الأمر المراد تنفيذه داخل السيرفر.\n\n💡 أمثلة:\n ⟸ `.$ ls`\n ⟸ `.$ node -v` \n ⟸ `.$ pm2 status`'
}, { quoted: msg });
}

// 1️⃣ إرسال رسالة الانتظار الأولى وحفظ بياناتها في متغير لكي نقوم بتعديلها لاحقاً
const initialResult = await sock.sendMessage(groupId, {
text: '⚙️ جاري التنفيذ داخل ترمينال السيرفر...'
}, { quoted: msg });

let o;
try {
// تشغيل الأمر النقي في الترمينال
o = await exec(cleanText);
} catch (e) {
o = e;
} finally {
const { stdout, stderr } = o;
let finalResponse = '';

// تجميع النتيجة النهائية في نص واحد
if (stdout && stdout.trim()) {
finalResponse += stdout.trim();
}
if (stderr && stderr.trim()) {
finalResponse += `\n\n❌ خطأ من النظام:\n${stderr.trim()}`;
}

// إذا لم يخرج الأمر أي نص (مثل أوامر الإنشاء الصامتة)
if (!finalResponse.trim()) {
finalResponse = '✅ تم تنفيذ الأمر بنجاح بدون مخرجات نصية.';
}

// 2️⃣ التعديل السحري: تعديل رسالة الانتظار القديمة لتصبح هي النتيجة مباشرة
await sock.sendMessage(groupId, {
text: finalResponse,
edit: initialResult.key // تمرير مفتاح الرسالة الأولى ليتم استبدالها
});
}

} catch (error) {
console.error('✗ خطأ في أمر الترمينال:', error);
await sock.sendMessage(msg.key.remoteJid, {
text: `❌ حدث خطأ غير متوقع أثناء المعالجة:\n\n${error.message || error.toString()}`
}, { quoted: msg });
}
}
};