module.exports = {
  command: 'تست',
  description: '⚙️ اختبار أداء البوت',
  usage: '.تست',
  category: 'tools',

  async execute(sock, msg) {
    try {
      let botProfilePic;
      try {
        botProfilePic = await sock.profilePictureUrl(sock.user.id, 'image');
      } catch {
        botProfilePic = 'https://i.imgur.com/8TnZ4Rv.png';
      }

      const messageText = `
 *𝗔𝗥𝗖𝗘𝗡*
━━━━━━━━━━━━━━
✅ *Online*
⚡ *Power: MAX*
🆔 *ID:* ${sock.user.id}
━━━━━━━━━━━━━━
_I'm here..._
      `.trim();

      const message = {
        text: messageText,
        mentions: [msg.sender],
        contextInfo: {
          mentionedJid: [msg.sender],
          externalAdReply: {
            title: "𝗔𝗥𝗖𝗘𝗡",
            body: "⚡ Ready for action.",
            thumbnailUrl: botProfilePic,
            sourceUrl: `https://wa.me/201028489465`,
            mediaType: 1,
            renderLargerThumbnail: true
          }
        }
      };

      await sock.sendMessage(msg.key.remoteJid, message, { quoted: msg });

    } catch (error) {
      console.error('❌ Test Command Error:', error);
      await sock.sendMessage(msg.key.remoteJid, {
        text: '⚠️ حدث خطأ أثناء تنفيذ الأمر.',
      }, { quoted: msg });
    }
  }
};