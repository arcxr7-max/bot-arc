const { jidDecode } = require('@whiskeysockets/baileys');

module.exports = {
  command: 'تست',
  description: '⚙️ اختبار أداء البوت',
  usage: '.تست',
  category: 'tools',

  async execute(sock, msg) {
    try {
      const from = msg.key.remoteJid;
      const sender = msg.participant || msg.key.participant || msg.key.remoteJid;

      // تنظيف معرّف البوت لاستخراج صورة البروفايل بدون مشاكل :44
      const botJid = (sock.user && sock.user.id) 
        ? (jidDecode(sock.user.id)?.user || sock.user.id.split('@')[0]) + '@s.whatsapp.net' 
        : sock.user.id;

      let botProfilePic = 'https://i.imgur.com/8TnZ4Rv.png';
      try {
        const pfp = await sock.profilePictureUrl(botJid, 'image');
        if (pfp) botProfilePic = pfp;
      } catch (e) {
        // استخدام الصورة الافتراضية عند الفشل
      }

      const messageText = `
 𝗔𝗥𝗖𝗘𝗡
━━━━━━━━━━━━━━
✅ Online
⚡ Power: MAX
🆔 ID: ${sock.user.id}
━━━━━━━━━━━━━━
_I'm here..._
      `.trim();

      const message = {
        text: messageText,
        mentions: [sender],
        contextInfo: {
          mentionedJid: [sender],
          externalAdReply: {
            title: "𝗔𝗥𝗖𝗘𝗡",
            body: "ɪ'ᴍ ʜᴇʀᴇ",
            thumbnailUrl: botProfilePic,
            sourceUrl: "https://wa.me/201028489465",
            mediaType: 1,
            renderLargerThumbnail: true,
            showAdAttribution: true
          }
        }
      };

      await sock.sendMessage(from, message, { quoted: msg });

    } catch (error) {
      console.error('❌ Test Command Error:', error);
      await sock.sendMessage(msg.key.remoteJid, {
        text: '⚠️ حدث خطأ أثناء تنفيذ الأمر.',
      }, { quoted: msg });
    }
  }
};
