const config = require('../config');
const fs = require('fs');
const path = require('path');

const pointsFile = path.join(__dirname, '../data/points.json');
const accountsFile = path.join(__dirname, '../data/bankAccounts.json');

function loadPoints() {
    if (!fs.existsSync(pointsFile)) return {};
    return JSON.parse(fs.readFileSync(pointsFile, 'utf8'));
}

function savePoints(data) {
    fs.writeFileSync(pointsFile, JSON.stringify(data, null, 2));
}

function loadAccounts() {
    if (!fs.existsSync(accountsFile)) return {};
    return JSON.parse(fs.readFileSync(accountsFile, 'utf8'));
}

module.exports = {
    command: 'تحويل',
    description: '💸 تحويل نقود عبر رقم الحساب البنكي',
    usage: '.تحويل [المبلغ] [رقم الحساب]',
    category: 'bank',

    async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
                try {
            const chatId = msg.key.remoteJid;
            const sender = msg.key.participant || msg.key.remoteJid;
            const senderNumber = sender.split('@')[0];

            // ✅ قراءة النص مباشرة من الرسالة
            let fullText = '';
            if (msg.message?.conversation) fullText = msg.message.conversation;
            else if (msg.message?.extendedTextMessage?.text) fullText = msg.message.extendedTextMessage.text;
            else return;

            // ✅ إزالة الأمر .تحويل والحصول على المبلغ ورقم الحساب
            const withoutCommand = fullText.replace(/^\.تحويل\s*/, '').trim();
            const parts = withoutCommand.split(/\s+/);
            
            const amount = parseInt(parts[0]);
            const targetAccountNumber = parts[1];

            // ✅ التحقق من وجود المبلغ ورقم الحساب
            if (!parts[0] || isNaN(amount) || amount <= 0) {
                return sock.sendMessage(chatId, {
                    text: '❌ استخدم: .تحويل [المبلغ] [رقم الحساب]\nمثال: .تحويل 999 5810172522'
                }, { quoted: msg });
            }

            if (!parts[1]) {
                return sock.sendMessage(chatId, {
                    text: '❌ رقم الحساب مطلوب\nمثال: .تحويل 999 5810172522'
                }, { quoted: msg });
            }

            // ✅ البحث عن المستخدم صاحب رقم الحساب
            const accounts = loadAccounts();
            let targetUser = null;
            let targetNumber = null;

            for (const [num, acc] of Object.entries(accounts)) {
                if (acc.accountNumber == targetAccountNumber) {
                    targetUser = acc;
                    targetNumber = num;
                    break;
                }
            }

            if (!targetUser) {
                return sock.sendMessage(chatId, {
                    text: `❌ رقم الحساب ${targetAccountNumber} غير موجود`
                }, { quoted: msg });
            }

            // ✅ منع التحويل للنفس
            if (targetNumber === senderNumber) {
                return sock.sendMessage(chatId, {
                    text: '❌ لا يمكنك التحويل لحسابك الخاص'
                }, { quoted: msg });
            }

            // ✅ التحقق من الرصيد
            let points = loadPoints();
            const senderBalance = points[senderNumber] || 0;

            if (senderBalance < amount) {
                return sock.sendMessage(chatId, {
                    text: `❌ رصيدك غير كافٍ! رصيدك: ${senderBalance} نقطة`
                }, { quoted: msg });
            }

            // ✅ تنفيذ التحويل
            points[senderNumber] = senderBalance - amount;
            points[targetNumber] = (points[targetNumber] || 0) + amount;
            savePoints(points);

            await sock.sendMessage(chatId, {
                text: `✅ تم تحويل ${amount} نقطة إلى الحساب ${targetAccountNumber}`
            }, { quoted: msg });

        } catch (error) {
            console.error('❌ خطأ:', error);
            await sock.sendMessage(msg.key.remoteJid, {
                text: '❌ حدث خطأ أثناء التحويل'
            }, { quoted: msg });
        }
    }
};