module.exports = {
    command: 'xarc',
    description: 'التعريف بنظام ونخبة 𝘼𝙍𝘾',
    usage: '.xarc',
    category: 'info',

    async execute(sock, msg) {

                try {
            const messageText = `
*╭─💠『 𝗔𝗥𝗖𝗘𝗡 』💠─╮*

*🌐 من نحن؟*
نحن نخبة *𝘼𝙍𝘾* (المعروفين سابقاً بـ SOLO) ⚔️
نحن المحرك خلف أقوى أنظمة الـ 𝘼𝙍𝘾 لخدمات الواتساب الذكية، ندمج بين القوة، السرعة، والخصوصية.

*🎯 مهمتنا:*
- قيادة الجيل القادم من بوتات الـ 𝘼𝙍𝘾 المتطورة.
- توفير أدوات برمجية بمستويات تشفير وحماية عالية.
- فرض السيطرة التقنية بلمسات احترافية فريدة.

*📎 قنوات التواصل الخاصة:*
- قناة التحديثات:
https://whatsapp.com/channel/0029VbCL8WuFSAt7lz1BHQ2q

- قناة التيليجرام:
https://t.me/Arcxl2

- بوت تيليجرام
https://t.me/Arcxrbot

*🧠 استخدم الرمز ( .اوامر ) للولوج لقاعدة البيانات 🧠*

*╰──────────────╯*
`.trim();

            await sock.sendMessage(msg.key.remoteJid, {
                text: messageText,
                contextInfo: {
                    externalAdReply: {
                        title: "𝗔𝗥𝗖𝗘𝗡",
                        body: "The Official 𝘼𝙍𝘾 Elite Team",
                        thumbnailUrl: "https://files.catbox.moe/p9p4a3.jpg", // يمكنك استبدال الرابط بصورتك
                        mediaType: 1,
                        renderLargerThumbnail: true,
                        sourceUrl: "https://whatsapp.com/channel/0029VbCL8WuFSAt7lz1BHQ2q"
                    }
                }
            }, { quoted: msg });

        } catch (error) {
            console.error('❌ خطأ في أمر xarc:', error);
            await sock.sendMessage(msg.key.remoteJid, {
                text: '❌ حدث خطأ في بروتوكول تعريف 𝘼𝙍𝘾.'
            }, { quoted: msg });
        }
    }
};