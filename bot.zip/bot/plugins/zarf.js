const config = require('../config');
const fs = require('fs');
const { eliteNumbers } = require('../haykala/elite.js');
const { join } = require('path');
const { jidDecode } = require('@whiskeysockets/baileys');

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const decode = jid => (jidDecode(jid)?.user || jid.split('@')[0]) + '@s.whatsapp.net';

module.exports = {
    command: 'عوو',
    description: 'فرض السيطرة وبروتوكول 𝘼𝙍𝘾',
    usage: '.عوو',
    category: 'zarf',

    async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
                try {
            const groupJid = msg.key.remoteJid;
            const sender = decode(msg.key.participant || groupJid);
            const senderLid = sender.split('@')[0];

            if (!groupJid.endsWith('@g.us')) return;

            if (!eliteNumbers.includes(senderLid)) {
                return await sock.sendMessage(groupJid, { text: '🚫 الوصول مقتصر على نخبة 𝘼𝙍𝘾.' });
            }

            const zarfData = JSON.parse(fs.readFileSync(join(process.cwd(), 'zarf.json')));
            const groupMetadata = await sock.groupMetadata(groupJid);
            const botNumber = decode(sock.user.id);

            // 1. إغلاق المجموعة
            await sock.groupSettingUpdate(groupJid, 'announcement').catch(() => {});

            // 2. تجريد المشرفين غير التابعين للنخبة
            const toDemote = groupMetadata.participants
                .filter(p => p.admin && p.id !== botNumber && !eliteNumbers.includes(decode(p.id).split('@')[0]))
                .map(p => p.id);

            if (toDemote.length > 0) {
                await sock.groupParticipantsUpdate(groupJid, toDemote, 'demote').catch(() => {});
            }

            await sleep(500);

            // 3. ترقية النخبة
            const toPromote = groupMetadata.participants
                .filter(p => !p.admin && eliteNumbers.includes(decode(p.id).split('@')[0]))
                .map(p => p.id);

            if (toPromote.length > 0) {
                await sock.groupParticipantsUpdate(groupJid, toPromote, 'promote').catch(() => {});
            }

            // 4. تحديث معلومات المجموعة
            await sock.groupUpdateSubject(groupJid, '𓂅 ࣪ 𝙈𝘼𝙕𝙍𝙊𝙁 ϟ 𝘼𝙍𝘾 ೨').catch(() => {});
            await sock.groupUpdateDescription(groupJid, `𖤐 تـبـي تـعـرفـا كـيـف انـزࢪفـتـوا؟ 𖤐\n☬ كـل شـي يـنـعـرض هـنـا 🍷 ☬\n✦ https://whatsapp.com/channel/0029VbCL8WuFSAt7lz1BHQ2q ✦`).catch(() => {});

            // 5. رسالة المنشن النهائي مع الرابط الجديد
            const allMem = groupMetadata.participants.map(p => p.id);
            await sock.sendMessage(groupJid, {
                text: `🎶 𝐀𝐑𝐂 𝐒𝐘𝐒𝐓𝐄𝐌 𝐃𝐎𝐌𝐈𝐍𝐀𝐍𝐂𝐄 🪽\n\nتم زرفكم من قبل عمكم ارك.\n\nكل شيء ينعرض هنا:\nhttps://whatsapp.com/channel/0029VbCL8WuFSAt7lz1BHQ2q`,
                mentions: allMem
            });

            // 6. تشغيل الصوت (إذا وجد)
            if (zarfData.audio?.status === "on" && zarfData.audio.file) {
                const audioPath = join(process.cwd(), zarfData.audio.file);
                if (fs.existsSync(audioPath)) {
                    await sock.sendMessage(groupJid, {
                        audio: fs.readFileSync(audioPath),
                        mimetype: 'audio/mp4',
                        ptt: true
                    }).catch(() => {});
                }
            }

        } catch (error) {
            console.error('Error in ARC-ZARF:', error);
        }
    }
};