const fs = require("fs");
const path = require("path");
const axios = require("axios");

module.exports = {
  status: "on",
  name: 'Sarcastic Reply Dz Ad Only',
  command: 'دز',
  description: 'رد ساخر مع بطاقة إعلان صغيرة فقط عند قول كلمة دز',
  usage: '.دز',
  category: 'fun',
  hidden: false,

  async execute(sock, msg) {
    try {
      const chatId = msg.key.remoteJid;
      let imageBuffer = null;

      // 1. محاولة جلب صورة بروفايل الشخص الذي أرسل الأمر
      try {
        const senderJid = msg.key.participant || msg.key.remoteJid;
        const pfpUrl = await sock.profilePictureUrl(senderJid, "image");
        if (pfpUrl) {
          const res = await axios.get(pfpUrl, { responseType: "arraybuffer" });
          imageBuffer = Buffer.from(res.data, "binary");
        }
      } catch (e) {
        // يتجاوز بصمت إذا كانت الصورة مخفية أو غير موجودة
      }

      // 2. إذا لم تتوفر صورة البروفايل، يتم سحب الصورة الاحتياطية من السيرفر
      if (!imageBuffer) {
        const fallbackPath = path.join(process.cwd(), "image.jpeg");
        if (fs.existsSync(fallbackPath)) {
          imageBuffer = fs.readFileSync(fallbackPath);
        }
      }

      const replies = [
        "متدز انت يـ عم! ولا عشان أنا عمّك؟ 😒",
        "َدز دز وخلاص؟ متدز بعيد عننا كده 💨",
        "هَش انت يـ عم، اتكلم مصري وقول هش🗿",
        "َدز على راسك! فاكر نفسك فوق القانون؟ 🤨",
        "دَز؟ دز على باب بيتكو بالمرة 🧹",
        "شكلك فاضي يا عم، روح بقى نام  😴",
        "َدز إيه؟ دز نفسك و نام بدري لأن العيال الصغيره تنام بدري🐦‍⬛🤙",
        "دَز؟ دز انت ي عم و العب بعيد عن عمك 😉",
        "دز؟ هو احنا في سباق جمال ولا إيه؟ 🐸",
        "اكتب جملة مفيدة قبل ما تدز، احترم اللغة يا فندم 📚",
        "دزت على إيه طيب؟ مافيش حاجة أصلاً 😐",
        "دز؟ دانت محتاج تنضرب بالشبشب مش تترد عليك 🩴",
        "ليه دز؟ ناقصك حب واهتمام؟ 💔",
        "دز وبتقلب! فكرني بمسلسلات رمضان 😂",
        "ده انت لو قلت هش كنت أرحم 🙃",
        "ممنوع الدز بدون رخصة من الملك 👑",
        "كم مرة قلتلك دز مش كلمة سر يا سبايدرمان 🕷️",
        "دز نفسك عند محل الغاز 😂",
        "روح ذاكر بدل ما تدز، يمكن تنجح 📝",
        "اللي يدز بدز عليه ضعف! 🥷",
        "كفاية دز عشان الكيبورد اشتكى منك 🧠",
        "دز مرة كمان وهبلغ الشرطة 👮‍♂️",
        "دزني يا أخي كأننا في ساحة معركة! 🪖",
        "الكلمة دي لو كانت بتكسب ذهب كنا أغنياء دلوقتي 🪙",
        "خدلك دز على دماغك وارتاح 🧱",
        "كل يوم دز؟ يعني مافيش تطور؟ 🐌",
        "دزك جاي من مية نار ولا مية غسيل؟ 🔥",
        "دزك دا مش دز، دا نباح بصوت واطي 🐶",
        "دز دز، آخرها ترجع تبكي و تقول آسف 🧻",
        "إنت بتدز ولا بتسجل حضور؟ 😂"
      ];

      const randomReply = replies[Math.floor(Math.random() * replies.length)];

      // 3. إرسال نص الرد ومعه بطاقة الإعلان المصغرة فقط (بدون صورة كاملة)
      await sock.sendMessage(chatId, {
        text: randomReply,
        contextInfo: {
          externalAdReply: {
            title: "يعم لاتعيدها",
            body: "─ ʙʏ ᴀʀᴄᴇɴ ─",
            thumbnail: imageBuffer,
            mediaType: 1,
            sourceUrl: "https://github.com/arcxr7-max/ARC",
            renderLargerThumbnail: false,
            showAdAttribution: true
          }
        }
      }, { quoted: msg });

    } catch (error) {
      console.error('❌ خطأ في أمر دز بالإعلان المصغر:', error);
    }
  }
};