const fs = require("fs");
const path = require("path");
const axios = require("axios");

module.exports = {
  status: "on",
  name: 'Sarcastic Reply Yes Ad Only',
  command: 'نعم',
  description: 'رد ساخر مع بطاقة إعلان صغيرة فقط عند قول كلمة نعم',
  usage: '.نعم',
  category: 'fun',
  hidden: false,

  async execute(sock, msg) {
    try {
      const chatId = msg.key.remoteJid;
      let imageBuffer = null;

      // 1. محاولة جلب صورة بروفايل الشخص الذي أرسل الأمر
      try {
        const senderJid = msg.key.participant || msg.key.remoteJid;
        const pfpUrl = await sock.profilePictureUrl(senderJid, "image");
        if (pfpUrl) {
          const res = await axios.get(pfpUrl, { responseType: "arraybuffer" });
          imageBuffer = Buffer.from(res.data, "binary");
        }
      } catch (e) {
        // يتجاوز بصمت إذا كانت الصورة مخفية أو غير موجودة
      }

      // 2. إذا لم تتوفر صورة البروفايل، يتم سحب الصورة الاحتياطية من السيرفر
      if (!imageBuffer) {
        const fallbackPath = path.join(process.cwd(), "image.jpeg");
        if (fs.existsSync(fallbackPath)) {
          imageBuffer = fs.readFileSync(fallbackPath);
        }
      }

      const replies = [
        "نعم الله عليك، وش بدك أيُّها العاق 😤",
        "نعم أوف! استرجلت وبطلت تقول يب 😂",
        "نعم؟ لا تكون فجأة بطلت تتنفس كمان؟ 🐸",
        "نعم نعم نعم... خُش في الموضوع يا نجم 🌟",
        "بس كده؟ نعم وبس؟ فينك من زمان؟ 😒",
        "نعم يا كبير، شكلك جايب خبر مهم 😎"
      ];

      const randomReply = replies[Math.floor(Math.random() * replies.length)];

      // 3. إرسال نص الرد ومعه بطاقة الإعلان المصغرة المطلوبة بالحقوق الجديدة
      await sock.sendMessage(chatId, {
        text: randomReply,
        contextInfo: {
          externalAdReply: {
            title: "TB 100 png",
            body: "─ ʙʏ ᴀʀᴄᴇɴ ─",
            thumbnail: imageBuffer,
            mediaType: 1,
            sourceUrl: "https://github.com/arcxr7-max/ARC",
            renderLargerThumbnail: false,
            showAdAttribution: true
          }
        }
      }, { quoted: msg });

    } catch (error) {
      console.error('❌ خطأ في أمر نعم بالإعلان المصغر:', error);
    }
  }
};