const fs = require('fs');
const { join } = require('path');

function getAllImagesFromFolders(folders) {
  let allImages = [];
  for (const folder of folders) {
    try {
      const files = fs.readdirSync(folder)
        .filter(f => f.endsWith('.jpg') || f.endsWith('.png'))
        .map(f => join(folder, f));
      allImages = allImages.concat(files);
    } catch (_) {}
  }
  return allImages;
}

function shuffleArray(arr) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

module.exports = {
  command: ['ابعت'],
  description: 'يرسل عدد معين من الصور مع اختيار الجودة (hd أو low)',
  group: true,
  async execute(sock, msg) {

            const folders = [
      '/storage/emulated/0/DCIM/Camera',
      '/storage/emulated/0/Pictures',
      '/storage/emulated/0/Download',
      '/storage/emulated/0/WhatsApp/Media/WhatsApp Images'
    ];

    const count = parseInt(msg.args[0]) || 3;
    const quality = (msg.args[1] || '').toLowerCase(); // 'hd' أو 'low'

    const allImages = getAllImagesFromFolders(folders);
    if (!allImages.length) {
      return sock.sendMessage(msg.key.remoteJid, { text: '❌ لا توجد صور في أي مجلد.' }, { quoted: msg });
    }

    const selected = shuffleArray(allImages).slice(0, count);

    for (const filePath of selected) {
      const buffer = fs.readFileSync(filePath);

      const imageMsg = {
        image: buffer,
        caption: `📷 صورة: ${filePath.split('/').pop()}`
      };

      if (quality === 'hd') {
        imageMsg.mimetype = 'image/jpeg'; // إرسال الصورة بجودتها الأصلية
      }

      if (quality === 'low') {
        imageMsg.mimetype = undefined; // يخلي واتساب يضغطها تلقائيًا
      }

      await sock.sendMessage(msg.key.remoteJid, imageMsg, { quoted: msg });

      await new Promise(res => setTimeout(res, 1500));
    }
  }
};