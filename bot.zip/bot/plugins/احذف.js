const fs = require('fs').promises;
const fsSync = require('fs');
const path = require('path');
const { isDev } = require('../utils/devs');

const folders = ['plugins', 'handlers', 'utils', 'haykala', 'data', ''];

async function searchFile(fileName, baseDir) {
for (const folder of folders) {
const searchPath = folder ? path.join(baseDir, folder, fileName) : path.join(baseDir, fileName);
try {
await fs.access(searchPath);
return searchPath;
} catch(e) {}
}
return null;
}

async function listAllFiles(baseDir) {
let filesList = [];
for (const folder of folders) {
const searchPath = folder ? path.join(baseDir, folder) : baseDir;
try {
const files = await fs.readdir(searchPath);
for (const file of files) {
if (file.endsWith('.js') || file.endsWith('.json')) {
filesList.push(`${folder ? folder + '/' : ''}${file}`);
}
}
} catch(e) {}
}
return filesList;
}

module.exports = {
category: 'control',
command: 'del',
description: '🗑️ حذف ملف من أي مجلد وتحديث الذاكرة تلقائياً.',
usage: '.del [اسم الملف]',

async execute(sock, msg) {
const chatId = msg.key.remoteJid;
const sender = msg.key.participant || msg.key.remoteJid;
const senderNumber = sender.split('@')[0];

if (!isDev(senderNumber)) {
return sock.sendMessage(chatId, { text: '⚠️ ┋ عذراً، هذا الأمر مخصص للمطور الأساسي فقط!' }, { quoted: msg });
}

let fullText = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
const fileName = fullText.replace(/^\.del\s+/, '').trim();

if (!fileName) {
const files = await listAllFiles(process.cwd());
const fileList = files.map((f, i) => `${i+1}. ${f}`).join('\n');
return sock.sendMessage(chatId, {
text: `📁 قائمة الملفات\n\n${fileList || 'لا يوجد ملفات'}\n\n📌 استخدم: .del [اسم الملف]\nمثال: .del !اتصل.js`
}, { quoted: msg });
}

const baseDir = process.cwd();
const filePath = await searchFile(fileName, baseDir);

if (!filePath) {
return sock.sendMessage(chatId, { text: `❌ الملف ${fileName} غير موجود في أي مجلد` }, { quoted: msg });
}

try {
await fs.unlink(filePath);
const relativePath = path.relative(baseDir, filePath);

// 🔄 [التحديث التلقائي الذكي للـ Cache]
try {
const pluginsDir = path.join(baseDir, 'plugins');
if (fsSync.existsSync(pluginsDir)) {
const files = fsSync.readdirSync(pluginsDir);
for (const file of files) {
if (file.endsWith('.js')) {
delete require.cache[require.resolve(path.join(pluginsDir, file))];
}
}
}
const handlerPath = path.join(baseDir, 'handlers', 'handler.js');
if (fsSync.existsSync(handlerPath)) delete require.cache[require.resolve(handlerPath)];
if (global.loadPlugins) await global.loadPlugins(true);
} catch (e) { console.error(e); }

// 📝 الرسالة المختصرة الجديدة بناءً على طلبك
await sock.sendMessage(chatId, { 
text: `*✅ تم حذف البلوجن بنجاح!*\n*📁 ${relativePath}*\n*💾 تم حفظ نسخة احتياطية وتحديث النظام*` 
}, { quoted: msg });

} catch(e) {
await sock.sendMessage(chatId, { text: `❌ فشل حذف الملف: ${e.message}` }, { quoted: msg });
}
}
};