module.exports = {
    command: ['احسب'],
    category: 'tools',
    description: '🧮 إجراء العمليات الحسابية الذكية لجميع الرموز',

    async execute(sock, msg) {
        try {
            const from = msg.key.remoteJid;
            const body = msg.message?.extendedTextMessage?.text || msg.message?.conversation || '';
            const args = body.trim().split(/\s+/).slice(1);
            let rawExpression = args.join(' ');

            if (!rawExpression) {
                return await sock.sendMessage(from, { 
                    text: '❌ يرجى كتابة العملية الحسابية بعد الأمر.\nمثال: `.احسب 4 × 5` أو `.احسب 10 ÷ 2`' 
                }, { quoted: msg });
            }

            // 🔄 تنظيف وتبديل الرموز العامة لرموز تفهمها لغة البرمجة (دعم كل العمليات)
            let expression = rawExpression
                .replace(/×/g, '*')  // تحويل علامة الضرب اللمسية إلى نجمة ضرب
                .replace(/÷/g, '/')  // تحويل علامة القسمة اللمسية إلى سلاش قسمة
                .replace(/\^/g, '**') // تحويل علامة الأسس مثل 2^3 إلى أس برمي
                .replace(/\s+/g, ''); // إزالة الفراغات المتداخلة

            // 🔒 فحص أمني صارم بعد التبديل للأرقام والرموز الرياضية المسموحة فقط
            if (!/^[0-9+\-*/().]+$/.test(expression)) {
                return await sock.sendMessage(from, { text: '❌ العملية تحتوي على رموز غير صالحة للعمليات الرياضية.' }, { quoted: msg });
            }

            // تفاعل تلقائي 🧮
            await sock.sendMessage(from, { react: { text: "🧮", key: msg.key } });

            // حساب النتيجة الحسابية بدقة وأمان
            const result = Function(`"use strict"; return (${expression})`)();

            // تنسيق النتيجة لتبدو احترافية
            const responseText = `
🧮 _الآلة الحاسبة الذكية_

▫️ العملية: \`${rawExpression}\`

. . . . . . . . . . . . . . . . . . . . .

*النتيجة النهائية:* *${result}*
`.trim();

            await sock.sendMessage(from, { text: responseText }, { quoted: msg, noFormat: true });

        } catch (error) {
            await sock.sendMessage(from, { text: '❌ عذراً، تعذر حساب هذه العملية. تأكد من صياغتها رياضياً بشكل صحيح.' }, { quoted: msg });
        }
    }
};