// plugins/عدد.js
module.exports = {
    command: ['احصاء'],
    category: 'tools',
    description: '📊 حساب عدد الكلمات والحروف في النص',

    async execute(sock, msg) {
        try {
            const from = msg.key.remoteJid;
            const body = msg.message?.extendedTextMessage?.text || msg.message?.conversation || '';
            const args = body.trim().split(/\s+/).slice(1);
            const text = args.join(' ').trim();

            if (!text) {
                return await sock.sendMessage(from, { 
                    text: '❌ *يرجى كتابة نص بعد الأمر!*\n\n💡 مثال:\n`.عدد قمة الأدب أن تنصت`' 
                }, { quoted: msg });
            }

            const wordCount = text.split(/\s+/).filter(w => w.length > 0).length;
            const charCountWithSpaces = text.length;
            const charCountNoSpaces = text.replace(/\s+/g, '').length;

            const countMessage = [
                `╭───────────────────╮`,
                `📊 *إحصائيات النص المرسل:*`,
                ``,
                `📝 *النص:* "${text.substring(0, 30)}${text.length > 30 ? '...' : ''}"`,
                ``,
                `🔹 *عدد الكلمات:* ${wordCount}`,
                `🔹 *عدد الحروف (مع الفراغات):* ${charCountWithSpaces}`,
                `🔹 *عدد الحروف (بدون فراغات):* ${charCountNoSpaces}`,
                `╰───────────────────╯`
            ].join('\n');

            await sock.sendMessage(from, { text: countMessage }, { quoted: msg });

        } catch (error) {
            console.error(error);
        }
    }
};