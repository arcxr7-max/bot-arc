const axios = require('axios');

const AZKAR_URL = 'https://raw.githubusercontent.com/arcxr7-max/ARC/refs/heads/main/azkar.json';

module.exports = {
    category: 'islamic',
command: ['اذكاري'],
    description: '🕌 عرض ذكر أو دعاء عشوائي',
    usage: '.اذكاري',
     

    async execute(sock, msg) {
        const chatId = msg.key.remoteJid;
                await sock.sendMessage(chatId, { react: { text: '📿', key: msg.key } });

        try {
            const response = await axios.get(AZKAR_URL);
            const list = response.data;
            const random = list[Math.floor(Math.random() * list.length)];
            await sock.sendMessage(chatId, { text: random });
        } catch(e) {
            await sock.sendMessage(chatId, { text: '❌ خطأ في جلب الأذكار' });
        }
    }
};