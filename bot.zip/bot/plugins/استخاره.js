module.exports = {
    category: 'islamic',
  command: 'استخارة',
  description: '🕌 دعاء الاستخارة مع صوت',
  usage: '.استخارة',
  
  async execute(sock, msg) {
    const text = `
📿 *دعاء الاستخارة*:

اللَّهُمَّ إِنِّي أَسْتَخِيرُكَ بِعِلْمِكَ، وَأَسْتَقْدِرُكَ بِقُدْرَتِكَ، وَأَسْأَلُكَ مِنْ فَضْلِكَ العَظِيمِ...

(اقرأه بعد ركعتين بنية الاستخارة)

🎧 *استمع للدعاء الآن:*
`.trim();

    await sock.sendMessage(msg.key.remoteJid, { text }, { quoted: msg });

    await sock.sendMessage(msg.key.remoteJid, {
      audio: { url: 'https://www.ashefaa.com/jawal/enshad/%D8%AF%D8%B9%D8%A7%D8%A1-%D8%A7%D9%84%D8%A7%D8%B3%D8%AA%D8%AE%D8%A7%D8%B1%D8%A9.mp3' },
      mimetype: 'audio/mpeg',
      ptt: false
    }, { quoted: msg });
  }
};