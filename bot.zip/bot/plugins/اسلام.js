// plugins/اسلام.js
const fs = require('fs');
const path = require('path');

// ملف لتخزين حالة كل جروب
const DATA_PATH = path.join(__dirname, '../data/islam-groups.json');

// تحميل أو إنشاء ملف الحالات
function loadGroups() {
    if (!fs.existsSync(DATA_PATH)) return {};
    return JSON.parse(fs.readFileSync(DATA_PATH));
}

function saveGroups(data) {
    const dir = path.dirname(DATA_PATH);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(DATA_PATH, JSON.stringify(data, null, 2));
}

// أوقات الصلاة
const prayerTimes = [
    { hour: 4, minute: 36, name: "الفجر" },
    { hour: 13, minute: 42, name: "الظهر" },
    { hour: 17, minute: 21, name: "العصر" },
    { hour: 20, minute: 51, name: "المغرب" },
    { hour: 22, minute: 23, name: "العشاء" }
];

const hadith = "قال ﷺ: «الصلاة عماد الدين، من أقامها فقد أقام الدين.»";
const city = "سيدي العابد - المغرب";

// وظيفة إرسال التذكير
async function sendPrayerReminder(sock, groupId, prayer) {
    const msg = `🕌 *تذكير بصلاة ${prayer.name}* 🕌
━━━━━━━━━━━━━━━━━━
📍 *المدينة:* ${city}
📜 *الحديث:* ${hadith}

⏰ *حان الآن وقت صلاة ${prayer.name}!*

🙏 فضلاً توقفوا عن الدردشة وتهيؤوا للصلاة

━━━━━━━━━━━━━━━━━━
⏳ سيتم إعادة فتح الدردشة خلال 10 ثوانٍ`;

    try {
        // قفل المجموعة (وضع الإعلانات)
        await sock.groupSettingUpdate(groupId, 'announcement');
        await sock.sendMessage(groupId, { text: msg });
        
        setTimeout(async () => {
            try {
                // فتح المجموعة مرة أخرى
                await sock.groupSettingUpdate(groupId, 'not_announcement');
                await sock.sendMessage(groupId, { text: "✅ *تم فتح الدردشة للجميع!*\n🤲 تقبل الله منا ومنكم" });
            } catch(e) {
                console.error("خطأ في فتح المجموعة:", e);
            }
        }, 10000);
    } catch (err) {
        console.error("خطأ في إرسال التذكير:", err);
    }
}

module.exports = {
    category: 'islamic',
    command: ['اسلام'],
    description: '🕌 تفعيل أو إيقاف تذكير أوقات الصلاة في المجموعة',
    usage: '.اسلام [تشغيل|ايقاف]',
    
    async execute(sock, msg) {
        const groupId = msg.key.remoteJid;

        // التحقق من أن الأمر في مجموعة
        if (!groupId.endsWith('@g.us')) {
            return sock.sendMessage(groupId, { 
                text: '❌ هذا الأمر يعمل فقط في المجموعات' 
            }, { quoted: msg });
        }

        // قراءة النص كاملاً
        let fullText = '';
        if (msg.message?.conversation) fullText = msg.message.conversation;
        else if (msg.message?.extendedTextMessage?.text) fullText = msg.message.extendedTextMessage.text;
        else fullText = '';

        const subCmd = fullText.replace(/^\.اسلام\s?/i, '').trim().toLowerCase();
        let groups = loadGroups();

        // تفعيل التذكير
        if (subCmd === 'تشغيل' || subCmd === 'تفعيل' || subCmd === 'on') {
            groups[groupId] = true;
            saveGroups(groups);
            return sock.sendMessage(groupId, { 
                text: '✅ *تم تفعيل تذكير أوقات الصلاة في هذا الجروب!*\n🕌 سيتم تذكيركم بكل صلاة في وقتها'
            }, { quoted: msg });
        }

        // إيقاف التذكير
        if (subCmd === 'ايقاف' || subCmd === 'تعطيل' || subCmd === 'off') {
            groups[groupId] = false;
            saveGroups(groups);
            return sock.sendMessage(groupId, { 
                text: '🛑 *تم إيقاف تذكير أوقات الصلاة في هذا الجروب!*'
            }, { quoted: msg });
        }

        // عرض حالة الجروب الحالية
        const currentStatus = groups[groupId] ? '✅ مفعل' : '❌ معطل';
        
        return sock.sendMessage(groupId, { 
            text: `🕌 *نظام تذكير الصلاة*\n━━━━━━━━━━━━━━━━━━\n📊 *الحالة:* ${currentStatus}\n📍 *المدينة:* ${city}\n⏰ *أوقات الصلاة:*\n${prayerTimes.map(p => `   • ${p.name}: ${p.hour}:${p.minute.toString().padStart(2, '0')}`).join('\n')}\n\n📌 *للتشغيل:* .اسلام تشغيل\n📌 *للايقاف:* .اسلام ايقاف`
        }, { quoted: msg });
    }
};

// إعداد المؤقت للتذكير (مرة واحدة فقط)
if (!global._islamPrayerInterval) {
    global._islamPrayerInterval = setInterval(async () => {
        const now = new Date();
        const currentHour = now.getHours();
        const currentMinute = now.getMinutes();
        const currentSecond = now.getSeconds();

        const groups = loadGroups();
        const activeGroups = Object.entries(groups).filter(([_, active]) => active === true);

        if (activeGroups.length === 0) return;

        for (const prayer of prayerTimes) {
            // التحقق من الوقت (مع مراعاة الثواني لتجنب الإرسال المتكرر)
            if (currentHour === prayer.hour && currentMinute === prayer.minute && currentSecond === 0) {
                for (const [groupId] of activeGroups) {
                    try {
                        const sock = global.sock || global.conn;
                        if (sock) {
                            await sendPrayerReminder(sock, groupId, prayer);
                        } else {
                            console.log("⚠️ sock غير معرف");
                        }
                    } catch (e) {
                        console.error("خطأ أثناء إرسال التذكير:", e);
                    }
                }
            }
        }
    }, 1000); // فحص كل ثانية بدلاً من دقيقة (أكثر دقة)
}