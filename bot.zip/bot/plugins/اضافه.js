const config = require('../config');
const fs = require('fs');
const path = require('path');
const { isDev } = require('../utils/devs');
const { isElite } = require('../haykala/elite');

const pointsFile = path.join(__dirname, '../data/points.json');

function getPoints() {
    if (!fs.existsSync(pointsFile)) return {};
    return JSON.parse(fs.readFileSync(pointsFile, 'utf8'));
}

function savePoints(points) {
    fs.writeFileSync(pointsFile, JSON.stringify(points, null, 2));
}

module.exports = {
    command: 'اضافه',
    description: '➕ إضافة نقاط لشخص (للمطورين والنخبة فقط)',
    usage: '.اضافه [المبلغ] @الشخص',
    category: 'info',

    async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
                const chatId = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;
        const senderNumber = sender.split('@')[0];

        // ✅ التحقق من المطور (من ملف devs.json)
        if (!isDev(senderNumber) && !isElite(senderNumber)) {
            return sock.sendMessage(chatId, {
                text: '🚫 هذا الأمر للمطورين والنخبة فقط'
            }, { quoted: msg });
        }

        // ✅ قراءة النص مباشرة من الرسالة
        let fullText = '';
        if (msg.message?.conversation) fullText = msg.message.conversation;
        else if (msg.message?.extendedTextMessage?.text) fullText = msg.message.extendedTextMessage.text;
        else fullText = '';

        // ✅ إزالة الأمر واستخراج المبلغ والمنشن
        const withoutCommand = fullText.replace(/^\.اضافه\s*/, '').trim();
        const parts = withoutCommand.split(/\s+/);
        
        const amount = parseInt(parts[0]);
        const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];

        // ✅ التحقق من المبلغ
        if (!amount || isNaN(amount) || amount <= 0) {
            return sock.sendMessage(chatId, {
                text: '❌ استخدم: .اضافه [المبلغ] @الشخص\nمثال: .اضافه 100 @المستخدم'
            }, { quoted: msg });
        }

        // ✅ التحقق من وجود منشن
        if (!mentioned) {
            return sock.sendMessage(chatId, {
                text: '❌ قم بمنشن الشخص الذي تريد إضافة نقاط له'
            }, { quoted: msg });
        }

        const targetNumber = mentioned.split('@')[0];
        let points = getPoints();
        
        points[targetNumber] = (points[targetNumber] || 0) + amount;
        savePoints(points);

        await sock.sendMessage(chatId, {
            text: `✅ تم إضافة ${amount} نقطة لـ @${targetNumber}\n💰 رصيده الآن: ${points[targetNumber]} نقطة`,
            mentions: [mentioned]
        }, { quoted: msg });
    }
};