const axios = require('axios');
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');

/* 🧠 منع التكرار */
const sentAudios = new Map();
const MAX_HISTORY = 100;

function rememberAudio(id) {
  sentAudios.set(id, Date.now());
  if (sentAudios.size > MAX_HISTORY) {
    const oldest = [...sentAudios.entries()]
      .sort((a, b) => a[1] - b[1])[0][0];
    sentAudios.delete(oldest);
  }
}

module.exports = {
  command: 's',
  category: 'media',
  description: '🎧 يرسل صوت Edit (TikTok / YouTube)',
  usage: '.s [الموضوع]',

  async execute(sock, msg) {

            const chatId = msg.key.remoteJid;
    const body =
      msg.message?.extendedTextMessage?.text ||
      msg.message?.conversation ||
      '';

    const args = body.trim().split(/\s+/).slice(1);
    const query = args.join(' ');
    const searchText = query ? `${query} edit audio` : 'edit audio';

    await sock.sendMessage(chatId, {
      react: { text: '🎧', key: msg.key },
    });

    /* 🔴 TikTok (TikWM) */
    try {
      const apiUrl = `https://www.tikwm.com/api/feed/search?keywords=${encodeURIComponent(searchText)}`;
      const { data } = await axios.get(apiUrl);

      if (data.code === 0 && data.data?.videos?.length) {
        const fresh = data.data.videos.filter(v => {
          const id = v.video_id || v.id || v.play;
          return id && !sentAudios.has(id);
        });

        if (fresh.length) {
          const selected = fresh[Math.floor(Math.random() * fresh.length)];
          const audioUrl = selected.music || selected.music_info?.play;
          const audioId = selected.video_id || selected.id;

          if (audioUrl) {
            rememberAudio(audioId);

            return await sock.sendMessage(
              chatId,
              {
                audio: { url: audioUrl },
                mimetype: 'audio/mpeg',
                ptt: false,
                caption: `🎧 *Audio Edit*\n\n📌 *الموضوع:* ${query || 'عشوائي'}`,
              },
              { quoted: msg }
            );
          }
        }
      }
    } catch (e) {
      console.warn('⚠️ فشل TikTok — التحويل إلى YouTube');
    }

    /* 🟡 YouTube (yt-dlp) */
    try {
      const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'audio-'));
      const outPath = path.join(tmpDir, 'audio.%(ext)s');

      const cmd = `
yt-dlp "ytsearch1:${searchText}" \
-x --audio-format mp3 \
-o "${outPath}" --quiet --no-warnings
`;
      execSync(cmd);

      const files = fs.readdirSync(tmpDir).filter(f => f.endsWith('.mp3'));
      if (!files.length) throw new Error('لا يوجد صوت');

      const audioPath = path.join(tmpDir, files[0]);

      await sock.sendMessage(
        chatId,
        {
          audio: fs.readFileSync(audioPath),
          mimetype: 'audio/mpeg',
          ptt: false,
          caption: `🎧 *تم من YouTube*\n\n📌 *الموضوع:* ${query || 'عشوائي'}`,
        },
        { quoted: msg }
      );

      fs.rmSync(tmpDir, { recursive: true, force: true });
    } catch (err) {
      console.error('❌ فشل كامل:', err.message);
      await sock.sendMessage(
        chatId,
        {
          text: '❌ تعذر جلب صوت من TikTok و YouTube.\nتأكد أن yt-dlp مثبت.',
        },
        { quoted: msg }
      );
    }
  },
};