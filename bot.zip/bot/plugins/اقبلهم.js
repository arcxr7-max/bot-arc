const config = require('../config');
const fs = require('fs');

module.exports = {
  command: ['اقبلهم'],
  description: 'يقبل كل طلبات الانضمام دفعة واحدة (بحد أقصى 200).',
  category: 'group',

  async execute(sock, msg) {
    try {
      const groupId = msg.key.remoteJid;

      const imagePath = 'imagee.jpeg';
      const hasImage = fs.existsSync(imagePath);
      const imageBuffer = hasImage ? fs.readFileSync(imagePath) : null;

      const reply = async (text) => {
        await sock.sendMessage(groupId, {
          text,
          contextInfo: {
            externalAdReply: {
              title: 'قبول الطلبات',
              body: 'تمت الموافقة على الجميع 🤝',
              thumbnail: imageBuffer,
              mediaType: 1,
              sourceUrl: 'https://t.me/YourChannel',
              renderLargerThumbnail: false,
              showAdAttribution: true
            }
          }
        }, { quoted: msg });
      };

      let joinRequestList = await sock.groupRequestParticipantsList(groupId);

      if (!joinRequestList || joinRequestList.length === 0) {
        return reply('📭 لا توجد طلبات حالياً.');
      }

      // حد أقصى 200 فقط
      joinRequestList = joinRequestList.slice(0, 200);

      // ✅ استخراج جميع الـ JIDs دفعة واحدة
      const jidsToApprove = joinRequestList.map(request => request.jid);

      // ✅ قبول الكل دفعة واحدة (بدون حلقة)
      await sock.groupRequestParticipantsUpdate(groupId, jidsToApprove, 'approve');

      return reply(`*منوࢪين* (${jidsToApprove.length} طلب)`);

    } catch (error) {
      console.error(error);
      return await sock.sendMessage(msg.key.remoteJid, { text: '❌ حصل خطأ أثناء قبول الطلبات.' }, { quoted: msg });
    }
  }
};