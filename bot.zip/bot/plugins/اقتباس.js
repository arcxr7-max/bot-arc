const config = require('../config');

module.exports = {
  category: 'fun',
  command: ['اقتباس'],
  description: 'يرسل اقتباس عميق مزخرف مع إيموجيات من رابط خارجي.',

  async execute(sock, msg) {
    try {
      const chatId = msg.key.remoteJid;

      // رابط ملف الاقتباسات الخاص بك على GitHub (استبدله برابطك المباشر Raw)
      const quotesUrl = 'https://raw.githubusercontent.com/arcxr7-max/ARC/refs/heads/main/Adap.json';
      
      // رابط الصورة المباشر أونلاين
      const imageUrl = 'https://i.imgur.com/8TnZ4Rv.png';

      // جلب الاقتباسات من الرابط
      const response = await fetch(quotesUrl);
      if (!response.ok) throw new Error('فشل في جلب الاقتباسات من الرابط');
      
      const quotes = await response.json();
      const quote = quotes[Math.floor(Math.random() * quotes.length)];

      await sock.sendMessage(chatId, {
        text: quote,
        contextInfo: {
          externalAdReply: {
            title: "اقتباس اليوم",
            body: "💬 اقتباس مزخرف يلامس الأعماق",
            thumbnailUrl: imageUrl,
            mediaType: 1,
            sourceUrl: "https://t.me/arcxr7",
            renderLargerThumbnail: false,
            showAdAttribution: true
          }
        }
      }, { quoted: msg });

    } catch (error) {
      console.error('Error in quote command:', error);
      if (msg.key?.remoteJid) {
        await sock.sendMessage(msg.key.remoteJid, {
          text: '❌ حدث خطأ أثناء جلب الاقتباس، حاول مرة أخرى لاحقاً.'
        }, { quoted: msg });
      }
    }
  }
};
