const config = require('../config');
const fs = require('fs');
const path = require('path');

const file = path.join(__dirname, '../data/suggestions.json');
const devJid = '201028489465@s.whatsapp.net';

if (!fs.existsSync(file)) fs.writeFileSync(file, '[]');

module.exports = {
  command: "اقترح",
  description: "📝 أرسل اقتراحك لإدارة البوت",
  usage: ".اقترح [نص الاقتراح]",

  async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
            const args = msg.args || [];
    const from = msg.key.remoteJid;
    const name = msg.pushName || "عضو مجهول";
    const sender = msg.participant || msg.key.participant || msg.key.remoteJid;

    const suggestion = args.join(" ").trim();
    if (!suggestion) {
      return await sock.sendMessage(from, {
        text: "📝 اكتب اقتراح بعد الأمر.\nمثال: `.اقترح نضيف لعبة جديدة`"
      }, { quoted: msg });
    }

    const cleanText = suggestion.replace(/[<>]/g, '');
    const formattedDate = new Date().toLocaleString("ar-EG");

    const list = JSON.parse(fs.readFileSync(file));
    list.push({
      name,
      suggestion: cleanText,
      from: sender,
      date: formattedDate
    });
    fs.writeFileSync(file, JSON.stringify(list, null, 2));

    await sock.sendMessage(from, {
      text: "✅ اقتراحك اتسجل وتم إرساله للمطور، شكراً ليك! 🙏"
    }, { quoted: msg });

    // استخراج اسم الجروب لو الرسالة من جروب
    let groupName = '';
    if (from.endsWith('@g.us')) {
      try {
        const metadata = await sock.groupMetadata(from);
        groupName = metadata.subject || 'جروب غير معروف';
      } catch {
        groupName = 'جروب غير معروف';
      }
    }

    await sock.sendMessage(devJid, {
      text: `📩 *اقتراح جديد من • ${name}*\n\n` +
            `📬 من: wa.me/${sender.split("@")[0]}\n` +
            (groupName ? `👥 الجروب: ${groupName}\n` : '') +
            `📝 الاقتراح:\n${cleanText}`
    });
  }
};