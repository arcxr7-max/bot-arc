const config = require('../config');
const fs = require('fs');
const path = require('path');

const pointsFile = path.join(__dirname, '../data/points.json');

function getPoints() {
    if (!fs.existsSync(pointsFile)) return {};
    return JSON.parse(fs.readFileSync(pointsFile, 'utf8'));
}

function savePoints(points) {
    fs.writeFileSync(pointsFile, JSON.stringify(points, null, 2));
}

const letters = ['ا', 'ب', 'ت', 'ث', 'ج', 'ح', 'خ', 'د', 'ذ', 'ر', 'ز', 'س', 'ش', 'ص', 'ض', 'ط', 'ظ', 'ع', 'غ', 'ف', 'ق', 'ك', 'ل', 'م', 'ن', 'ه', 'و', 'ي'];

if (!global.writingGames) global.writingGames = {};

module.exports = {
    command: 'اكتب',
    description: '✍️ اكتب كلمة تبدأ بحرف معين',
    usage: '.اكتب',
    category: 'game',

    async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
                const chatId = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;
        const senderNumber = sender.split('@')[0];

        if (global.writingGames[senderNumber]) {
            return sock.sendMessage(chatId, { text: '⚠️ لديك لعبة نشطة! أجب على الحرف' }, { quoted: msg });
        }

        const letter = letters[Math.floor(Math.random() * letters.length)];
        global.writingGames[senderNumber] = { letter, chatId, time: Date.now() };

        await sock.sendMessage(chatId, {
            text: `✍️ *لعبة اكتب كلمة*\n\nاكتب كلمة تبدأ بحرف *${letter}*\n\n💰 الجائزة: 30 نقطة\n⏰ لديك 20 ثانية`
        }, { quoted: msg });

        setTimeout(() => {
            if (global.writingGames[senderNumber]) {
                delete global.writingGames[senderNumber];
                sock.sendMessage(chatId, { text: `⌛ انتهى الوقت! الحرف كان: ${letter}` });
            }
        }, 20000);
    }
};