const config = require('../config');
const fs = require('fs');
const path = require('path');

// ربط النقاط بملف العملة حقك
const pointsFile = path.join(__dirname, '../data/points.json');

if (!global.xoGames) global.xoGames = {};

const drawBoard = b => [0, 3, 6].map(i => 
    b.slice(i, i + 3).map((c, idx) => c ? (c === 'X' ? '❌' : '⭕') : `${i + idx + 1}️⃣`).join(' | ')
).join('\n');

const checkWinner = b => {
    const lines = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]];
    for (const [a, c, d] of lines) if (b[a] && b[a] === b[c] && b[a] === b[d]) return b[a];
    return null;
};

module.exports = {
    command: 'xo',
    description: 'لعبة اكس او الشهيرة',
    category: 'game',

    async execute(sock, message) {
        const from = message.key.remoteJid;
        const senderJid = message.key.participant || from;
        const text = message.args?.join(' ') || '';
        
        const game = global.xoGames[from];
        const cmd = text.trim().toLowerCase();
        const isDelete = cmd === 'delete' || cmd === 'حذف';
        const isJoin = cmd === 'join' || cmd === 'انضمام' || text === '';

        if (isDelete) {
            if (!game) return sock.sendMessage(from, { text: "❌ لا توجد لعبة نشطة للحذف!" }, { quoted: message });
            delete global.xoGames[from];
            return sock.sendMessage(from, { text: "🗑️ تم حذف اللعبة!" }, { quoted: message });
        }

        if (!game) {
            global.xoGames[from] = { 
                player1: senderJid, 
                player2: null, 
                board: Array(9).fill(null), 
                turn: 'X', 
                status: 'waiting' 
            };
            return sock.sendMessage(from, { 
                text: `🎮 تم إنشاء لعبة XO!\n\n@${senderJid.split('@')[0]} ينتظر خصماً.\n\nاكتب *.xo* للانضمام!`,
                mentions: [senderJid]
            }, { quoted: message });
        }

        if (game.status === 'waiting' && senderJid !== game.player1) {
            game.player2 = senderJid;
            game.status = 'playing';
            return sock.sendMessage(from, { 
                text: `🎮 بدأت اللعبة!\n\n${drawBoard(game.board)}\n\n@${game.player1.split('@')[0]} (❌) ضد @${game.player2.split('@')[0]} (⭕)\n\nدور @${game.player1.split('@')[0]} ابدأ بالاختيار من 1 إلى 9`,
                mentions: [game.player1, game.player2] 
            }, { quoted: message });
        }

        if (game.status === 'playing') {
            return sock.sendMessage(from, { text: "❌ اللعبة بدأت بالفعل! اكتب *.xo حذف* إذا أردت إنهاءها." }, { quoted: message });
        }

        if (senderJid === game.player1) {
            return sock.sendMessage(from, { text: "❌ أنت تنتظر خصماً، لا يمكنك اللعب ضد نفسك!" }, { quoted: message });
        }
    }
};

// الجزء ده لازم تضيفه في الـ handler.js عشان يستقبل الحركات
global.handleXO = async (sock, message, body) => {
    const from = message.key.remoteJid;
    const senderJid = message.key.participant || from;
    const game = global.xoGames?.[from];

    if (!game || game.status !== 'playing') return;

    const currentPlayer = game.turn === 'X' ? game.player1 : game.player2;
    if (senderJid !== currentPlayer) return;

    const move = parseInt(body.trim()) - 1;
    if (isNaN(move) || move < 0 || move > 8 || game.board[move] !== null) return;

    game.board[move] = game.turn;
    const winner = checkWinner(game.board);
    const isTie = game.board.every(cell => cell !== null);

    if (winner || isTie) {
        let resText = drawBoard(game.board) + "\n\n";
        if (winner) {
            const winnerJid = winner === 'X' ? game.player1 : game.player2;
            const userNo = winnerJid.split('@')[0];
            
            // إضافة 500 نقطة للفائز في ملف النقاط حقك
            let points = fs.existsSync(pointsFile) ? JSON.parse(fs.readFileSync(pointsFile)) : {};
            points[userNo] = (points[userNo] || 0) + 500;
            fs.writeFileSync(pointsFile, JSON.stringify(points, null, 2));

            resText += `🎉 كفووو @${userNo} فزت باللعبة!\n💰 ربحت 500 نقطة.`;
        } else {
            resText += "🤝 تعادل! لا يوجد فائز.";
        }
        
        await sock.sendMessage(from, { text: resText, mentions: winner ? [game.player1, game.player2] : [] });
        delete global.xoGames[from];
        return;
    }

    game.turn = game.turn === 'X' ? 'O' : 'X';
    const nextPlayer = game.turn === 'X' ? game.player1 : game.player2;
    await sock.sendMessage(from, { 
        text: `${drawBoard(game.board)}\n\nدورك يا @${nextPlayer.split('@')[0]} (${game.turn})`,
        mentions: [nextPlayer] 
    });
};
