const config = require('../config');
const fs = require('fs');
const path = require('path');

module.exports = {
  status: "on",
  name: 'مطور',
  command: ['مطور'],
  category: 'info',
  description: '👑 إرسال بطاقة المطور بنظام المعاينة المتقدم',
  hidden: false,
  version: '7.0',

  async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    try {
    const from = msg.key.remoteJid;
    
    // 🎯 جلب صورة بروفايل الرقم المذكور تلقائياً من سيرفر الواتساب
    let imageUrl;
    try {
        // نقوم بتركيب الـ JID الخاص بالرقم بالصيغة الصحيحة للواتساب
        const targetJid = '212612969896@s.whatsapp.net';
        imageUrl = await sock.profilePictureUrl(targetJid, 'image');
    } catch (picError) {

        imageUrl = 'https://www.image2url.com/r2/default/images/1778949052225-cab8d2eb-c09a-48c3-89db-cd86ae7025c1.jpg';
    }

    // هنا يكمل كود الإرسال الخاص بك لـ imageUrl حياً وبدون أي مشاكل...

      const devNumber = '212612969896'

      // 1. إعداد جهة الاتصال (VCard)
      const vcard = 'BEGIN:VCARD\n'
        + 'VERSION:3.0\n'
        + 'FN:𓆰𝑬𝑴𝑷 ꙰𓃥\n'
        + 'ORG:𝘼𝙍𝘾 OWNER;\n'
        + `TEL;type=CELL;type=VOICE;waid=${devNumber}:+${devNumber}\n`
        + 'END:VCARD';

      // 2. إرسال جهة الاتصال مع الصورة والوصف المزخرف (ExternalAdReply)
      await sock.sendMessage(from, {
        contacts: {
          displayName: '𓆰𝑬𝑴𝑷 ꙰𓃥',
          contacts: [{ vcard }]
        },
        contextInfo: {
          externalAdReply: {
            title: 'ᴛʜᴇ ᴏᴡɴᴇʀ', // العنوان المزخرف الأول
            body: '© ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴀʀᴄ', // الوصف الثاني
            thumbnailUrl: imageUrl, // رابط الصورة الملتصق بالبطاقة
            sourceUrl: `https://wa.me/${devNumber}`, // رابط عند الضغط على الصورة
            mediaType: 1,
            renderLargerThumbnail: true // لجعل الصورة تظهر بشكل أوضح وكبير
          }
        }
      }, { quoted: msg });


    } catch (err) {
      console.error(err);
      await sock.sendMessage(msg.key.remoteJid, {
        text: `❌ فشل عرض بيانات المطور.`
      }, { quoted: msg });
    }
  }
};