const config = require('../config');
const fs = require('fs');
const path = require('path');
const warnsFile = path.join(__dirname, '../data/warns.json');

function loadWarns() {
  if (!fs.existsSync(warnsFile)) fs.writeFileSync(warnsFile, '{}');
  return JSON.parse(fs.readFileSync(warnsFile));
}

function saveWarns(warns) {
  fs.writeFileSync(warnsFile, JSON.stringify(warns, null, 2));
}

module.exports = {
  command: 'انذار',
  description: '⚠️ إعطاء إنذار لعضو (فقط للمشرفين)، وإذا وصل لـ 3 يتم طرده',
  usage: '.انذار @العضو',
  groupOnly: true,

  async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
            const groupId = msg.key.remoteJid;

    // 1. التأكد أنه جروب
    if (!groupId.endsWith('@g.us')) {
      return await sock.sendMessage(groupId, {
        text: '❌ هذا الأمر يعمل في الجروبات فقط'
      }, { quoted: msg });
    }

    // 2. التأكد من أن المرسل مشرف
    const metadata = await sock.groupMetadata(groupId);
    const senderId = msg.participant || msg.key.participant || msg.key.remoteJid;
    const isAdmin = metadata.participants.some(
      p => p.id === senderId && (p.admin === 'admin' || p.admin === 'superadmin')
    );

    if (!isAdmin) {
      return await sock.sendMessage(groupId, {
        text: '🚫 هذا الأمر مخصص للمشرفين فقط.'
      }, { quoted: msg });
    }

    // 3. استخراج المنشن من الرسالة
    const mention = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
    if (!mention) {
      return await sock.sendMessage(groupId, {
        text: '❌ منشن العضو المراد إعطاؤه إنذارًا.\nمثال:\n.انذار @العضو'
      }, { quoted: msg });
    }

    // 4. تحميل أو إضافة إنذار
    const warns = loadWarns();
    if (!warns[groupId]) warns[groupId] = {};
    if (!warns[groupId][mention]) warns[groupId][mention] = 0;

    warns[groupId][mention]++;
    const warnCount = warns[groupId][mention];
    saveWarns(warns);

    // 5. طرد إذا تجاوز الحد
    if (warnCount >= 3) {
      await sock.groupParticipantsUpdate(groupId, [mention], 'remove');
      warns[groupId][mention] = 0;
      saveWarns(warns);

      return await sock.sendMessage(groupId, {
        text: `🚫 @${mention.split('@')[0]} تم طرده بعد الحصول على 3 إنذارات.`,
        mentions: [mention]
      }, { quoted: msg });
    }

    // 6. عرض عدد الإنذارات الحالي
    return await sock.sendMessage(groupId, {
      text: `⚠️ @${mention.split('@')[0]} حصل على إنذار.\n📌 عدد الإنذارات: ${warnCount}/3`,
      mentions: [mention]
    }, { quoted: msg });
  }
};