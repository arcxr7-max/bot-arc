const config = require('../config');
const fs = require('fs');
const path = require('path');
const warnsFile = path.join(__dirname, '../data/warns.json');

function loadWarns() {
  try {
    if (!fs.existsSync(warnsFile)) fs.writeFileSync(warnsFile, '{}');
    const data = fs.readFileSync(warnsFile);
    return JSON.parse(data.length ? data : '{}');
  } catch {
    fs.writeFileSync(warnsFile, '{}');
    return {};
  }
}

module.exports = {
  command: 'انذارات',
  description: '📋 عرض عدد إنذارات العضو',
  usage: '.انذارات @العضو',
  groupOnly: true,

  async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
            const groupId = msg.key.remoteJid;

    if (!groupId.endsWith('@g.us')) {
      return sock.sendMessage(groupId, { text: '❌ هذا الأمر يعمل في الجروبات فقط' }, { quoted: msg });
    }

    const mention = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
    if (!mention) {
      return sock.sendMessage(groupId, {
        text: '❌ منشن عضو لعرض عدد إنذاراته.\nمثال:\n.انذارات @العضو'
      }, { quoted: msg });
    }

    const warns = loadWarns();
    const count = warns?.[groupId]?.[mention] || 0;

    return sock.sendMessage(groupId, {
      text: `📋 @${mention.split('@')[0]} لديه ${count} من 3 إنذارات.`,
      mentions: [mention]
    }, { quoted: msg });
  }
};