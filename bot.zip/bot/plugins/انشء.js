const { isElite } = require('../haykala/elite');
const fs = require('fs');
const path = require('path');

module.exports = {
  command: 'انشئ',
  category: 'tools',
  description: '✨ ينشئ جروب واحد للنخبة فقط، بالاسم اللي تكتبه أو "جروب جديد 🐊" إذا ما كتبتش',

  async execute(sock, msg) {
    const sender = msg.key.participant || msg.participant || msg.key.remoteJid;

    if (!isElite(sender)) {
      return await sock.sendMessage(msg.key.remoteJid, {
        text: '🚫 ليس لديك صلاحية لاستخدام هذا الأمر!'
      }, { quoted: msg });
    }

    try {
      // جلب النص الكامل بعد الأمر (داعم للحالات المختلفة)
      let fullMessage = '';
      if (msg.message) {
        fullMessage = msg.message.conversation
          || (msg.message.extendedTextMessage && msg.message.extendedTextMessage.text)
          || (typeof msg.text === 'string' && msg.text)
          || '';
      }
      const commandLength = '.انشئ'.length; // طول الأمر
      const groupNameInput = fullMessage.slice(commandLength).trim(); // كل اللي بعد الأمر
      const groupName = groupNameInput.length > 0 ? groupNameInput : 'جروب جديد 🐊';
      const participants = []; // ممكن تضيف أرقام النخبة لو حابب

      // إنشاء الجروب
      const group = await sock.groupCreate(groupName, participants);

      // محاولة رفع صورة الجروب (لو موجودة) — لكن لو فشلت هنتجاهل الخطوة ونكمل
      const imgPath = path.join(__dirname, '..', 'image.jpeg');
      let imageFailed = false;
      if (fs.existsSync(imgPath)) {
        try {
          const buffer = fs.readFileSync(imgPath);
          await sock.updateProfilePicture(group.id, buffer);
        } catch (imgErr) {
          imageFailed = true;
          console.error('⚠️ لم يتم رفع صورة الجروب — تم تجاهل الخطوة:', imgErr);
        }
      }

      // جلب رابط الدعوة
      const inviteCode = await sock.groupInviteCode(group.id);

      // رسالة النجاح (مع ملاحظة لو الصورة ما ارتفعتش)
      let successText = `✅ تم إنشاء الجروب بنجاح!\n📎 رابط الدعوة: https://chat.whatsapp.com/${inviteCode}`;
      if (imageFailed) {
        successText += `\n\n⚠️ ملاحظة: لم أتمكّن من رفع صورة الجروب، تم إنشاء الجروب بدون صورة.`;
      }

      await sock.sendMessage(msg.key.remoteJid, { text: successText }, { quoted: msg });

    } catch (error) {
      console.error('❌ خطأ أثناء إنشاء الجروب:', error);
      await sock.sendMessage(msg.key.remoteJid, {
        text: '⚠️ حدث خطأ أثناء محاولة إنشاء الجروب!'
      }, { quoted: msg });
    }
  }
};