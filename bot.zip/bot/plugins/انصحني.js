const config = require('../config');
const animes = [
  {
    title: 'Vivy: Fluorite Eye’s Song',
    mood: ['كئيب', 'حزين', 'دراما', 'موسيقى'],
    genre: 'دراما، خيال علمي',
    episodes: 13,
    reason: 'عميق، حزين، موسيقى رائعة، ورسم مبهر.',
    trailer: 'https://www.youtube.com/watch?v=1HAGuju_yKY'
  },
  {
    title: 'Gintama',
    mood: ['مضحك', 'كوميدي', 'ساخر', 'ضحك'],
    genre: 'كوميدي، أكشن، ساخر',
    episodes: 'كثير 😅',
    reason: 'أكثر أنمي يضحكك، شخصيات مجنونة، نكت بدون فلتر.',
    trailer: 'https://www.youtube.com/watch?v=FoBfXvlOR6M'
  },
  {
    title: 'Made in Abyss',
    mood: ['غامض', 'دموي', 'كئيب', 'خيال مظلم'],
    genre: 'مغامرة، فانتازيا، دراما',
    episodes: 13,
    reason: 'أنمي غامض وظاهره لطيف لكنه صادم جداً.',
    trailer: 'https://www.youtube.com/watch?v=6k0JuZei5_4'
  },
  {
    title: 'Horimiya',
    mood: ['رومانسي', 'مدرسي', 'خفة', 'لطيف'],
    genre: 'رومانسي، كوميدي، مدرسي',
    episodes: 13,
    reason: 'أنمي لطيف وسريع يخليك تبتسم طول الوقت.',
    trailer: 'https://www.youtube.com/watch?v=IYHz0VuwuF0'
  },
  {
    title: 'Chainsaw Man',
    mood: ['دموي', 'اكشن', 'جنون', 'ساخر'],
    genre: 'أكشن، رعب، دموي، خيال',
    episodes: 12,
    reason: 'دم، وحوش، جنون... وأكثر! لمحبي الأكشن الصادم.',
    trailer: 'https://www.youtube.com/watch?v=eyonP1AgC0k'
  },
  {
    title: 'Death Note',
    mood: ['نفسي', 'غامض', 'فلسفي'],
    genre: 'غموض، نفسي، شونين، تحقيق',
    episodes: 37,
    reason: 'عقليات بتتصادم، صراع عباقرة، وتمثيل عدالة مزيف.',
    trailer: 'https://www.youtube.com/watch?v=NlJZ-YgAt-c'
  },
  {
    title: 'Attack on Titan',
    mood: ['اكشن', 'دموي', 'كئيب', 'نهاية حزينة'],
    genre: 'أكشن، دراما، فانتازيا مظلمة',
    episodes: '87 + Final Season',
    reason: 'صراع البقاء، مؤامرات، نضج الشخصيات وأحداث مصيرية.',
    trailer: 'https://www.youtube.com/watch?v=M_OauHnAFc8'
  },
  {
    title: 'Your Lie in April',
    mood: ['رومانسي', 'دراما', 'حزين', 'موسيقى'],
    genre: 'دراما، موسيقى، رومانسي',
    episodes: 22,
    reason: 'مؤثر جدًا، موسيقى جميلة، ونهاية تبكي الحجر.',
    trailer: 'https://www.youtube.com/watch?v=3aL0gDZtFbE'
  },
  {
    title: 'Steins;Gate',
    mood: ['نفسي', 'غامض', 'فلسفي', 'خيال علمي'],
    genre: 'خيال علمي، نفسي، دراما',
    episodes: '24 + OVA',
    reason: 'تلاعب بالزمن، جنون عبقري، أحداث تقلب دماغك.',
    trailer: 'https://www.youtube.com/watch?v=UqCxygSF5rs'
  },
  {
    title: 'Mob Psycho 100',
    mood: ['مضحك', 'قوة خارقة', 'نمو شخصي'],
    genre: 'أكشن، كوميدي، نفسي، شونين',
    episodes: '3 مواسم',
    reason: 'أنمي كوميدي لكن عميق جدًا، عن النضج والقوة الحقيقية.',
    trailer: 'https://www.youtube.com/watch?v=CdqoNKCCt7A'
  },
  {
    title: 'Parasyte',
    mood: ['دموي', 'كئيب', 'نفسي', 'فلسفي'],
    genre: 'رعب، أكشن، نفسي',
    episodes: 24,
    reason: 'مخلوقات غريبة، صراع الإنسان والهوية، وأكشن رهيب.',
    trailer: 'https://www.youtube.com/watch?v=7cLsRfjZfEc'
  },
  {
    title: 'Tokyo Ghoul',
    mood: ['كئيب', 'دموي', 'حزين', 'نفسي'],
    genre: 'أكشن، دراما، رعب نفسي',
    episodes: '4 مواسم',
    reason: 'رحلة كين من طالب عادي إلى وحش ممزق بين عالمين، كلها ألم وهوية مكسورة.',
    trailer: 'https://www.youtube.com/watch?v=7aMOurgDB-o'
  },
  {
    title: 'Clannad: After Story',
    mood: ['حزين', 'دراما', 'عاطفي', 'كآبة'],
    genre: 'دراما، رومانسي، عائلي',
    episodes: 25,
    reason: 'أحد أكثر الأنميات المؤثرة نفسيًا، بيكسر القلب ويلمسه في نفس الوقت.',
    trailer: 'https://www.youtube.com/watch?v=K1IjOa5u5nM'
  },
  {
    title: 'I Want to Eat Your Pancreas',
    mood: ['حزين', 'دراما', 'رومانسي', 'نهاية حزينة'],
    genre: 'دراما، رومانسي، مدرسي',
    episodes: 'فيلم',
    reason: 'قصة حب حزينة بين شخصين من عالمين مختلفين، ونهاية تهد جبال.',
    trailer: 'https://www.youtube.com/watch?v=xnMTCcVKrkE'
  },
  {
    title: 'Orange',
    mood: ['دراما', 'حزين', 'مدرسي', 'نفسي'],
    genre: 'دراما، نفسي، خيال بسيط',
    episodes: 13,
    reason: 'رسالة من المستقبل لمحاولة إنقاذ صديق من الانتحار، مليان مشاعر.',
    trailer: 'https://www.youtube.com/watch?v=4aU9Vr0mQyo'
  }
];

module.exports = {
    category: 'fun',
  command: ['انصحني'],
    description: 'اقتراح أنمي بناءً على حالتك أو مزاجك!',
  usage: '.انصحني [مودك - مثال: كئيب، ضحك، دموي...]',

  async execute(sock, msg, args = []) {
    const text = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
    const input = text.replace(/^\.?انصحني\s*/i, '').trim().toLowerCase();

    if (!input) {
      await sock.sendMessage(msg.key.remoteJid, {
        text: '🧠 اكتب مودك بعد الأمر\nمثال:\n`.انصحني ضحك`\n`.انصحني رومانسي كئيب`',
      }, { quoted: msg });
      return;
    }

    const moodArray = input.split(/\s+/);

    const results = animes.filter(anime =>
      anime.mood.some(m => moodArray.includes(m))
    );

    if (results.length === 0) {
      await sock.sendMessage(msg.key.remoteJid, {
        text: '❌ ملقتش أنمي بالمود اللي كتبته 😔\nجرب كلمات زي: كئيب، ضحك، دموي، رومانسي، ساخر...',
      }, { quoted: msg });
      return;
    }

    const pick = results[Math.floor(Math.random() * results.length)];

    const reply = `🎬 *أنمي مقترح ليك: ${pick.title}*\n\n` +
      `🎭 التصنيف: ${pick.genre}\n` +
      `📺 عدد الحلقات: ${pick.episodes}\n` +
      `✨ ليه؟ ${pick.reason}\n` +
      `🎥 التريلر: ${pick.trailer}`;

    await sock.sendMessage(msg.key.remoteJid, { text: reply }, { quoted: msg });
  }
};