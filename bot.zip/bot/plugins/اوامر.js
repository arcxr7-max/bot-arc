const config = require('../config');
const fs = require('fs');
const path = require('path');

module.exports = {
    status: "on",
    name: 'Bot Commands',
    command: ['اوامر'],
    category: 'tools',
    description: 'قائمة الأوامر بحسب الفئة المتاحة',
    hidden: false,
    version: '3.5',

    async execute(sock, msg) {
        try {
            const body = msg.message?.extendedTextMessage?.text || msg.message?.conversation || '';
            const args = body.trim().split(/\s+/).slice(1);

            const categories = {};
            const pluginsDir = path.join(process.cwd(), 'plugins');

            // متغير لحساب إجمالي جميع الأوامر في البوت
            let totalBotCommands = 0;

            if (fs.existsSync(pluginsDir)) {
                const files = fs.readdirSync(pluginsDir).filter(f => f.endsWith('.js'));

                await sock.sendMessage(msg.key.remoteJid, { react: { text: "⛩️", key: msg.key } });

                for (const file of files) {
                    try {
                        const filePath = path.join(pluginsDir, file);
                        delete require.cache[require.resolve(filePath)];
                        const plugin = require(filePath);

                        if (!plugin || plugin.hidden) continue;

                        let category = plugin.category?.toLowerCase() || 'others';
                        const cmdName = Array.isArray(plugin.command) ? plugin.command[0] : plugin.command;

                        if (!cmdName) continue;

                        if (!categories[category]) categories[category] = [];

                        let commandDisplay = '';
                        if (Array.isArray(plugin.command) && plugin.command.length > 1) {
                            commandDisplay = `- ${plugin.command.map(cmd => `\`${cmd}\``).join(' - ')}`;
                        } else {
                            commandDisplay = `- \`${cmdName}\``;
                        }

                        if (plugin.description) {
                            commandDisplay += `\n> ${plugin.description}`;
                        }

                        categories[category].push(commandDisplay);
                        totalBotCommands++; 
                    } catch (e) {
                        continue;
                    }
                }
            }

            const imageUrl = 'https://raw.githubusercontent.com/arcxr7-max/ARC/refs/heads/main/Picsart_26-05-22_02-25-22-504.jpg';
            const targetChat = msg.key.remoteJid;
            const userMention = [msg.key.participant || msg.key.remoteJid];

            // 1️⃣ عرض كل الأوامر دفعة واحدة
            if (args[0]?.toLowerCase() === 'all' || args[0]?.toLowerCase() === 'كل') {
                let allMenu = `╭─𝗖𝗔𝗧𝗘𝗚𝗢𝗥𝗜𝗘𝗦:\n`;
                const sortedCategories = Object.keys(categories).sort();
                let totalCommands = 0;

                for (const cat of sortedCategories) {
                    const cmdCount = categories[cat].length;
                    totalCommands += cmdCount;
                    allMenu += `│ ◦ \`${cat.toUpperCase()} - ${cmdCount}\`\n`;
                    allMenu += categories[cat].join('\n\n');
                    allMenu += '\n│\n';
                }

                allMenu += `╰─𝗔𝗥𝗖𝗘𝗡`;
                allMenu += `\n\n📊 إجمالي الأوامر: \`${totalCommands}\``;

                return await sock.sendMessage(targetChat, {
                    image: { url: imageUrl },
                    caption: allMenu,
                    mentions: userMention
                }, { quoted: msg });
            }

            // 2️⃣ عرض فئة محددة طلبها المستخدم
            if (args.length > 0) {
                const requestedCategory = args.join(' ').toLowerCase();

                if (!categories[requestedCategory]) {
                    return await sock.sendMessage(targetChat, {
                        text: `❌ الفئة \`${requestedCategory}\` غير موجودة.\nاكتب \`.اوامر\` لعرض الفئات المتوفرة.`
                    }, { quoted: msg });
                }

                let menu = `╭─𝗖𝗔𝗧𝗘𝗚𝗢𝗥𝗜𝗘𝗦:\n`;
                menu += `│ ◦ \`${requestedCategory.toUpperCase()} - ${categories[requestedCategory].length}\`\n\n`;
                menu += categories[requestedCategory].join('\n\n');
                menu += '\n╰─𝗔𝗥𝗖𝗘𝗡';

                return await sock.sendMessage(targetChat, {
                    image: { url: imageUrl },
                    caption: menu,
                    mentions: userMention
                }, { quoted: msg });
            }

            // 3️⃣ القائمة الرئيسية الحالية المنسقة بالتصميم الجديد بالظبط 💎
            let menu = `╭─𝗖𝗔𝗧𝗘𝗚𝗢𝗥𝗜𝗘𝗦:\n`;
            menu += `│ ◦ \`ALL - ${totalBotCommands}\`\n`;

            Object.keys(categories).sort().forEach(cat => {
                const count = categories[cat].length; 
                menu += `│ ◦ \`${cat.toUpperCase()} - ${count}\`\n`;
            });

            menu += '╰─𝗔𝗥𝗖𝗘𝗡\n\n';
            menu += 'اكتب \`.اوامر [فئة]\` لعرض أوامرها.';

            await sock.sendMessage(targetChat, {
                image: { url: imageUrl },
                caption: menu,
                mentions: userMention
            }, { quoted: msg });

        } catch (error) {
            console.error('❌ Menu Fatal Error:', error);
            await sock.sendMessage(msg.key.remoteJid, { text: '❌ حدث خطأ داخلي أثناء استخراج القائمة.' }, { quoted: msg });
        }
    }
};