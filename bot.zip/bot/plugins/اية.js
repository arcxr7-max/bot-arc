const axios = require('axios');

module.exports = {
    command: ['اية'],
    category: 'islamic',
    description: '🕌 جلب آية قرآنية عشوائية',

    async execute(sock, msg) {
        try {
            const from = msg.key.remoteJid;

            // التفاعل التلقائي بقلب أبيض على رسالة المستخدم 🤍
            await sock.sendMessage(from, { react: { text: "🤍", key: msg.key } });

            // رابط مستودع GitHub موثوق يحتوي على القرآن الكريم كاملاً مصنفاً
            const githubUrl = 'https://raw.githubusercontent.com/arcxr7-max/ARC/refs/heads/main/aya.json';
            
            // جلب البيانات من GitHub
            const response = await axios.get(githubUrl);
            const quranData = response.data;

            if (!quranData || quranData.length === 0) {
                throw new Error('لم يتم جلب البيانات بشكل صحيح');
            }

            // اختيار سورة وآية عشوائية
            const randomSurah = quranData[Math.floor(Math.random() * quranData.length)];
            const randomAyah = randomSurah.verses[Math.floor(Math.random() * randomSurah.verses.length)];

            // 💎 التنسيق النهائي: البسملة والآية بخط عريض، السطر الأخير مائل مع فراغات متناسقة
            const quranMessage = `
*﷽*


*﴿ ${randomAyah.text} ﴾*


. . . . . . . . . . . . . . . . . . . . .


_▫️ سورة ${randomSurah.name} ꘎ الآية ${randomAyah.id}_
`.trim();

            // إرسال الآية مباشرة للمستخدم مع إلغاء التنسيق التلقائي
            await sock.sendMessage(from, { text: quranMessage }, { quoted: msg, noFormat: true });

        } catch (error) {
            console.error('❌ خطأ في جلب الآية من GitHub:', error);
            await sock.sendMessage(msg.key.remoteJid, { 
                text: '❌ عذراً، تعذر جلب الآية الكريمة حالياً. يرجى المحاولة مرة أخرى لاحقاً.' 
            }, { quoted: msg });
        }
    }
};