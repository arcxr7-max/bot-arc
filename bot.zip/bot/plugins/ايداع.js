const config = require('../config');
const fs = require('fs');
const path = require('path');

const pointsFile = path.join(__dirname, '../data/points.json');
const protectedFile = path.join(__dirname, '../data/protected.json');
const accountsFile = path.join(__dirname, '../data/bankAccounts.json');

function getPoints() {
    if (!fs.existsSync(pointsFile)) return {};
    return JSON.parse(fs.readFileSync(pointsFile, 'utf8'));
}

function savePoints(points) {
    fs.writeFileSync(pointsFile, JSON.stringify(points, null, 2));
}

function getProtected() {
    if (!fs.existsSync(protectedFile)) return {};
    return JSON.parse(fs.readFileSync(protectedFile, 'utf8'));
}

function saveProtected(data) {
    fs.writeFileSync(protectedFile, JSON.stringify(data, null, 2));
}

function getAccounts() {
    if (!fs.existsSync(accountsFile)) return {};
    return JSON.parse(fs.readFileSync(accountsFile, 'utf8'));
}

module.exports = {
    category: 'bank',
    command: 'ايداع',
    description: '💰 إيداع نقود في البنك',
    usage: '.ايداع [المبلغ]',
    
    async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
                const chatId = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;
        const senderNumber = sender.split('@')[0];

        // قراءة النص مباشرة
        let fullText = '';
        if (msg.message?.conversation) fullText = msg.message.conversation;
        else if (msg.message?.extendedTextMessage?.text) fullText = msg.message.extendedTextMessage.text;
        else fullText = '';

        const withoutCommand = fullText.replace(/^\.ايداع\s*/, '').trim();
        const amount = parseInt(withoutCommand);

        let points = getPoints();
        let protected = getProtected();
        let accounts = getAccounts();
        
        const currentPoints = points[senderNumber] || 0;
        const currentProtected = protected[senderNumber] || 0;
        const bankName = accounts[senderNumber]?.bankName || 'البنك';
        const available = currentPoints - currentProtected;

        // عرض الرصيد
        if (isNaN(amount) || amount <= 0) {
            return sock.sendMessage(chatId, { 
                text: `💰 رصيدك: ${currentPoints} نقطة\n🏦 في البنك: ${currentProtected} نقطة\n\nاستخدم: .ايداع [المبلغ]`
            }, { quoted: msg });
        }

        if (amount < 10) {
            return sock.sendMessage(chatId, { text: `❌ الحد الأدنى 10 نقاط` }, { quoted: msg });
        }

        if (amount > available) {
            return sock.sendMessage(chatId, { text: `❌ معك بس ${available} نقطة` }, { quoted: msg });
        }

        // تنفيذ الإيداع
        protected[senderNumber] = currentProtected + amount;
        saveProtected(protected);

        await sock.sendMessage(chatId, {
            text: `✅ تم إيداع ${amount} نقطة في ${bankName}`
        }, { quoted: msg });
    }
};