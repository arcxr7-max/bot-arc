const fs = require('fs-extra');
const path = require('path');

// مسار ملف النقاط الخاص بالبوت المتوافق مع الهاندلر
const pointsFile = path.join(__dirname, '../data/points.json');

// 🌐 رابط الـ Raw المباشر لملف الـ JSON الخاص بك على GitHub
const GITHUB_DATA_URL = 'https://raw.githubusercontent.com/arcxr7-max/ARC/refs/heads/main/anime_emoji_game.json';

let cachedGameData = null;

async function fetchGameData() {
    if (cachedGameData) return cachedGameData;
    try {
        const response = await fetch(GITHUB_DATA_URL);
        if (!response.ok) throw new Error('فشل الاتصال بقيت هاب');
        cachedGameData = await response.json();
        return cachedGameData;
    } catch (error) {
        console.error('❌ خطأ في جلب لعبة الإيموجي من GitHub:', error);
        return null;
    }
}

module.exports = {
    category: 'game',
    command: 'ايمو',
    description: 'لعبة تخمين شخصيات الأنمي من خلال الإيموجي.',
    
    async execute(sock, message) {
        const from = message.key.remoteJid;

        // تهيئة الكائن العالمي للألعاب من خارج المستمعات لضمان ثبات الجلسة
        if (!global.animeEmojiGame) global.animeEmojiGame = {};

        // التحقق من وجود لعبة نشطة
        if (global.animeEmojiGame[from]) {
            return await sock.sendMessage(from, { text: '⚠️ هناك لعبة قائمة بالفعل في هذه المجموعة! أجب عليها أولاً.' }, { quoted: message });
        }

        const gameData = await fetchGameData();
        if (!gameData || gameData.length === 0) {
            return await sock.sendMessage(from, { text: '❌ حدث خطأ أثناء جلب الأسئلة من GitHub.' }, { quoted: message });
        }

        const randomQuestion = gameData[Math.floor(Math.random() * gameData.length)];
        const correctAnswer = randomQuestion.response.trim().toLowerCase();

        const questionText = `
╭━━━〔 🎮 خَمِّنْ الإيمُوجِي 〕━━━╮

🧩 خمن اسم شخصية الأنمي من الإيموجي التالي:
👉  ${randomQuestion.question}

💰 الجائزة: +500 نقطة
⏰ الوقت: 30 ثانية للإجابة

╰━━━━━━━━━━━━━━━━━━━━╯
        `.trim();

        await sock.sendMessage(from, { text: questionText }, { quoted: message });

        // مؤقت الـ 30 ثانية
        const timer = setTimeout(async () => {
            if (global.animeEmojiGame[from]) {
                delete global.animeEmojiGame[from];
                await sock.sendMessage(from, { text: `⏰ انتهى الوقت! ولم يعرف أحد الإجابة.\n\n💡 الإجابة الصحيحة هي: *${randomQuestion.response}*` });
            }
        }, 30000);

        // ⚙️ حياكة الجلسة مباشرة لتلتقطها مستمعات الهاندلر الذكية دون وسيط الذاكرة
        global.animeEmojiGame[from] = {
            answer: correctAnswer,
            response: randomQuestion.response,
            timer: timer
        };
    }
};