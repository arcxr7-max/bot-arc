const fs = require('fs');
const path = require('path');

// مسار ملف النقاط
const pointsFile = path.join(__dirname, '../data/points.json');

const emojis = [
  // وجوه وتعبيرات
  "😀", "😃", "😄", "😁", "😆", "😅", "🤣", "😂", "🙂", "🙃", "😉", "😊", "😇", "🥰", "😍", "🤩", "😘", "😗", "😚", "😙", "😋", "😛", "😜", "🤪", "😝", "🤑", "🤗", "🤭", "🤫", "🤔", "🤐", "🤨", "😐", "😑", "😶", "😏", "😒", "🙄", "😬", "🤥", "😌", "😔", "😪", "🤤", "😴", "😷", "🤒", "🤕", "🤢", "🤮", "🤧", "🥵", "🥶", "🥴", "😵", "🤯", "🤠", "🥳", "😎", "🤓", "🧐", "😕", "😟", "🙁", "😮", "😯", "😲", "😳", "🥺", "😦", "😧", "😨", "😰", "😥", "😢", "😭", "😱", "😈", "👿", "💀", "👻", "👽", "👾", "🤖",
  // قلوب وحركات
  "😺", "😸", "😹", "😻", "😼", "😽", "💘", "💝", "💖", "💗", "💓", "💞", "💕", "💟", "❣️", "💔", "❤️", "🧡", "💛", "💚", "💙", "💜", "🖤", "🤍", "🤎", "💯", "💢", "💥", "💫", "💦", "💨", "💣", "💬", "💭", "💤",
  // يد وجسم
  "👋", "🤚", "🖐️", "✋", "🖖", "👌", "🤏", "✌️", "🤞", "🤟", "🤘", "🤙", "👈", "👉", "👆", "👇", "☝️", "👍", "👎", "✊", "👊", "🤛", "🤜", "👏", "🙌", "👐", "🤲", "🤝", "🙏", "✍️", "💪", "🦾", "👂", "👃", "🧠", "🦷", "👀", "👁️", "👅", "👄",
  // حيوانات وطبيعة
  "🌵", "🎄", "🌲", "🌳", "🌴", "🌱", "🌿", "☘️", "🍀", "🍃", "🍂", "🍁", "🍄", "🐚", "💐", "🌷", "🌹", "🥀", "🌺", "🌸", "🌼", "🌻", "🌞", "🌝", "🌙", "🌎", "🌍", "🌏", "🪐", "💫", "⭐️", "🌟", "✨", "⚡️", "🔥", "🌪️", "🌈", "☀️", "🌤️", "⛅️", "🌥️", "☁️", "🌦️", "🌧️", "⛈️", "🌩️", "🌨️", "❄️", "🌊",
  // حيوانات
  "🐶", "🐱", "🐭", "🐹", "🐰", "🦊", "🐻", "🐼", "🐨", "🐯", "🦁", "🐮", "🐷", "🐸", "🐵", "🐒", "🐔", "🐧", "🐦", "🐤", "🐣", "🐥", "🦆", "🦅", "🦉", "🦇", "🐺", "🐗", "🐴", "🦄", "🐝", "🐛", "🦋", "🐌", "🐞", "🐜", "🐢", "🐍", "🦎", "🦖", "🦕", "🐙", "🦑", "🦐", "🦀", "🐡", "🐠", "🐟", "🐬", "🐳", "🐋", "🦈", "🐅", "🐆", "🦓", "🦍", "🐘", "🦛", "🦏", "🐪", "🐫", "🦒", "🦘", "🐎", "🐖", "🐏", "🐑", "🦙", "🐐", "🦌", "🐕", "🐈", "🐓", "🦃", "🦚", "🦜", "🦢", "🦩", "🕊️", "🐇", "🦝", "🐾", "🐉", "🐲",
  // طعام وشراب
  "🍇", "🍈", "🍉", "🍊", "🍋", "🍌", " Pineapple", "🍎", "🍏", "🍐", "🍑", "🍒", "🍓", "🥝", " Tomato", "🥥", "🥑", "🍆", "🥔", "🥕", "🌽", "🌶️", "🥒", "🥬", "🥦", "🍄", "🥜", "🍞", "🥐", "🥖", "🥨", "🥯", "🥞", "🧇", "🧀", "🍖", "🍗", "🥩", "🥓", "🍔", "🍟", "🍕", "🌭", "🥪", "🌮", "🌯", "🍳", "🥘", "🍲", "🥣", "🥗", "🍿", "🍱", "🍘", "🍙", "🍚", "🍛", "🍜", "🍝", "🍣", "🍤", "🍦", "🍧", "🍨", "🍩", "🍪", "🎂", "🍰", "🧁", "🥧", "🍫", "🍬", "🍭", "🍮", "🍯", "🥛", "☕️", "🍵", "🥤", "🧊"
];

const emojiGame = {};

// دالة تحميل النقاط
function loadPoints() {
  if (!fs.existsSync(pointsFile)) fs.writeFileSync(pointsFile, '{}');
  return JSON.parse(fs.readFileSync(pointsFile));
}

// دالة حفظ النقاط
function savePoints(data) {
  fs.writeFileSync(pointsFile, JSON.stringify(data, null, 2));
}

// دالة إضافة النقاط
function addPoints(user, amount) {
  const points = loadPoints();
  points[user] = (points[user] || 0) + amount;
  savePoints(points);
  return points[user];
}

module.exports = {
  command: 'ايموجي',
  description: '🎯 تحدي الإيموجي السريع للحصول على نقاط',
  usage: 'ايموجي',
  category: 'game',

  async execute(sock, msg, args) {
    const chatId = msg.key.remoteJid;
    const senderName = msg.pushName || 'مستخدم';

    if (emojiGame[chatId]) {
      return await sock.sendMessage(chatId, {
        text: `🚫 *هناك تحدي إيموجي جاري بالفعل!*\nانتظر حتى ينتهي.\n\n╰─⟡ 𝗔𝗥𝗖𝗘𝗡`
      }, { quoted: msg });
    }

    const randomEmoji = emojis[Math.floor(Math.random() * emojis.length)];

    emojiGame[chatId] = {
      emoji: randomEmoji,
      finished: false,
      startedBy: senderName
    };

    await sock.sendMessage(chatId, {
      text: `
╭─❒ 『 *🎯 تحدي الإيموجي السريع* 』 ❒─╮

❁ *أرسل الإيموجي التالي:* ⟶ [ ${randomEmoji} ]
❁ *المطلوب:* ⟶ وضعه في رسالة بمفرده
❁ *الجائزة:* ⟶ 💰 200 نقاط

*⟬✨ أسرع واحد يرسله هو الفائز! ✨⟭*

╰─⟡ مع تحيات: 𝗔𝗥𝗖𝗘𝗡 ⦿
`
    }, { quoted: msg });

    const handler = async ({ messages }) => {
      const reply = messages[0];
      if (!reply.message) return;

      const from = reply.key.remoteJid;
      if (from !== chatId) return;
      if (reply.key.fromMe) return;

      const text = (reply.message.conversation || reply.message.extendedTextMessage?.text || '').trim();

      if (text === emojiGame[chatId].emoji && !emojiGame[chatId].finished) {
        emojiGame[chatId].finished = true;
        clearTimeout(emojiGame[chatId].timeout);

        const senderJid = reply.key.participant || reply.key.remoteJid;
        const user = senderJid.split('@')[0];
        
        // إضافة النقاط (200 نقطة)
        const totalPoints = addPoints(user, 200);

        await sock.sendMessage(chatId, {
          text: `
🎉 *كفو! استجابة سريعة جداً!*

👤 *الفائز:* @${user}
💰 *الجائزة:* +200 نقاط
📊 *رصيدك الآن:* ${totalPoints} نقطة

╰─⟡ 𝗔𝗥𝗖𝗘𝗡 ⦿
`,
          mentions: [senderJid]
        }, { quoted: reply });

        delete emojiGame[chatId];
        sock.ev.off('messages.upsert', handler);
      }
    };

    sock.ev.on('messages.upsert', handler);

    // مؤقت 30 ثانية
    emojiGame[chatId].timeout = setTimeout(async () => {
      if (emojiGame[chatId] && !emojiGame[chatId].finished) {
        await sock.sendMessage(chatId, {
          text: `⌛ *انتهى الوقت!* \n\n❁ الإيموجي كان: [ ${emojiGame[chatId].emoji} ]\n💤 يبدو أن الجميع نائمون اليوم.\n\n╰─⟡ 𝗔𝗥𝗖𝗘𝗡`
        });

        delete emojiGame[chatId];
        sock.ev.off('messages.upsert', handler);
      }
    }, 30000);
  }
};