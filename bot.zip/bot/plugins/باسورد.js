// plugins/باسورد.js
module.exports = {
    command: ['باسورد'],
    category: 'tools',
    description: '🔐 توليد كلمة مرور عشوائية وقوية جداً لحماية حساباتك',

    async execute(sock, msg) {
        try {
            const from = msg.key.remoteJid;
            const body = msg.message?.extendedTextMessage?.text || msg.message?.conversation || '';
            const args = body.trim().split(/\s+/).slice(1);
            
            // تحديد طول كلمة المرور (الافتراضي 12 حرفاً وأقصاه 32)
            let length = parseInt(args[0]) || 12;
            if (length < 8) length = 8;
            if (length > 32) length = 32;

            const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+~|}{[]:;?><,./-=";
            let password = "";
            
            // توليد الرموز عشوائياً
            for (let i = 0; i < length; i++) {
                const randomIndex = Math.floor(Math.random() * charset.length);
                password += charset[randomIndex];
            }

            const passMessage = [
                `╭───────────────────╮`,
                `🔐 *تم إنشاء كلمة مرور قوية بنجاح:*`,
                ``,
                `📏 *الطول المحدد:* ${length} حرفاً`,
                `🔑 *كلمة المرور:* \`${password}\``,
                ``,
                `💡 _اضغط على كلمة المرور لنسخها مباشرة._`,
                `╰───────────────────╯`
            ].join('\n');

            await sock.sendMessage(from, { text: passMessage }, { quoted: msg });

        } catch (error) {
            console.error(error);
        }
    }
};