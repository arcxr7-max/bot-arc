const config = require('../config');
const fs = require('fs');
const path = require('path');
const { isDev } = require('../utils/devs');

const dataDir = path.join(__dirname, '..', 'data');
const blockFile = path.join(dataDir, 'blockedUsers.json');

if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
if (!fs.existsSync(blockFile)) fs.writeFileSync(blockFile, JSON.stringify([]));

const loadBlockedUsers = () => {
    try {
        return JSON.parse(fs.readFileSync(blockFile));
    } catch {
        return [];
    }
};

const saveBlockedUsers = (data) => {
    try {
        fs.writeFileSync(blockFile, JSON.stringify(data, null, 2));
    } catch (err) {
        console.error("خطأ في حفظ ملف الحظر:", err);
    }
};

module.exports = {
    command: 'بان',
    description: '🚫 حظر أو إلغاء حظر شخص عند الرد على رسالته (للمطورين فقط)',
    usage: '.بان (رد على رسالة الشخص)',
    category: 'admin',

    async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
                        const chatId = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;
        const senderNumber = sender.split('@')[0];

        // التحقق من المطور
        if (!isDev(senderNumber)) {
            return sock.sendMessage(chatId, { 
                text: '⚠️ هذا الأمر مخصص فقط للمطورين.'
            }, { quoted: msg });
        }

        // التحقق من الرد على شخص
        const targetJid = msg.message?.extendedTextMessage?.contextInfo?.participant;

        if (!targetJid) {
            return sock.sendMessage(chatId, { 
                text: '❗ يجب الرد على رسالة الشخص المراد حظره أو إلغاء حظره.'
            }, { quoted: msg });
        }

        const blockedUsers = loadBlockedUsers();
        const targetNumber = targetJid.split('@')[0];

        if (blockedUsers.includes(targetJid)) {
            // إلغاء الحظر
            const updated = blockedUsers.filter(u => u !== targetJid);
            saveBlockedUsers(updated);
            return sock.sendMessage(chatId, { 
                text: `✅ تم إلغاء الحظر عن @${targetNumber}ِ`,
                mentions: [targetJid]
            }, { quoted: msg });
        } else {
            // حظر
            blockedUsers.push(targetJid);
            saveBlockedUsers(blockedUsers);
            return sock.sendMessage(chatId, { 
                text: `🚫 تم حظر @${targetNumber}. لن يستجيب له البوت بعد الآن.`,
                mentions: [targetJid]
            }, { quoted: msg });
        }
    }
};