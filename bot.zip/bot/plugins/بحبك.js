const config = require('../config');
const { getProfilePicture } = require("@whiskeysockets/baileys");

module.exports = {
  command: "بحبك",
  description: "رد لطيف على كلمة بحبك",
  usage: ".بحبك",
  category: "fun",

  async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
            try {
      const replies = [
        "أحبك حب البوت للأوامر 🤖❤️",
        "أنا كمان بحب نفسي 😅",
        "كلنا بنحبك هنا 💫",
      ];

      const randomReply = replies[Math.floor(Math.random() * replies.length)];
      const senderId = msg.key.participant || msg.key.remoteJid;

      let pfp = null;
      try {
        pfp = await sock.profilePictureUrl(senderId, 'image');
      } catch {}

      await sock.sendMessage(msg.key.remoteJid, {
        text: randomReply,
        contextInfo: {
          externalAdReply: {
            title: "💌 بحبك؟",
            body: "رد لطيف من 𝐌𝐔𝐒𝐀𝐒𝐇𝐈 𝐁𝐎𝐓 🪶",
            thumbnailUrl: pfp,
            mediaType: 1,
            renderLargerThumbnail: false,
            showAdAttribution: false
          }
        }
      }, { quoted: msg });

    } catch (error) {
      console.error("❌ خطأ في أمر 'بحبك':", error);
      await sock.sendMessage(msg.key.remoteJid, {
        text: `❌ حصل خطأ:\n${error.message || error.toString()}`
      }, { quoted: msg });
    }
  }
};