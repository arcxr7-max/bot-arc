const config = require('../config');
const fs = require('fs');
const { join, dirname } = require('path');

const sessionStart = Date.now();
const uptimeFilePath = join(process.cwd(), 'data', 'uptime.json');
let cachedPastUptime = null;

function getCumulativeUptime() {
    if (cachedPastUptime === null) {
        if (!fs.existsSync(dirname(uptimeFilePath))) {
            fs.mkdirSync(dirname(uptimeFilePath), { recursive: true });
        }
        if (fs.existsSync(uptimeFilePath)) {
            try {
                const data = JSON.parse(fs.readFileSync(uptimeFilePath, 'utf-8'));
                cachedPastUptime = data.totalUptime || 0;
            } catch (e) {
                cachedPastUptime = 0;
            }
        } else {
            cachedPastUptime = 0;
        }
    }

    const currentSessionTime = Date.now() - sessionStart;
    const totalMs = cachedPastUptime + currentSessionTime;

    setImmediate(() => {
        try {
            fs.writeFileSync(uptimeFilePath, JSON.stringify({ totalUptime: totalMs }), 'utf-8');
        } catch (e) {}
    });

    const minutes = Math.floor((totalMs / (1000 * 60)) % 60);
    const hours = Math.floor((totalMs / (1000 * 60 * 60)) % 24);
    const days = Math.floor(totalMs / (1000 * 60 * 60 * 24));

    // 💡 التعديل الذكي هنا: إذا تم إكمال يوم أو أكثر، يعرض الأيام فقط بدون الساعات والدقائق
    if (days > 0) {
        return `${days} ${days === 1 ? 'day' : 'days'}`;
    }

    // إذا كان وقت التشغيل أقل من يوم، يعرض الساعات والدقائق بشكل طبيعي
    let uptimeParts = [];
    if (hours > 0) uptimeParts.push(`${hours}h`);
    if (minutes > 0 || uptimeParts.length === 0) uptimeParts.push(`${minutes} min`);

    return uptimeParts.join(' - ');
}

module.exports = {
    command: ['بوت'],
    description: '⚙️ يعرض معلومات البوت والإصدار ووقت التشغيل التراكمي السريع',
    category: 'tools',

    async execute(sock, msg) {
        try {
            const zarfPath = join(process.cwd(), 'data', 'zarf.json');
            let zarfData = { reaction_status: "on", reaction: "🫀" };

            if (fs.existsSync(zarfPath)) {
                try {
                    zarfData = JSON.parse(fs.readFileSync(zarfPath, 'utf-8'));
                } catch (e) {}
            }

            if (zarfData.reaction_status === "on" && zarfData.reaction) {
                await sock.sendMessage(msg.key.remoteJid, {
                    react: { text: zarfData.reaction, key: msg.key }
                }).catch(() => {});
            }

            const pluginsDir = join(process.cwd(), 'plugins');
            let totalCommands = 0;
            if (fs.existsSync(pluginsDir)) {
                totalCommands = fs.readdirSync(pluginsDir).filter(f => f.endsWith('.js')).length;
            }

            const calculatedVersion = (totalCommands * 0.025).toFixed(2);
            const totalUptime = getCumulativeUptime();

            const infoText = `
┏━🜲 𝗕𝗢𝗧 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗧𝗜𝗢𝗡 🜲━┓
╭───〔 ⚙️ ${config.botName || '𝗔𝗥𝗖🇪🇳'} 〕───╮
│ ◦ 📦 الأوامر: \`${totalCommands}\`
│ ◦ 🛠️ الإصدار: \`v${calculatedVersion}\`
│ ◦ 👑 المطور: \`𓆰𝑬𝑴𝑷 ꙰𓃥\`
│ ◦ ⏱️ وقت التشغيل: \`${totalUptime}\`
│ ◦ 🧠 النواة: \`Node.js (Baileys)\`
╰───────────────────╯
┗━🜲 ${config.botName || '𝗔𝗥𝗖🇪🇳'} 🜲━┛
`.trim();

            const myCustomImage = "https://raw.githubusercontent.com/arcxr7-max/ARC/refs/heads/main/Picsart_26-05-25_20-12-19-554.jpg";

            await sock.sendMessage(msg.key.remoteJid, {
                image: { url: myCustomImage },
                caption: infoText,
                contextInfo: { renderLargerThumbnail: true }
            }, { quoted: msg });

        } catch (err) {
            console.error('❌ خطأ في أمر بوت:', err);
            await sock.sendMessage(msg.key.remoteJid, { text: '❌ حصل خطأ أثناء عرض معلومات البوت.' }, { quoted: msg });
        }
    }
};