const config = require('../config');
const { eliteNumbers } = require('../haykala/elite.js');
const { jidDecode } = require('@whiskeysockets/baileys');

const decode = jid => (jidDecode(jid)?.user || jid.split('@')[0]) + '@s.whatsapp.net';

function getPureNumber(jid) {
    try {
        const decoded = jidDecode(jid);
        if (decoded && decoded.user) {
            return decoded.user.replace(/[^0-9]/g, '');
        }
    } catch(e) {}
    return jid.split('@')[0].replace(/[^0-9]/g, '');
}

module.exports = {
    command: 'بوسو',
    description: 'يرفع كل أعضاء المجموعة إلى مشرفين دفعة واحدة',
    usage: '.بوسو',
    category: 'admin',

    async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
                
        
        
        
        
                try {
            const groupJid = msg.key.remoteJid;

            if (!groupJid.endsWith('@g.us')) {
                return sock.sendMessage(groupJid, { text: '❗ هذا الأمر يعمل فقط داخل المجموعات.' }, { quoted: msg });
            }

            const sender = msg.key.participant || msg.key.remoteJid;
            const senderNumber = getPureNumber(sender);

            const isElite = eliteNumbers.includes(senderNumber);
            
            if (!isElite) {
                return sock.sendMessage(groupJid, { text: '❗ لا تملك صلاحية استخدام هذا الأمر.' }, { quoted: msg });
            }

            const groupMetadata = await sock.groupMetadata(groupJid);
            const botNumber = getPureNumber(sock.user.id);

            const toPromote = groupMetadata.participants
                .filter(p => !p.admin && getPureNumber(p.id) !== botNumber)
                .map(p => p.id);

            if (toPromote.length === 0) {
                return sock.sendMessage(groupJid, { text: '⚠️ لا يوجد أعضاء غير مشرفين.' }, { quoted: msg });
            }

            await sock.groupParticipantsUpdate(groupJid, toPromote, 'promote');

            await sock.sendMessage(groupJid, { 
                text: `🗿`
            }, { quoted: msg });

        } catch (err) {
            console.error('❌ خطأ:', err);
            
            if (err.message?.includes('forbidden')) {
                await sock.sendMessage(msg.key.remoteJid, { 
                    text: '❌ البوت ليس أدمن في هذه المجموعة! قم بترقية البوت أولاً.'
                }, { quoted: msg });
            } else {
                await sock.sendMessage(msg.key.remoteJid, { 
                    text: `❌ حدث خطأ: ${err.message || err.toString()}`
                }, { quoted: msg });
            }
        }
    }
};