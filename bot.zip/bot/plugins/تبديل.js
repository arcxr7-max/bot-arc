const fs = require('fs');
const path = require('path');
const { isDev } = require('../utils/devs');
const { getPlugins } = require('../handlers/plugins.js');

module.exports = {
command: 'تبديل',
category: 'control',
description: '🔐 تغيير صلاحية أمر مفرد أو فئة كاملة من الأوامر مباشرة من داخل السورس كود',
usage: '.تبديل [الأمر أو الفئة] [all/admin/both/dev]',

async execute(sock, msg) {

const chatId = msg.key.remoteJid;
const sender = (msg.key.participant || msg.key.remoteJid).split('@')[0];

// 🛡️ رسالة الحماية المعدلة بناءً على طلبك دون أي تغيير آخر
if (!isDev(sender)) {
return sock.sendMessage(chatId, { text: '⚠️ ┋ عذراً، هذا الأمر مخصص للمطور الأساسي فقط!' }, { quoted: msg });
}

const body = msg.message?.extendedTextMessage?.text || msg.message?.conversation || '';
const args = body.trim().split(/\s+/).slice(1);

const target = args[0]?.toLowerCase().trim();
const newLevel = args[1]?.toLowerCase().trim();

if (!target || !newLevel) {
return sock.sendMessage(chatId, {
text: '💡 طريقة الاستخدام الذكية:\n' +
'• لتغيير أمر مفرد: `.تبديل [اسم الأمر] [المستوى]`\n' +
'• لتغيير فئة كاملة: `.تبديل [اسم الفئة] [المستوى]`\n\n' +
'المستويات المتاحة:\n' +
'• `all` ➜ للكل 👥\n' +
'• `admin` ➜ للمشرفين، النخبة، والمطور 🛡️\n' +
'• `both` ➜ للنخبة والمطور فقط 🜲\n' +
'• `dev` ➜ للمطور الأساسي فقط ⚙️\n\n' +
'أمثلة:\n' +
'▫️ `.تبديل سرقة dev` (تأمين أمر مفرد)\n' +
'▫️ `.تبديل control both` (تأمين التحكم بالكامل)'
}, { quoted: msg });
}

const validLevels = ['all', 'admin', 'both', 'dev'];
if (!validLevels.includes(newLevel)) {
return sock.sendMessage(chatId, { text: '❌ مستوى الصلاحية غير صحيح! اختر من بين: (all, admin, both, dev)' }, { quoted: msg });
}

const pluginsDir = path.join(process.cwd(), 'plugins');
let affectedFiles = new Set();
let matchedType = 'أمر مفرد';

// 📁 عمل مسح حركي وشامل لجميع الملفات لمعرفة مساراتها الفيزيائية الحقيقية
let allJsFiles = [];
function scanAllPlugins(dir) {
if (!fs.existsSync(dir)) return;
const items = fs.readdirSync(dir);
for (const item of items) {
const fullPath = path.join(dir, item);
if (fs.lstatSync(fullPath).isDirectory()) {
scanAllPlugins(fullPath);
} else if (item.endsWith('.js')) {
allJsFiles.push({ path: fullPath, name: item });
}
}
}
scanAllPlugins(pluginsDir);

// 🧲 دالة الحقن الذكي داخل ملف السورس كود
function injectOrUpdatePerm(filePath, level) {
try {
if (!fs.existsSync(filePath)) return false;
let content = fs.readFileSync(filePath, 'utf-8');
const permRegex = /const\s+_cR\s=\s['"][^'"]+['"]/g;
const newPermLine = `const _cR = 'dev'`;

if (content.includes('=== ARC PERM START ===')) {
content = content.replace(permRegex, newPermLine);
} else {
const executeRegex = /async\s+execute\s\(\ssock\s,\smsg\s\)\s\{/;
if (!executeRegex.test(content)) return false;

const injectCode = `async execute(sock, msg) {
`;

content = content.replace(executeRegex, injectCode);
}

fs.writeFileSync(filePath, content, 'utf-8');
return true;
} catch (e) {
return false;
}
}

// 🧠 جلب الأوامر من ذاكرة البوت الاحتياطية لتحديد إذا كان الاختيار أمراً مفرداً
let allPlugins = {};
try { allPlugins = getPlugins() || {}; } catch (e) {}

// الفحص البرميجي: هل الهدف المكتوب هو فئة مسجلة؟
const isCategory = Object.values(allPlugins).some(p => p?.category?.toLowerCase().trim() === target);

// 🛠️ استراتيجية الفحص الفيزيائي للمجلدات
let targetFiles = [];

if (isCategory || target === 'control') {
matchedType = `فئة كاملة [ ${target.toUpperCase()} ]`;
// فحص كل ملفات البوت والتقاط أي ملف ينتمي لهذه الفئة برمجياً عبر الـ سورس كود
for (const file of allJsFiles) {
try {
const content = fs.readFileSync(file.path, 'utf-8');
const catRegex = /category\s:\s['"`]([^'"`]+)['"`]/i;
const match = content.match(catRegex);
if (match && match[1].toLowerCase().trim() === target) {
targetFiles.push(file);
}
} catch (e) {}
}
} else {
// إذا كان أمراً مفرداً، نبحث عن الملف الحاضن له
matchedType = `أمر مفرد [ .${target} ]`;
for (const file of allJsFiles) {
try {
const content = fs.readFileSync(file.path, 'utf-8');
if (content.includes(`'${target}'`) || content.includes(`"${target}"`) || content.includes(`\`${target}\``)) {
targetFiles.push(file);
break;
}
} catch (e) {}
}
}

if (targetFiles.length === 0) {
return sock.sendMessage(chatId, { text: `❌ لم يتم العثور على أي ملفات برمجية تطابق الفئة أو الأمر \`.${target}\`` }, { quoted: msg });
}

// تنفيذ الحقن النهائي على القائمة الكاملة المستخرجة فيزيائياً
for (const file of targetFiles) {
const success = injectOrUpdatePerm(file.path, newLevel);
if (success) affectedFiles.add(file.name);
}

const levelNames = { all: 'الكل 👥', admin: 'المشرفين 🛡️', both: 'النخبة والمطور 🜲', dev: 'المطور فقط ⚙️' };
const finalArr = Array.from(affectedFiles);

const successMsg = `
┏━🜲 <b>𝗔𝗥𝗖🇪🇳 𝗦𝗬𝗦𝗧🇪𝗠 🜲</b>━┓
╭───❒ 『 LIVE SWITCH SUCCESS 』
> 🔐 تم مسح المجلد فيزيائياً وتأمين السورس كود بنجاح!
───────────────────────
- \`النوع المكتشف:\` ${matchedType}
- \`المستوى الجديد:\` ${levelNames[newLevel]}
- \`عدد ملفات السورس المعدلة:\` ${finalArr.length} ملف كود
───────────────────────
📁 ملفات السورس الحقيقية التي تم تأمينها:
${finalArr.map(f => `▫️ \`${f}\``).join('\n')}
───────────────────────
> ✨ تم التعديل على الملفات الحاضنة للأوامر بالكامل وتجاوز فخ الذاكرة! ⦿
╰──────────────
┗━🜲 <b>𝗕𝗢𝗧 𝗖𝗢𝗡𝗧𝗥𝗢𝗟 🜲</b>━┛`.trim();

await sock.sendMessage(chatId, { text: successMsg }, { quoted: msg });
}
};