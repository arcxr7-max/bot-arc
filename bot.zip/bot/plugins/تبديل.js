const fs = require('fs');
const path = require('path');
const { isDev } = require('../utils/devs');

module.exports = {
command: 'تبديل',
category: 'control',
description: '🔐 تغيير صلاحية أمر مفرد أو فئة كاملة من الأوامر مباشرة من داخل السورس كود',
usage: '.تبديل [الأمر أو الفئة] [all/admin/both/dev]',

async execute(sock, msg) {

const chatId = msg.key.remoteJid;
const sender = (msg.key.participant || msg.key.remoteJid).split('@')[0];

// 🛡️ التحقق من المطور
if (!isDev(sender)) {
return sock.sendMessage(chatId, { text: '⚠️ ┋ عذراً، هذا الأمر مخصص للمطور الأساسي فقط!' }, { quoted: msg });
}

const body = msg.message?.extendedTextMessage?.text || msg.message?.conversation || '';
const args = body.trim().split(/\s+/).slice(1);

const target = args[0]?.toLowerCase().trim();
const newLevel = args[1]?.toLowerCase().trim();

if (!target || !newLevel) {
return sock.sendMessage(chatId, {
text: '💡 طريقة الاستخدام الذكية:\n' +
'• لتغيير أمر مفرد: `.تبديل [اسم الأمر] [المستوى]`\n' +
'• لتغيير فئة كاملة: `.تبديل [اسم الفئة] [المستوى]`\n\n' +
'المستويات المتاحة:\n' +
'• `all` ➜ للكل 👥\n' +
'• `admin` ➜ للمشرفين، النخبة، والمطور 🛡️\n' +
'• `both` ➜ للنخبة والمطور فقط 🜲\n' +
'• `dev` ➜ للمطور الأساسي فقط ⚙️\n' +
'• `del` ➜ لحذف الحماية 🗑️\n\n' +
'أمثلة:\n' +
'▫️ `.تبديل سرقة dev` (تأمين أمر مفرد)\n' +
'▫️ `.تبديل control both` (تأمين التحكم بالكامل)\n' +
'▫️ `.تبديل سرقة del` (حذف الحماية)'
}, { quoted: msg });
}

const validLevels = ['all', 'admin', 'both', 'dev', 'del'];
if (!validLevels.includes(newLevel)) {
return sock.sendMessage(chatId, { text: '❌ مستوى الصلاحية غير صحيح! اختر من بين: (all, admin, both, dev, del)' }, { quoted: msg });
}

const isDeleteAction = newLevel === 'del';
let level = isDeleteAction ? 'all' : newLevel;

const pluginsDir = path.join(process.cwd(), 'plugins');
if (!fs.existsSync(pluginsDir)) {
return sock.sendMessage(chatId, { text: '❌ تعذر تحديد موقع مجلد الأوامر (plugins).' }, { quoted: msg });
}

let allJsFiles = [];
function scanAllPlugins(dir) {
if (!fs.existsSync(dir)) return;
const items = fs.readdirSync(dir);
for (const item of items) {
const fullPath = path.join(dir, item);
if (fs.lstatSync(fullPath).isDirectory()) {
scanAllPlugins(fullPath);
} else if (item.endsWith('.js')) {
allJsFiles.push({ path: fullPath, name: item });
}
}
}
scanAllPlugins(pluginsDir);

// 🧠 جلب الأوامر
let allPlugins = {};
try { allPlugins = require('../handlers/plugins').getPlugins() || {}; } catch (e) {}

const isCategory = Object.values(allPlugins).some(p => p?.category?.toLowerCase().trim() === target);

let targetFiles = [];
let matchedType = '';

// ================= [ فحص الفئات ] =================
if (isCategory || target === 'control') {
matchedType = `فئة كاملة [ ${target.toUpperCase()} ]`;
for (const file of allJsFiles) {
try {
const content = fs.readFileSync(file.path, 'utf-8');
const catRegex = /category\s*:\s*['"`]([^'"`]+)['"`]/i;
const match = content.match(catRegex);
if (match && match[1].toLowerCase().trim() === target) {
targetFiles.push(file);
}
} catch (e) {}
}
}
// ================= [ فحص الأوامر ] =================
else {
matchedType = `أمر مفرد [ .${target} ]`;
for (const file of allJsFiles) {
try {
const content = fs.readFileSync(file.path, 'utf-8');
const cmdRegex = new RegExp(`command\\s*:\\s*['"\`]${target}['"\`]`, 'i');
const arrayRegex = new RegExp(`command\\s*:\\s*\\[[^\\]]*['"\`]${target}['"\`][^\\]]*\\]`, 'i');

if (file.name.replace('.js', '').toLowerCase() === target || cmdRegex.test(content) || arrayRegex.test(content)) {
targetFiles.push(file);
break;
}
} catch (e) {}
}
}

if (targetFiles.length === 0) {
return sock.sendMessage(chatId, { text: `❌ لم يتم العثور على أي ملفات برمجية تطابق الفئة أو الأمر \`.${target}\`` }, { quoted: msg });
}

// ================= [ تجهيز الحماية ] =================
let protectionCode = '';
if (!isDeleteAction && level !== 'all') {
protectionCode = `// [ARCEN-SECURITY-START]
const senderNum = (msg.key.participant || msg.key.remoteJid).split('@')[0];
const { isDev } = require('../utils/devs');
const _fs = require('fs');
const _path = require('path');
const eliteFilePath = _path.join(process.cwd(), 'data', 'elite.json');
let eliteNumbers = [];
if (_fs.existsSync(eliteFilePath)) {
try { eliteNumbers = JSON.parse(_fs.readFileSync(eliteFilePath, 'utf-8')).eliteNumbers || []; } catch(e){}
}
`;
if (level === 'dev') {
protectionCode += `if (!isDev(senderNum)) return sock.sendMessage(msg.key.remoteJid, { text: '⚠️ ┋ عذراً، هذا الأمر مخصص للمطور الأساسي فقط!' }, { quoted: msg });\n        `;
} else if (level === 'both') {
protectionCode += `if (!isDev(senderNum) && !eliteNumbers.includes(senderNum)) return sock.sendMessage(msg.key.remoteJid, { text: '⚠️ ┋ هذا الأمر مخصص للمطورين والنخبة فقط!' }, { quoted: msg });\n        `;
} else if (level === 'admin') {
protectionCode += `const groupMetadata = msg.key.remoteJid.endsWith('@g.us') ? await sock.groupMetadata(msg.key.remoteJid) : null;
const isAdmin = groupMetadata ? groupMetadata.participants.find(p => p.id.split('@')[0] === senderNum)?.admin : false;
if (!isDev(senderNum) && !eliteNumbers.includes(senderNum) && !isAdmin) return sock.sendMessage(msg.key.remoteJid, { text: '🛡️ ┋ هذا الأمر يتطلب صلاحيات المشرفين أو المطور أو النخبة!' }, { quoted: msg });\n        `;
}
protectionCode += `// [ARCEN-SECURITY-END]\n        `;
}

// ================= [ حقن أو تنظيف ] =================
let successCount = 0;
for (const file of targetFiles) {
try {
let fileContent = fs.readFileSync(file.path, 'utf-8');

// تنظيف الحماية القديمة
const cleanRegex = /\/\/\s\[ARCEN-SECURITY-START\][\s\S]*?\/\/\s\[ARCEN-SECURITY-END\]\n?/g;
fileContent = fileContent.replace(cleanRegex, '');

// تنظيف الأكواد القديمة
const oldEliteRegex = /if\s*\(\s*!eliteNumbers\.includes[\s\S]*?\}\s*\}\n?/gi;
const oldDevRegex = /if\s*\(\s*!isDev[\s\S]*?\}\s*\}\n?/gi;
fileContent = fileContent.replace(oldEliteRegex, '').replace(oldDevRegex, '');

// حقن الحماية الجديدة
if (!isDeleteAction && level !== 'all') {
const executeRegex = /(async\s+execute\s*\([\s\S]*?\)\s*\{)/i;
if (executeRegex.test(fileContent)) {
fileContent = fileContent.replace(executeRegex, `$1\n        ${protectionCode}`);
}
}

fs.writeFileSync(file.path, fileContent, 'utf-8');
successCount++;
} catch (err) {
console.error(`خطأ أثناء معالجة الملف ${file.name}:`, err);
}
}

// ================= [ نتيجة ] =================
let levelText = '';
if (isDeleteAction) {
levelText = 'تم حذف جدار الحماية والعودة للوضع الافتراضي 🗑️❌';
} else {
const levelNames = { all: 'الكل 👥', admin: 'المشرفين 🛡️', both: 'النخبة والمطور 🜲', dev: 'المطور فقط ⚙️' };
levelText = levelNames[level] || level;
}

const successMsg = `
┏━🜲 نظام الصلاحيات المطور 🜲━┓
╭───❒ 『 SYSTEM UPDATED 』
> ⚙️ تم تعديل كود النظام بنجاح وتحديث جدار الحماية! 
───────────────────────
- \`المستهدف:\` ${matchedType}
- \`الحالة الجديدة:\` ${levelText}
- \`الملفات المحدثة:\` ${successCount} ملف
───────────────────────
📁 الملفات المعدلة:
${targetFiles.map(f => `▫️ \`${f.name}\``).join('\n')}
───────────────────────
> 💡 تم إجراء التعديل حياً، يرجى كتابة .تحديث لتفعيل الخيارات. ⦿
╰──────────────
┗━🜲 𝗔𝗥𝗖𝗘𝗡 🜲━┛`;

await sock.sendMessage(chatId, { text: successMsg }, { quoted: msg });
}
};