const config = require('../config');
const fs = require('fs');
const path = require('path');

module.exports = {
  command: "اختبارصورة",
  description: "اختبار إرسال صورة فقط",
  async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
            const chatId = msg.key.remoteJid;
    const imagePath = path.join(__dirname, '../resources/hrp.jpeg');

    if (!fs.existsSync(imagePath)) {
      return await sock.sendMessage(chatId, {
        text: '❌ الصورة hrp.jpeg غير موجودة في مجلد resources.'
      }, { quoted: msg });
    }

    await sock.sendMessage(chatId, {
      image: fs.readFileSync(imagePath),
      caption: "📸 *اختبار صورة: شغالة تمام؟*"
    }, { quoted: msg });
  }
};