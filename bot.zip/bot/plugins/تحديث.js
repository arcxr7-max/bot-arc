const fs = require('fs');
const path = require('path');
const { isDev } = require('../utils/devs');

module.exports = {
category: 'control',
command: 'تحديث',
description: '🔄 إعادة تحميل الأوامام بدون إعادة تشغيل البوت',
usage: '.تحديث',

async execute(sock, msg) {

const chatId = msg.key.remoteJid;
const sender = msg.key.participant || msg.key.remoteJid;
const senderNumber = sender.split('@')[0];

// 🛡️ رسالة الحماية المعدلة بناءً على طلبك دون أي تغيير آخر
if (!isDev(senderNumber)) {
return sock.sendMessage(chatId, {
text: '⚠️ ┋ عذراً، هذا الأمر مخصص للمطور الأساسي فقط!'
}, { quoted: msg });
}

await sock.sendMessage(chatId, { react: { text: '🔄', key: msg.key } });

try {
// تنظيف cache الأوامر
const pluginsDir = path.join(__dirname, '../plugins');
const files = fs.readdirSync(pluginsDir);

let count = 0;
for (const file of files) {
if (file.endsWith('.js')) {
const filePath = path.join(pluginsDir, file);
delete require.cache[require.resolve(filePath)];
count++;
}
}

// إعادة تحميل الـ handler
const handlerPath = path.join(__dirname, '../handlers/handler.js');
delete require.cache[require.resolve(handlerPath)];

// تحديث المتغير العام
if (global.loadPlugins) {
await global.loadPlugins(true);
}

await sock.sendMessage(chatId, {
text: `✅ تم تحديث ${count} أمر بنجاح`
}, { quoted: msg });

} catch (error) {
console.error(error);
await sock.sendMessage(chatId, {
text: `❌ خطأ: ${error.message}`
}, { quoted: msg });
}
}
};