module.exports = {
  status: "on",
  name: 'Smart Translate Text Clean',
  command: 'ترجم',
  description: 'يترجم ذكياً ويرسل نص الترجمة الصافي فقط بدون إضافات أو مكاتب',
  usage: '.ترجم hello / .ترجم أهلاً',
  category: 'tools',
  hidden: false,

  async execute(sock, msg) {
    try {
      const chatId = msg.key.remoteJid;
      const body = msg.message?.extendedTextMessage?.text || msg.message?.conversation || '';
      const args = body.trim().split(/\s+/).slice(1);
      
      // جلب النص سواء كان مكتوباً بعد الأمر أو مقتبساً (Reply)
      let textToTranslate = args.join(' ');
      const quotedMessage = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      
      if (quotedMessage) {
        textToTranslate = quotedMessage.conversation || quotedMessage.extendedTextMessage?.text || textToTranslate;
      }

      if (!textToTranslate) {
        return sock.sendMessage(chatId, { 
          text: "❌ يرجى كتابة النص المراد ترجمته بعد الأمر أو عمل رد (منشن) على الرسالة." 
        }, { quoted: msg });
      }

      // تحديد لغة الهدف ذكياً: إذا كان النص يحتوي على أحرف إنجليزية يتم الترجمة للعربية (ar)، وغير ذلك يترجم للإنجليزية (en)
      const isEnglish = /[a-zA-Z]/.test(textToTranslate);
      const targetLang = isEnglish ? 'ar' : 'en';

      // رابط الـ API المجاني للترجمة الفورية
      const apiUrl = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${targetLang}&dt=t&q=${encodeURIComponent(textToTranslate)}`;
      
      const response = await fetch(apiUrl);
      if (!response.ok) throw new Error('فشل الاتصال بسيرفر الترجمة');
      
      const data = await response.json();
      
      // تجميع النص المترجم
      let translatedText = '';
      if (data && data[0]) {
        data[0].forEach(item => {
          if (item[0]) translatedText += item[0];
        });
      }

      if (!translatedText) {
        throw new Error('لم يتم العثور على ترجمة للنص');
      }

      // إرسال نص الترجمة الصافي مباشرة بدون أي إضافات
      await sock.sendMessage(chatId, { text: translatedText }, { quoted: msg });

    } catch (error) {
      console.error('❌ خطأ في أمر الترجمة النظيف:', error);
    }
  }
};