const config = require('../config');
module.exports = {
  command: "تصنيف",
  description: "📊 يصنفك تصنيفات عشوائية",
  usage: ".تصنيف",

  async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
            const traits = [
      ["🐍 خبيث", Math.floor(Math.random() * 101)],
      ["🔥 مثير للجدل", Math.floor(Math.random() * 101)],
      ["👑 قائد بالفطرة", Math.floor(Math.random() * 101)],
      ["🧠 عبقري", Math.floor(Math.random() * 101)],
      ["💀 لا يُرحم", Math.floor(Math.random() * 101)]
    ];

    const results = traits.map(([trait, value]) => `${trait} – ${value}%`).join("\n");

    await sock.sendMessage(msg.key.remoteJid, {
      text: `📊 *تصنيف ${msg.pushName || "عضو"}:*\n\n${results}`
    }, { quoted: msg });
  }
};