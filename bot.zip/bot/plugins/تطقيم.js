// • Feature : جلب صور تطقيم انمي وكابلز عشوائية 
// • Developers : ARCEN Team

module.exports = {
    category: 'fun',
  command: ['تطقيم'], // يعمل فقط عبر أمر .تطقيم بناءً على طلبك
  description: 'جلب صور تطقيم انمي متناسقة (Matching Couples) بشكل عشوائي.',
  
  async execute(sock, message, args) {
    const from = message.key.remoteJid;

    try {
      // إرسال تفاعل الانتظار لبدء معالجة الصور
      await sock.sendMessage(from, { react: { text: '⏳', key: message.key } });

      // جلب بيانات التطقيم من المستودع الخاص بالـ Database
      const response = await fetch('https://raw.githubusercontent.com/KazukoGans/database/main/anime/ppcouple.json');
      if (!response.ok) throw new Error(`فشل جلب البيانات من المصدر: ${response.status}`);
      
      const data = await response.json();
      
      // اختيار طقم عشوائي من المصفوفة
      const randomPair = data[Math.floor(Math.random() * data.length)];
      
      // جلب بافر صورة الولد والبنت
      const resCowo = await fetch(randomPair.cowo);
      const bufferCowo = Buffer.from(await resCowo.arrayBuffer());

      const resCiwi = await fetch(randomPair.cewe);
      const bufferCiwi = Buffer.from(await resCiwi.arrayBuffer());

      // إرسال الصورة الأولى (الولد ♂️)
      await sock.sendMessage(from, {
        image: bufferCowo,
        caption: '*الـولد ♂️*'
      }, { quoted: message });

      // إرسال الصورة الثانية (البنت ♀️)
      await sock.sendMessage(from, {
        image: bufferCiwi,
        caption: '*الـبنت ♀️*'
      }, { quoted: message });

      // إرسال تفاعل النجاح
      await sock.sendMessage(from, { react: { text: '✅', key: message.key } });

    } catch (e) {
      console.error(e);
      await sock.sendMessage(from, { react: { text: '❌', key: message.key } });
      await sock.sendMessage(from, { text: '❌ حدث خطأ أثناء جلب صور التطقيم، يرجى المحاولة لاحقاً.' }, { quoted: message });
    }
  }
};