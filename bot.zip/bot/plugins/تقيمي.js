const fs = require('fs');
const path = require('path');

const file = path.join(__dirname, '../data/bot-ratings.json');
const devJid = '212612969896@s.whatsapp.net';'270527776174265@s.whatsapp.net'

if (!fs.existsSync(file)) fs.writeFileSync(file, '[]');

module.exports = {
  command: "تقيمك",
  description: "🌟 قيّم البوت بإدخال رقم من 1 إلى 5",
  usage: ".تقيمك [1 - 5]",

  async execute(sock, msg) {

            const from = msg.key.remoteJid;
    const sender = msg.participant || msg.key.participant || msg.key.remoteJid;
    const name = msg.pushName || "عضو";
    const args = msg.args.join(" ").trim();

    const stars = parseInt(args);

    if (isNaN(stars) || stars < 1 || stars > 5) {
      return await sock.sendMessage(from, {
        text: "❗ أرسل رقم لتقييم البوت من 1 إلى 5، مثال:\n`.تقيمك 3`"
      }, { quoted: msg });
    }

    const starDisplay = "⭐".repeat(stars);

    // حفظ التقييم في الملف
    const list = JSON.parse(fs.readFileSync(file));
    list.push({
      name,
      rating: stars,
      from: sender,
      date: new Date().toLocaleString("ar-EG")
    });
    fs.writeFileSync(file, JSON.stringify(list, null, 2));

    // استخراج اسم الجروب لو الرسالة من جروب
    let groupName = '';
    if (from.endsWith('@g.us')) {
      try {
        const metadata = await sock.groupMetadata(from);
        groupName = metadata.subject || 'جروب غير معروف';
      } catch {
        groupName = 'جروب غير معروف';
      }
    }

    // رسالة للمستخدم
    await sock.sendMessage(from, {
      text: `✨ *تم تسجيل تقييمك:*\n${starDisplay}\n\nشكراً لتقييمك لـ 𝗔𝗥𝗖𝗘𝗡 🜲`
    }, { quoted: msg });

    // رسالة للمطور
    await sock.sendMessage(devJid, {
      text: `🌟 *تقييم جديد من • ${name}*\n\n` +
            `📬 من: wa.me/${sender.split('@')[0]}\n` +
            (groupName ? `👥 الجروب: ${groupName}\n` : '') +
            `⭐ عدد النجوم: ${stars}`
    });
  }
};