// plugins/تنزيل.js
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const { pipeline } = require('stream');
const { promisify } = require('util');
const streamPipeline = promisify(pipeline);

module.exports = {
  command: ['تنزيل'],
  description: 'تنزيل صور من Pinterest حسب كلمة البحث.',
  usage: 'تنزيل <كلمة البحث>',
  category: 'tools',

  async execute(sock, msg) {
    const fullText =
      msg.message?.conversation ||
      msg.message?.extendedTextMessage?.text ||
      '';

    const inputText = fullText.replace(/^([،.\/!#])?تنزيل\s*/i, '').trim();

    if (!inputText) {
      return await sock.sendMessage(msg.key.remoteJid, {
        text: '❌ اكتب كلمة أبحث عنها بعد "تنزيل"',
      }, { quoted: msg });
    }

    const searchQuery = inputText;
    const numberOfImages = 10;

    const extras = ['aesthetic', '2024', 'hd', 'portrait', 'fanart', 'inspo', 'wallpaper'];
    const randomWord = extras[Math.floor(Math.random() * extras.length)];

    const searchUrl = `https://www.bing.com/images/search?q=${encodeURIComponent(`${searchQuery} ${randomWord} site:pinterest.com`)}&tsc=ImageBasicHover&form=IRFLTR&random=${Date.now()}`;

    try {
      await sock.sendMessage(msg.key.remoteJid, {
        text: `📥 جاري تنزيل 10 صور لـ *${searchQuery}* ...`,
      }, { quoted: msg });

      const { data } = await axios.get(searchUrl, {
        headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' }
      });

      const imageUrls = [];
      const murlRegex = /m="({[\s\S]*?})"/g;
      let match;

      while ((match = murlRegex.exec(data)) !== null) {
        try {
          const rawJson = match[1].replace(/&quot;/g, '"');
          const json = JSON.parse(rawJson);
          if (json.murl) imageUrls.push(json.murl);
        } catch {}
      }

      if (imageUrls.length === 0) {
        return await sock.sendMessage(msg.key.remoteJid, {
          text: '❌ لم يتم العثور على صور.',
        }, { quoted: msg });
      }

      const imagesToSend = imageUrls.slice(0, numberOfImages);

      for (const [index, imgUrl] of imagesToSend.entries()) {
        try {
          const filePath = path.join(__dirname, `dl-${Date.now()}-${index}.jpg`);
          const response = await axios({
            url: imgUrl,
            method: 'GET',
            responseType: 'stream'
          });

          await streamPipeline(response.data, fs.createWriteStream(filePath));

          const buffer = fs.readFileSync(filePath);
          await sock.sendMessage(msg.key.remoteJid, {
            image: buffer,
            caption: `📸 صورة ${index + 1} من "${searchQuery}"`,
          }, { quoted: msg });

          if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
        } catch (err) {
          console.error(`❌ خطأ في صورة ${index + 1}:`, err.message);
        }
      }

    } catch (err) {
      console.error('❌ خطأ أثناء البحث:', err);
      await sock.sendMessage(msg.key.remoteJid, {
        text: '❌ حدث خطأ أثناء التنزيل.',
      }, { quoted: msg });
    }
  }
};
