const fs = require('fs');
const path = require('path');
const disabledCmdsFile = path.join(process.cwd(), 'disabled_formats.json');

// دالة مساعدة لحفظ وقراءة البيانات
function getDisabledCmds() {
    if (fs.existsSync(disabledCmdsFile)) {
        try { return JSON.parse(fs.readFileSync(disabledCmdsFile, 'utf8')); } catch (e) { return []; }
    }
    return [];
}
function saveDisabledCmds(data) {
    fs.writeFileSync(disabledCmdsFile, JSON.stringify(data, null, 2), 'utf8');
}

module.exports = {
    status: "on",
    name: 'تنسيق الرسائل',
    command: ['تنسيق'],
    category: 'control',
    description: 'التحكم في التنسيق التلقائي للأوامر (بـ / بدون)',
    hidden: false,
    version: '2.0',

    async execute(sock, msg) {
        const targetChat = msg.key.remoteJid;
        const body = msg.message?.extendedTextMessage?.text || msg.message?.conversation || '';
        const args = body.trim().split(/\s+/).slice(1);

        if (args.length < 2) {
            return await sock.sendMessage(targetChat, { 
                text: "❌ *طريقة الاستخدام الصحيحة:*\n• `.تنسيق بدون [اسم_الأمر]` لإيقاف التنسيق\n• `.تنسيق ب [اسم_الأمر]` لتفعيل التنسيق" 
            }, { quoted: msg });
        }

        const action = args[0]; 
        const commandName = args[1].replace(/^\./, '').toLowerCase().trim(); 

        let disabledCmds = getDisabledCmds();

        if (action === 'بدون') {
            if (!disabledCmds.includes(commandName)) {
                disabledCmds.push(commandName);
                saveDisabledCmds(disabledCmds);
            }
            return await sock.sendMessage(targetChat, { 
                text: `✅ تم إلغاء التنسيق التلقائي تماماً للأمر: \`.${commandName}\` (محفوظ دائماً)` 
            }, { quoted: msg });
        } 
        
        if (action === 'ب') {
            disabledCmds = disabledCmds.filter(cmd => cmd !== commandName);
            saveDisabledCmds(disabledCmds);
            return await sock.sendMessage(targetChat, { 
                text: `✅ تم إعادة التنسيق التلقائي الافتراضي للأمر: \`.${commandName}\`` 
            }, { quoted: msg });
        }

        return await sock.sendMessage(targetChat, { text: "❌ خيار غير صحيح، استخدم (ب) أو (بدون)." }, { quoted: msg });
    }
};