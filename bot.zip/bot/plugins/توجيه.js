const config = require('../config');
const { isElite } = require('../haykala/elite.js');
const { isDev } = require('../utils/devs');

module.exports = {
  command: 'توجيه',
  description: '📣 توجيه رسالة إلى كل الجروبات (للمطورين والنخبة)',
  category: 'admin',

  async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
            const chatId = msg.key.remoteJid;
    const senderJid = msg.key.participant || msg.key.remoteJid;
    const senderNumber = senderJid.split('@')[0];

    // ✅ التحقق من الصلاحيات (مطور أو نخبة)
    if (!isDev(senderNumber) && !isElite(senderNumber)) {
      return sock.sendMessage(chatId, {
        text: '🚫 هذا الأمر مخصص للمطورين والنخبة فقط.'
      }, { quoted: msg });
    }

    // ✅ التحقق من وجود رد
    const quotedMsg = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;

    if (!quotedMsg) {
      return sock.sendMessage(chatId, {
        text: '❌ يجب الرد على رسالة نصية لتوجيهها.'
      }, { quoted: msg });
    }

    // ✅ استخراج النص من الرسالة المقتبسة
    const text = quotedMsg?.conversation || quotedMsg?.extendedTextMessage?.text;

    if (!text) {
      return sock.sendMessage(chatId, {
        text: '⚠️ الرسالة التي تم الرد عليها لا تحتوي على نص.'
      }, { quoted: msg });
    }

    // ✅ جلب جميع المجموعات
    const groupsMetadata = await sock.groupFetchAllParticipating();
    const groupJids = Object.keys(groupsMetadata).filter(gid => gid.endsWith('@g.us'));

    if (groupJids.length === 0) {
      return sock.sendMessage(chatId, {
        text: '❌ البوت ليس في أي جروب.'
      }, { quoted: msg });
    }

    await sock.sendMessage(chatId, {
      text: `🔄 جاري توجيه الرسالة إلى ${groupJids.length} جروب مع منشن للكل...`
    }, { quoted: msg });

    let successCount = 0;
    let failCount = 0;

    for (const group of groupJids) {
      try {
        const metadata = groupsMetadata[group];
        const mentions = metadata.participants.map(p => p.id);

        await sock.sendMessage(group, {
          text: `📢 *رسالة موجهة من النخبة:*\n\n${text}`,
          mentions: mentions
        });

        successCount++;
        await new Promise(resolve => setTimeout(resolve, 1000)); // تأخير ثانية بين كل جروب
      } catch (err) {
        console.log(`⚠️ فشل التوجيه إلى ${group}: ${err.message}`);
        failCount++;
      }
    }

    await sock.sendMessage(chatId, {
      text: `✅ تم توجيه الرسالة.\n📨 نجح: ${successCount} جروب\n❌ فشل: ${failCount} جروب`
    }, { quoted: msg });
  }
};