const axios = require('axios');
const path = require('path');
const os = require('os');
const fs = require('fs');
const { pipeline } = require('stream/promises');

const POLLINATIONS_KEY = 'pk_EsNR60VG0fSAwk9A';

// تعريف الـ theme الجديد بأشكال هندسية أنيقة وفخمة
const theme = {
  divider: '╭───────────────────╮',
  endDivider: '╰───────────────────╯'
};

module.exports = {
    command: ['توليد'],
    category: 'media',
    description: '🎨 توليد أحدث الصور بالذكاء الاصطناعي',

    async execute(sock, msg) {
        try {
            const from = msg.key.remoteJid;
            const body = msg.message?.extendedTextMessage?.text || msg.message?.conversation || '';
            
            // استخراج الوصف بعد الأمر
            const args = body.trim().split(/\s+/).slice(1);
            const text = args.join(' ').trim();

            // دالة التفاعل التلقائي
            const react = async (emoji) => {
                try { 
                    await sock.sendMessage(from, { react: { text: emoji, key: msg.key } });
                } catch (e) {
                    console.error(e);
                }
            };

            // إذا لم يكتب المستخدم وصفاً للصورة
            if (!text) {
                await react('❌');
                const helpText = [
                    `> ${theme.divider}`,
                    `✨🔮 *توليد الصور بالذكاء الاصطناعي* 🔮✨`,
                    ``,
                    `💎 *الاستخدام:* .توليد [وصف الصورة]`,
                    ``,
                    `📝 *أمثلة مميزة:*`,
                    `├ قطة لطيفة في حديقة`,
                    `├ غروب الشمس على البحر`,
                    `└ مدينة مستقبلية متطورة`,
                    ``,
                    `${global.botName || '𝗔𝗥𝗖𝗘𝗡'}`,
                    `${theme.endDivider}`
                ].join('\n');
                
                return await sock.sendMessage(from, { text: helpText }, { quoted: msg });
            }

            // بدء التوليد والتفاعل
            await react('⏳');
            await sock.sendMessage(from, { 
                text: `> ${theme.divider}\n✨🎨 *جاري تصميم وتوليد صورتك...* 🎨✨\n💎 🔍 يرجى الانتظار ثواني معدودة...\n${theme.endDivider}` 
            }, { quoted: msg });

            // ━━━ ترجمة الوصف إلى الإنجليزية تلقائياً ━━━
            let englishText = text;
            try {
                const trRes = await axios.get(
                    `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=en&dt=t&q=${encodeURIComponent(text)}`,
                    { timeout: 8000 }
                );
                const translated = trRes.data?.[0]?.map(x => x?.[0]).filter(Boolean).join('') || text;
                if (translated) englishText = translated;
            } catch { 
                englishText = text; 
            }

            const encoded  = encodeURIComponent(englishText + ', high quality, detailed, 4k');
            const seed     = Math.floor(Math.random() * 999999);
            const imageUrl = `https://gen.pollinations.ai/image/${encoded}?model=flux&width=1024&height=1024&seed=${seed}&nologo=true`;

            const filePath = path.join(os.tmpdir(), `bot_img_${Date.now()}.jpg`);
            
            // تحميل الصورة كـ Stream
            const imgRes = await axios({
                method: 'GET',
                url: imageUrl,
                responseType: 'stream',
                timeout: 120000,
                headers: {
                    Authorization: `Bearer ${POLLINATIONS_KEY}`,
                    'User-Agent': 'Mozilla/5.0'
                }
            });
            
            await pipeline(imgRes.data, fs.createWriteStream(filePath));

            // التحقق من حجم الملف
            const size = fs.statSync(filePath).size;
            if (size < 5000) {
                try { fs.unlinkSync(filePath); } catch {}
                throw new Error('تعذر إنشاء الصورة، يرجى المحاولة بوصف آخر.');
            }

            // إرسال الصورة النهائية بالتعليق المنسق والراقي الجديد
            const captionText = [
                `> ${theme.divider}`,
                `✨🖼️ *تم تصميم الصورة بنجاح!* 🖼️✨`,
                ``,
                `💎 *الوصف الحصري:* ${text}`,
                ``,
                `${global.botName || '𝗔𝗥𝗖𝗘𝗡'}`,
                `${theme.endDivider}`
            ].join('\n');

            await sock.sendMessage(from, {
                image: fs.readFileSync(filePath),
                caption: captionText
            }, { quoted: msg });

            await react('🎨');
            
            // حذف الصورة المؤقتة فوراً للحفاظ على الذاكرة
            try { fs.unlinkSync(filePath); } catch {}

        } catch (err) {
            console.error('draw error:', err.message);
            try { 
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
                await sock.sendMessage(msg.key.remoteJid, { 
                    text: `> ${theme.divider}\n⚠️ *فشل التوليد* ⚠️\n🔍 ${err.message}\n${theme.endDivider}` 
                }, { quoted: msg });
            } catch (e) {
                console.error(e);
            }
        }
    }
};