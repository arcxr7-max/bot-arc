const fs = require('fs').promises;
const existsSync = require('fs').existsSync;
const path = require('path');

module.exports = {
    command: 'جلسة',
    description: 'إصلاح وحذف ملفات التشفير والجلسات التالفة جذرياً مع إعادة تنشيط الذاكرة',
    usage: '.جلسة',

    async execute(sock, msg) {
        try {
            // 1. التحديد الآلي لمجلد الجلسة
            const possibleFolders = ['session', 'ملف_الاتصال', 'auth_info_baileys', 'sessions'];
            let sessionFolder = possibleFolders.find(folder => existsSync(path.join(process.cwd(), folder)));

            if (!sessionFolder) {
                return await sock.sendMessage(msg.key.remoteJid, {
                    text: '⚠️ لم يتم العثور على مجلد الجلسة في المسارات المتوقعة!'
                }, { quoted: msg });
            }

            const targetDir = path.join(process.cwd(), sessionFolder);
            const files = await fs.readdir(targetDir);
            
            let deletedCount = 0;

            // 2. معالجة الملفات وحذف المفاتيح والتأكد من حماية ملف التوثيق
            for (const file of files) {
                if (file === 'creds.json') {
                    continue;
                }

                const isCorruptedFile = 
                    file.startsWith('pre-key-') || 
                    file.startsWith('app-state-sync-') || 
                    file.startsWith('session-') || 
                    file.startsWith('sender-key-');

                if (isCorruptedFile) {
                    try {
                        await fs.unlink(path.join(targetDir, file));
                        deletedCount++;
                    } catch (err) {
                        // تجاهل الملفات المفتوحة
                    }
                }
            }

            if (deletedCount === 0) {
                return await sock.sendMessage(msg.key.remoteJid, {
                    text: '✅ الجلسة سليمة ونظيفة، لا توجد مفاتيح تشفير تالفة بحاجة للإصلاح!'
                }, { quoted: msg });
            }

            const responseText = 
                `⚙️ اكتملت عملية صيانة الجلسة بنجاح\n\n` +
                `🗑️ الملفات التالفة المحذوفة: ${deletedCount} ملف\n` +
                `🛡️ ملف التوثيق الرئيسي: آمن ومحفوظ (creds.json)\n\n` +
                `💡 يتم الآن إعادة تنشيط الاتصال لتفريغ الذاكرة القديمة وتطبيق التعديلات...`;

            // 3. إرسال رسالة التأكيد
            await sock.sendMessage(msg.key.remoteJid, {
                text: responseText
            }, { quoted: msg });

            // 4. إغلاق الاتصال مؤقتاً لتفريغ ذاكرة الـ RAM وإعادة الربط التلقائي
            setTimeout(() => {
                sock.ev.emit('connection.update', { connection: 'close' });
            }, 2000);

        } catch (error) {
            console.error('❌ خطأ أثناء تنظيف الجلسة:', error);
            await sock.sendMessage(msg.key.remoteJid, {
                text: '❌ حدث خطأ غير متوقع أثناء معالجة الجلسة.'
            }, { quoted: msg });
        }
    }
};
