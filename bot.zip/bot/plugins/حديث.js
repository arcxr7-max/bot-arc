// plugins/حديث.js
const axios = require('axios');

// رابط الأحاديث من GitHub (ضع رابط ملف JSON الخاص بك هنا)
const HADITH_URL = 'https://raw.githubusercontent.com/arcxr7-max/ARC/refs/heads/main/hadith.json';

module.exports = {
    category: 'islamic',
    command: [ 'حديث'],
    description: '📖 عرض حديث نبوي شريف عشوائي',
    usage: '.حديث',
    
    async execute(sock, msg) {
        const chatId = msg.key.remoteJid;

        // تفاعل فوري
        await sock.sendMessage(chatId, { react: { text: '📜', key: msg.key } });

        try {
            // جلب الأحاديث من الرابط
            const response = await axios.get(HADITH_URL, { timeout: 10000 });
            const hadithList = response.data;

            if (!Array.isArray(hadithList) || hadithList.length === 0) {
                throw new Error('قائمة الأحاديث فارغة');
            }

            // اختيار حديث عشوائي
            const random = hadithList[Math.floor(Math.random() * hadithList.length)];
            
            // تنسيق الرسالة حسب البنية الجديدة
            const message = `*🕌 حديث اليوم:*\n\n📜 *الراوي:* ${random.rawi}\n\n💬 *الحديث:*\n${random.hadith}\n\n📚 *المصدر:* ${random.source}\n\n━━━━━━━━━━━━━━━━━━\n✨ *صدق رسول الله ﷺ* ✨`;
            
            // إرسال الحديث
            await sock.sendMessage(chatId, { text: message }, { quoted: msg });
            
            // تفاعل نجاح
            await sock.sendMessage(chatId, { react: { text: '📜', key: msg.key } });

        } catch (error) {
            console.error('خطأ في جلب الأحاديث:', error);
            await sock.sendMessage(chatId, { 
                text: '❌ *حدث خطأ أثناء جلب الأحاديث*\n📌 تأكد من صحة الرابط أو حاول لاحقًا.'
            }, { quoted: msg });
            
            await sock.sendMessage(chatId, { react: { text: '❌', key: msg.key } });
        }
    }
};