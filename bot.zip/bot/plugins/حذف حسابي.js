const config = require('../config');
const fs = require('fs');
const path = require('path');

const accountsFile = path.join(__dirname, '../data/bankAccounts.json');
const pointsFile = path.join(__dirname, '../data/points.json');

function loadAccounts() {
    if (!fs.existsSync(accountsFile)) return {};
    return JSON.parse(fs.readFileSync(accountsFile, 'utf8'));
}

function loadPoints() {
    if (!fs.existsSync(pointsFile)) return {};
    return JSON.parse(fs.readFileSync(pointsFile, 'utf8'));
}

function saveAccounts(data) {
    fs.writeFileSync(accountsFile, JSON.stringify(data, null, 2));
}

module.exports = {
    command: 'حزف',
    description: '🗑️ حذف الحساب البنكي',
    category: 'bank',

    async execute(sock, msg) {
        const chatId = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;
        const senderNumber = sender.split('@')[0];

        try {
            const accounts = loadAccounts();
            const account = accounts[senderNumber];
            
            if (!account) {
                return sock.sendMessage(chatId, {
                    text: '❌ ماعندك حساب\n\n📌 استخدم .انشاء لإنشاء حساب'
                }, { quoted: msg });
            }

            // جلب النقاط والرتبة
            const points = loadPoints();
            const balance = points[senderNumber] || 0;

            // تخزين المعلومات قبل الحذف
            const accountInfo = {
                accountNumber: account.accountNumber,
                bankEmoji: account.bankEmoji || '🏦',
                bankName: account.bankName || 'بنك غير معروف',
                balance: balance.toLocaleString(),
                createdAt: account.createdAt ? account.createdAt.split('T')[0] : 'N/A'
            };

            // حذف الحساب
            delete accounts[senderNumber];
            saveAccounts(accounts);
            
            // حذف النقاط
            if (fs.existsSync(pointsFile)) {
                let pointsData = JSON.parse(fs.readFileSync(pointsFile, 'utf8'));
                delete pointsData[senderNumber];
                fs.writeFileSync(pointsFile, JSON.stringify(pointsData, null, 2));
            }

            // إرسال رسالة واحدة تحتوي معلومات الحساب + تأكيد الحذف
            await sock.sendMessage(chatId, {
                text: `🗑️ *تم حذف حسابك البنكي*

📋 *معلومات الحساب المحذوف:*
━━━━━━━━━━━━━━━━━
🔢 رقم الحساب: *${accountInfo.accountNumber}*
🏦 البنك: ${accountInfo.bankEmoji} ${accountInfo.bankName}
💰 الرصيد: ${accountInfo.balance} نقطة
📅 تاريخ الإنشاء: ${accountInfo.createdAt}
━━━━━━━━━━━━━━━━━
✅ تم حذف الحساب بنجاح

📌 استخدم .انشاء لإنشاء حساب جديد`
            }, { quoted: msg });

        } catch(e) {
            console.log('❌ خطأ في حزف:', e);
            await sock.sendMessage(chatId, { 
                text: '❌ حدث خطأ أثناء حذف الحساب' 
            }, { quoted: msg });
        }
    }
};