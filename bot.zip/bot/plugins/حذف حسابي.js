const config = require('../config');
const fs = require('fs');
const path = require('path');

const accountsFile = path.join(__dirname, '../data/bankAccounts.json');
const pointsFile = path.join(__dirname, '../data/points.json');

module.exports = {
    command: 'حزف',  // ✅ أمر قصير جداً
    description: 'حذف الحساب البنكي',
    category: 'bank',

    async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
                const chatId = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;
        const senderNumber = sender.split('@')[0];

        try {
            // قراءة الحسابات
            if (!fs.existsSync(accountsFile)) {
                return sock.sendMessage(chatId, { text: '❌ لا يوجد حسابات' }, { quoted: msg });
            }
            
            let accounts = JSON.parse(fs.readFileSync(accountsFile, 'utf8'));
            
            if (!accounts[senderNumber]) {
                return sock.sendMessage(chatId, { text: '❌ ماعندك حساب' }, { quoted: msg });
            }
            
            // حذف
            delete accounts[senderNumber];
            fs.writeFileSync(accountsFile, JSON.stringify(accounts, null, 2));
            
            // حذف النقاط
            if (fs.existsSync(pointsFile)) {
                let points = JSON.parse(fs.readFileSync(pointsFile, 'utf8'));
                delete points[senderNumber];
                fs.writeFileSync(pointsFile, JSON.stringify(points, null, 2));
            }
            
            await sock.sendMessage(chatId, { text: '✅ تم الحذف' }, { quoted: msg });
            
        } catch(e) {
            console.log(e);
            await sock.sendMessage(chatId, { text: '❌ خطأ' }, { quoted: msg });
        }
    }
};