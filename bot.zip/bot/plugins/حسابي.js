const config = require('../config');
const fs = require('fs');
const path = require('path');

const accountsFile = path.join(__dirname, '../data/bankAccounts.json');
const pointsFile = path.join(__dirname, '../data/points.json');

function loadAccounts() {
    if (!fs.existsSync(accountsFile)) return {};
    return JSON.parse(fs.readFileSync(accountsFile, 'utf8'));
}

function loadPoints() {
    if (!fs.existsSync(pointsFile)) return {};
    return JSON.parse(fs.readFileSync(pointsFile, 'utf8'));
}

// الرتب الجديدة
const ranks = [
    { min: 0, name: 'متدرب النينجا', emoji: '🥚' },
    { min: 1000, name: 'جينين', emoji: '🍃' },
    { min: 5000, name: 'جينين محترف', emoji: '🌿' },
    { min: 10000, name: 'تشونين', emoji: '⚔️' },
    { min: 25000, name: 'تشونين النخبة', emoji: '🗡️' },
    { min: 50000, name: 'جونين', emoji: '🔥' },
    { min: 75000, name: 'جونين الظل', emoji: '🌑' },
    { min: 100000, name: 'أنبو', emoji: '🎭' },
    { min: 150000, name: 'قائد الأنبو', emoji: '🖤' },
    { min: 200000, name: 'شيبوكاي', emoji: '🌊' },
    { min: 300000, name: 'قرصان مبتدئ', emoji: '☠️' },
    { min: 400000, name: 'صياد الأرواح', emoji: '👻' },
    { min: 500000, name: 'حامل اللعنة', emoji: '💀' },
    { min: 650000, name: 'مقاتل السايان', emoji: '🐉' },
    { min: 800000, name: 'محارب البرق', emoji: '⚡' },
    { min: 1000000, name: 'قائد الفرقة', emoji: '🛡️' },
    { min: 1250000, name: 'قائد القراصنة', emoji: '🏴' },
    { min: 1500000, name: 'ملك السيوف', emoji: '⚔️' },
    { min: 1800000, name: 'السيف الأسود', emoji: '🖤' },
    { min: 2200000, name: 'حارس البوابة', emoji: '🚪' },
    { min: 2600000, name: 'وحش القتال', emoji: '🔥' },
    { min: 3000000, name: 'سيد الجليد', emoji: '❄️' },
    { min: 3500000, name: 'تنين النار', emoji: '🐲' },
    { min: 4000000, name: 'عين الشيطان', emoji: '👁️' },
    { min: 5000000, name: 'فارس الظلام', emoji: '🌑' },
    { min: 6500000, name: 'سيد اللعنات', emoji: '💀' },
    { min: 8000000, name: 'ملك اللهب', emoji: '🔥' },
    { min: 10000000, name: 'الهوكاجي', emoji: '🌀' },
    { min: 12000000, name: 'قائد الأكاتسوكي', emoji: '🌌' },
    { min: 15000000, name: 'الإمبراطور القرمزي', emoji: '🔺' },
    { min: 18000000, name: 'السيد الملعون', emoji: '☠️' },
    { min: 22000000, name: 'تنين السماء', emoji: '🐉' },
    { min: 26000000, name: 'حارس الجحيم', emoji: '🔥' },
    { min: 30000000, name: 'سيد الأرواح', emoji: '👻' },
    { min: 35000000, name: 'محطم الأكوان', emoji: '💥' },
    { min: 40000000, name: 'الملك المظلم', emoji: '🌑' },
    { min: 50000000, name: 'عين الفراغ', emoji: '🕳️' },
    { min: 65000000, name: 'حاكم البرق', emoji: '⚡' },
    { min: 80000000, name: 'إمبراطور السايان', emoji: '🐲' },
    { min: 100000000, name: 'سيد العواصف', emoji: '🌪️' },
    { min: 120000000, name: 'ملك الوحوش', emoji: '🦁' },
    { min: 150000000, name: 'حاكم الجليد', emoji: '❄️' },
    { min: 180000000, name: 'نينجا الكارثة', emoji: '💢' },
    { min: 220000000, name: 'ملك الشياطين', emoji: '👹' },
    { min: 260000000, name: 'قاطع الأبعاد', emoji: '🗡️' },
    { min: 300000000, name: 'روح الانتقام', emoji: '👁️' },
    { min: 350000000, name: 'الوحش الأبدي', emoji: '🐺' },
    { min: 400000000, name: 'النينجا الأسطوري', emoji: '✨' },
    { min: 500000000, name: 'حاكم الظلال', emoji: '🖤' },
    { min: 650000000, name: 'فارس الجحيم', emoji: '🔥' },
    { min: 800000000, name: 'ملك الفراغ', emoji: '🌌' },
    { min: 1000000000, name: 'عين النهاية', emoji: '👁️' },
    { min: 1500000000, name: 'سيف الدمار', emoji: '⚔️' },
    { min: 2000000000, name: 'سيد التنانين', emoji: '🐉' },
    { min: 5000000000, name: 'روح الحرب', emoji: '🛡️' },
    { min: 7000000000, name: 'حاكم الأرواح', emoji: '👻' },
    { min: 10000000000, name: 'إمبراطور الظلام', emoji: '🌑' },
    { min: 15000000000, name: 'ملك الأكوان', emoji: '🌠' },
    { min: 20000000000, name: 'السيد الأبدي', emoji: '♾️' },
    { min: 30000000000, name: 'الوحش المدمر', emoji: '💥' },
    { min: 50000000000, name: 'حاكم العاصفة', emoji: '🌪️' },
    { min: 70000000000, name: 'روح الجحيم', emoji: '🔥' },
    { min: 100000000000, name: 'ملك الرعد', emoji: '⚡' },
    { min: 150000000000, name: 'قائد التنانين', emoji: '🐲' },
    { min: 200000000000, name: 'ملك الظلال', emoji: '🌑' },
    { min: 300000000000, name: 'ملك الزمن', emoji: '⌛' },
    { min: 500000000000, name: 'سيد الأبعاد', emoji: '🌀' },
    { min: 700000000000, name: 'الحاكم المطلق', emoji: '👑' },
    { min: 1000000000000, name: 'أسطورة الأبعاد', emoji: '☄️' }
];

// الحصول على الرتبة الحالية
function getRank(points) {
    let currentRank = ranks[0];
    for (const rank of ranks) {
        if (points >= rank.min) {
            currentRank = rank;
        } else {
            break;
        }
    }
    return currentRank;
}

// الحصول على الرتبة التالية والمتبقي
function getNextRankInfo(points) {
    for (let i = 0; i < ranks.length - 1; i++) {
        if (points < ranks[i + 1].min) {
            return { 
                nextRank: ranks[i + 1].name, 
                needed: ranks[i + 1].min - points 
            };
        }
    }
    return { nextRank: null, needed: null };
}

module.exports = {
    command: 'حسابي',
    description: '🏦 عرض معلومات حسابك البنكي والرتبة',
    usage: '.حسابي',
    category: 'bank',

    async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
                const chatId = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;
        const senderNumber = sender.split('@')[0];

        const accounts = loadAccounts();
        const account = accounts[senderNumber];
        
        if (!account) {
            return sock.sendMessage(chatId, {
                text: '❌ ليس لديك حساب بنكي!\nاستخدم .انشاء لإنشاء حساب'
            }, { quoted: msg });
        }

        const points = loadPoints();
        const balance = points[senderNumber] || 0;
        const rank = getRank(balance);
        const nextRankInfo = getNextRankInfo(balance);
        
        let rankText = `\n🏆 *الرتبة:* ${rank.emoji} ${rank.name}`;
        
        if (nextRankInfo.nextRank && rank.name !== '🌌 حاكم الضلال') {
            rankText += `\n📈 *تحتاج:* ${nextRankInfo.needed.toLocaleString()} نقطة للوصول إلى ${nextRankInfo.nextRank}`;
        } else if (rank.name === '🌌 حاكم الضلال') {
            rankText += `\n👑 *أنت في قمة الرتب!*`;
        }

        await sock.sendMessage(chatId, {
            text: `🏦 *معلومات حسابك البنكي*\n\n🔢 رقم الحساب: *${account.accountNumber}*\n🏦 البنك: ${account.bankEmoji} ${account.bankName}\n💰 الرصيد: ${balance.toLocaleString()} نقطة${rankText}\n📅 تاريخ الإنشاء: ${account.createdAt.split('T')[0]}`
        }, { quoted: msg });
    }
};