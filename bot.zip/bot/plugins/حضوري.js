const axios = require('axios');
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');

/* 🧠 نظام منع التكرار الذكي */
const sentVideos = new Map();
const MAX_HISTORY = 100;

function rememberVideo(id) {
  sentVideos.set(id, Date.now());
  if (sentVideos.size > MAX_HISTORY) {
    const oldestKey = [...sentVideos.entries()]
      .sort((a, b) => a[1] - b[1])[0][0];
    sentVideos.delete(oldestKey);
  }
}

// ✨ قائمة المواضيع الفخمة (بدون الحاجة لكتابة موضوع)
const epicTopics = [
  "sung jin woo",
  "edit anime phonk",
  "edit sung jin woo",
  "edit Cristiano Ronaldo"
];

module.exports = {
  command: 'حضوري',
  category: 'media',
  description: '🎬 يرسل فيديو حضور فخم (تلقائي)',
  usage: '.حضوري',

  async execute(sock, msg) {

            const chatId = msg.key.remoteJid;
    
    // اختيار موضوع عشوائي من القائمة الفخمة
    const randomTopic = epicTopics[Math.floor(Math.random() * epicTopics.length)];
    const searchText = `${randomTopic} edit`;  // البحث في TikTok/YouTube

    await sock.sendMessage(chatId, { react: { text: '🥱', key: msg.key } });

    /* 🔴 المحاولة الأولى: TikWM API (المصدر القوي) */
    try {
      const apiUrl = `https://www.tikwm.com/api/feed/search?keywords=${encodeURIComponent(searchText)}`;
      const { data } = await axios.get(apiUrl);

      if (data.code === 0 && data.data?.videos?.length) {
        const fresh = data.data.videos.filter(v => {
          const id = v.video_id || v.id || v.play;
          return id && !sentVideos.has(id);
        });

        if (fresh.length) {
          const selected = fresh[Math.floor(Math.random() * fresh.length)];
          const vid = selected.video_id || selected.id || selected.play;
          rememberVideo(vid);

          // كابشن فخم للحضور
          const caption = `🔥 *حضور فخم. يخليك تندم*\n\n✨ ${randomTopic}\n🎬 جهز نفسك...`;

          return await sock.sendMessage(chatId, {
            video: { url: selected.play },
            caption: caption
          }, { quoted: msg });
        }
      }
    } catch (err) {
      console.warn('⚠️ فشل TikWM — الانتقال إلى YouTube');
    }

    /* 🟡 المحاولة الثانية: YouTube باستخدام yt-dlp */
    try {
      const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'edit-'));
      const outPath = path.join(tmpDir, 'video.%(ext)s');
      const command = `yt-dlp "ytsearch1:${searchText}" -f mp4 -o "${outPath}" --quiet --no-warnings`;
      execSync(command);

      const files = fs.readdirSync(tmpDir).filter(f => f.endsWith('.mp4'));
      if (!files.length) throw new Error('لا يوجد فيديو');

      const videoPath = path.join(tmpDir, files[0]);
      const caption = `🔥 *حضور فخم (YouTube)*\n\n✨ ${randomTopic}`;

      await sock.sendMessage(chatId, {
        video: fs.readFileSync(videoPath),
        caption: caption
      }, { quoted: msg });

      fs.rmSync(tmpDir, { recursive: true, force: true });

    } catch (err) {
      console.error('❌ فشل كامل:', err.message);
      await sock.sendMessage(chatId, {
        text: '❌ تعذر جلب فيديو حضور. تأكد من اتصال الإنترنت وتثبيت yt-dlp.',
        quoted: msg
      });
    }
  }
};