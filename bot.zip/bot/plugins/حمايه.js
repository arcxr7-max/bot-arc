const config = require('../config');
const fs = require('fs');
const path = require('path');
const { jidDecode } = require('@whiskeysockets/baileys');
const { isDev } = require('../utils/devs');
const { isElite } = require('../haykala/elite');

const dataDir = path.join(__dirname, '..', 'data');
const monitorFile = path.join(dataDir, 'monitorState.json');
const cooldowns = {};

if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
if (!fs.existsSync(monitorFile)) fs.writeFileSync(monitorFile, JSON.stringify({}));

const loadMonitorState = () => {
    try { return JSON.parse(fs.readFileSync(monitorFile)); }
    catch { return {}; }
};

const saveMonitorState = (data) => {
    try { fs.writeFileSync(monitorFile, JSON.stringify(data, null, 2)); }
    catch (err) { console.error("❌ خطأ حفظ حالة المراقبة:", err); }
};

let handlerAttached = false;

module.exports = {
    command: 'ط',
    description: '🔒 تفعيل أو إيقاف الحماية المطلقة.',
    category: 'admin',

    async execute(sock, m) {
        const groupId = m.key.remoteJid;
        const sender = m.key.participant || m.participant;

        if (!groupId.endsWith('@g.us')) {
            return sock.sendMessage(groupId, { text: '❌ هذا الأمر يعمل فقط في المجموعات.' }, { quoted: m });
        }

        const senderNumber = (sender || '').split('@')[0];
        
        // التحقق من المطور أو النخبة
        if (!isDev(senderNumber) && !isElite(senderNumber)) {
            return sock.sendMessage(groupId, { text: '⚠️ فقط النخبة والمطور يمكنهم التحكم بالحماية.' }, { quoted: m });
        }

        const state = loadMonitorState();

        if (state[groupId]) {
            delete state[groupId];
            saveMonitorState(state);
            return sock.sendMessage(groupId, { text: '🔓 تم إيقاف الحماية المطلقة.' }, { quoted: m });
        }

        state[groupId] = true;
        saveMonitorState(state);
        await sock.sendMessage(groupId, { text: '🚨 *تم تفعيل الحماية المطلقة.*' }, { quoted: m });

        if (handlerAttached) return;
        handlerAttached = true;

        sock.ev.on('group-participants.update', async (update) => {
            const currentState = loadMonitorState();
            const groupId = update.id;

            if (!currentState[groupId]) return;
            if (cooldowns[groupId]) return;

            cooldowns[groupId] = true;
            setTimeout(() => delete cooldowns[groupId], 3000);

            try {
                const metadata = await sock.groupMetadata(groupId);
                const botId = jidDecode(sock.user.id).user + '@s.whatsapp.net';
                const participants = metadata.participants;
                const actor = update.actor || null;

                // جلب أرقام المطورين من ملف devs.json
                const devsFile = path.join(__dirname, '../data/devs.json');
                let devNumbers = [];
                if (fs.existsSync(devsFile)) {
                    devNumbers = JSON.parse(fs.readFileSync(devsFile, 'utf8'));
                }

                const allowedJids = [
                    botId,
                    ...devNumbers.map(num => num.includes('@') ? num : `${num}@s.whatsapp.net`)
                ];

                // المشرفين الغير مسموح لهم
                const toDemote = participants.filter(p => 
                    p.admin && !allowedJids.includes(p.id) && p.id !== metadata.owner
                ).map(p => p.id);

                // الترقية للمسموح لهم فقط
                const toPromote = allowedJids.filter(jid => {
                    const p = participants.find(p => p.id === jid);
                    return p && !p.admin;
                });

                if (toDemote.length > 0 || toPromote.length > 0) {
                    const mentions = [...toDemote];
                    if (actor) mentions.push(actor);

                    if (toDemote.length > 0) {
                        await sock.groupParticipantsUpdate(groupId, toDemote, 'demote').catch(console.error);
                    }
                    if (toPromote.length > 0) {
                        await sock.groupParticipantsUpdate(groupId, toPromote, 'promote').catch(console.error);
                    }

                    const demoteList = toDemote.map(j => `• @${j.split('@')[0]} ِ`).join('\n');
                    
                    const text = `🚨 *الحماية المطلقة مفعّلة!* 🚨\n\n` +
                        `👤 *تم منح إشراف بواسطة:* @ ${actor ? actor.split('@')[0] : 'غير معروف'} ِ\n\n` +
                        `❌ *تم سحب الإشراف من:*\n${demoteList || '• لا أحد'}\n\n` +
                        `🔁 *تم إرجاع الحالة الأصلية.*`;

                    await sock.sendMessage(groupId, { text, mentions });
                }

            } catch (err) {
                console.error("خطأ أثناء الحماية:", err);
            }
        });
    }
};