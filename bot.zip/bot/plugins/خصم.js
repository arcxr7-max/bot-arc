const config = require('../config');
const fs = require('fs');
const path = require('path');
const { isDev } = require('../utils/devs');

const pointsFile = path.join(__dirname, '../data/points.json');

function loadPoints() {
  if (!fs.existsSync(pointsFile)) fs.writeFileSync(pointsFile, '{}');
  return JSON.parse(fs.readFileSync(pointsFile));
}

function savePoints(points) {
  fs.writeFileSync(pointsFile, JSON.stringify(points, null, 2));
}

module.exports = {
  command: 'خصم',
  description: '➖ خصم نقاط من نفسك أو من شخص آخر (للمطور فقط)',
  usage: '.خصم [المبلغ] @العضو',
  category: 'info',

  async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
            const chatId = msg.key.remoteJid;
    const senderJid = msg.key.participant || msg.key.remoteJid;
    const senderNumber = senderJid.split('@')[0];

    // ✅ التحقق من المطور (من ملف devs.json)
    if (!isDev(senderNumber)) {
      return sock.sendMessage(chatId, {
        text: '🚫 هذا الأمر مخصص للمطور فقط!'
      }, { quoted: msg });
    }

    // قراءة النص مباشرة
    let fullText = '';
    if (msg.message?.conversation) fullText = msg.message.conversation;
    else if (msg.message?.extendedTextMessage?.text) fullText = msg.message.extendedTextMessage.text;
    else fullText = '';

    // استخراج المبلغ والمنشن
    const parts = fullText.split(/\s+/);
    let amount = null;
    let mention = null;

    for (let i = 0; i < parts.length; i++) {
      const part = parts[i];
      if (/^\d+$/.test(part)) {
        amount = parseInt(part);
      } else if (part.includes('@')) {
        mention = part.replace('@', '');
      }
    }

    // إذا لم يحدد المبلغ
    if (!amount || amount <= 0) {
      return sock.sendMessage(chatId, {
        text: '❌ استخدم: .خصم [المبلغ] @العضو\nمثال: .خصم 500 @المستخدم'
      }, { quoted: msg });
    }

    // تحديد المستهدف (إذا كان فيه منشن أو المرسل نفسه)
    const targetNumber = mention ? mention.split('@')[0] : senderNumber;
    const targetJid = targetNumber + '@s.whatsapp.net';

    const points = loadPoints();
    const current = points[targetNumber] || 0;

    if (current < amount) {
      return sock.sendMessage(chatId, {
        text: `❌ رصيد @${targetNumber}: ${current} نقطة فقط.\nلا يمكن خصم ${amount} نقطة.`,
        mentions: [targetJid]
      }, { quoted: msg });
    }

    // تنفيذ الخصم
    points[targetNumber] = current - amount;
    savePoints(points);

    // رسالة النجاح
    const isSelf = (targetNumber === senderNumber);
    const resultText = isSelf
      ? `✅ تم خصم ${amount} نقطة من رصيدك\n💰 رصيدك الآن: ${points[targetNumber]} نقطة`
      : `✅ تم خصم ${amount} نقطة من @${targetNumber}\n💰 رصيده الآن: ${points[targetNumber]} نقطة`;

    await sock.sendMessage(chatId, {
      text: resultText,
      mentions: isSelf ? [] : [targetJid]
    }, { quoted: msg });
  }
};