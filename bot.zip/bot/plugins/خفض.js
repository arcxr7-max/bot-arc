const config = require('../config');
const { isElite } = require('../haykala/elite');

module.exports = {
    command: 'خفض',
    category: 'admin',
    description: 'إزالة المشرف من المجموعة بالمنشن أو الرد (حصري للنخبة).',

    async execute(sock, msg, args = []) {
        // [ARCEN-SECURITY-START]
        const senderNum = (msg.key.participant || msg.key.remoteJid).split('@')[0];
        const { isDev } = require('../utils/devs');
        const _fs = require('fs');
        const _path = require('path');
        const eliteFilePath = _path.join(process.cwd(), 'data', 'elite.json');
        let eliteNumbers = [];
        if (_fs.existsSync(eliteFilePath)) {
            try { eliteNumbers = JSON.parse(_fs.readFileSync(eliteFilePath, 'utf-8')).eliteNumbers || []; } catch(e){}
        }
        
        const chatId = msg.key.remoteJid;
        if (!chatId.endsWith('@g.us')) {
            return sock.sendMessage(chatId, { text: '❌ هذا الأمر يعمل فقط في المجموعات.' }, { quoted: msg });
        }

        const groupMetadata = await sock.groupMetadata(chatId);
        const checkAdmin = groupMetadata ? groupMetadata.participants.find(p => p.id.split('@')[0] === senderNum)?.admin : false;
        
        if (!isDev(senderNum) && !eliteNumbers.includes(senderNum) && !checkAdmin) {
            return sock.sendMessage(chatId, { text: '🛡️ ┋ هذا الأمر يتطلب صلاحيات المشرفين أو المطور أو النخبة!' }, { quoted: msg });
        }
        // [ARCEN-SECURITY-END]

        const sender = msg.key.participant || msg.key.remoteJid;
        let target = null;

        // 🛠️ جلب المستهدف الذكي (يدعم المنشن أو الرد معاً)
        const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid;
        const contextParticipant = msg.message?.extendedTextMessage?.contextInfo?.participant;

        if (mentioned?.length) {
            target = mentioned[0]; // إذا وجد منشن يأخذه أولاً
        } else if (contextParticipant) {
            target = contextParticipant; // إذا وجد رد على رسالة يأخذه
        } else if (args[0] && /^[0-9]+$/.test(args[0].replace(/[^0-9]/g, ''))) {
            target = args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net'; // إذا كُتب رقم هاتف
        }

        // 🔒 الحماية: إذا استهدف نفسه أو كتب الأمر وحده يتم الرفض فوراً حمايةً للرتبة
        if (!target || target === sender) {
            return sock.sendMessage(chatId, {
                text: '⚠️ يا زعيم، يجب عليك الرد على رسالة المشرف أو عمل منشن له لخفضه! حماية النظام تمنع خفض نفسك.'
            }, { quoted: msg });
        }

        const isMember = groupMetadata.participants.some(p => p.id === target);
        if (!isMember) {
            return sock.sendMessage(chatId, { text: '❌ العضو غير موجود في المجموعة.' }, { quoted: msg });
        }

        // التحقق من صلاحيات المشرف لتفادي محاولة خفض عضو عادي
        const targetParticipant = groupMetadata.participants.find(p => p.id === target);
        const isTargetAdmin = targetParticipant?.admin === 'admin' || targetParticipant?.admin === 'superadmin';

        if (!isTargetAdmin) {
            return sock.sendMessage(chatId, { text: '❌ العضو ليس مشرفًا بالفعل!' }, { quoted: msg });
        }

        try {
            await sock.groupParticipantsUpdate(chatId, [target], 'demote');

            const senderName = (await sock.onWhatsApp(sender))?.[0]?.notify || `@${sender.split('@')[0]}`;
            const targetName = (await sock.onWhatsApp(target))?.[0]?.notify || `@${target.split('@')[0]}`;

            // 🛑 قالب الخفض الملكي المرتب والقوي
            const responseMessage = `
📉┃ تـجـريـد مـن صـلاحـيـات الإشـراف
━━━━━━━━━━━━━━━━━━━━━━

‹ 👤 › الـعـضـو الـمُـسـتـهـدف : ${targetName}ِ
‹ 🚫 › الـحـالـة الـحـالـيـة : عـضـو عـادي 🛑
‹ ⚙️ › الـفـاعـل الـمـسـؤول : ${senderName}ِ

━━━━━━━━━━━━━━━━━━━━━━
⚠️┃ تـمّ سـحـب رُتـبـة الإشـراف وإعـادتـه لـصـفـوف الأعـضـاء.
━━━━━━━━━━━━━━━━━━━━━━
✨┃ 𝗕𝗢𝗧 : ${config.botName || '𝗔𝗥𝗖𝗘𝗡'}`.trim();

            return sock.sendMessage(chatId, {
                text: responseMessage,
                mentions: [target, sender]
            }, { quoted: msg });

        } catch (error) {
            return sock.sendMessage(chatId, { text: `❌ فشل الخفض: ${error.message}` }, { quoted: msg });
        }
    }
};