const fs = require('fs-extra');
const path = require('path');

const pointsFile = path.join(__dirname, '../data/points.json');

module.exports = {
    command: 'خمن',
    description: '🎮 لعبة تخمين الرقم من 1 لـ 100',
    category: 'game',

    async execute(sock, msg) {

                const from = msg.key.remoteJid;
        const senderJid = msg.key.participant || from;
        const senderNumber = senderJid.split('@')[0];

        if (!global.gameNumber) global.gameNumber = {};

        // إذا كان العضو يلعب فعلاً
        if (global.gameNumber[senderJid]) {
            return sock.sendMessage(from, { text: '❌ أنت في جولة بالفعل! اكتب الرقم مباشرة.' }, { quoted: msg });
        }

        // اختيار رقم عشوائي بين 1 و 100
        const targetNumber = Math.floor(Math.random() * 100) + 1;

        // إعداد المؤقت (إذا لم يحلها في دقيقة يخسر)
        const timeout = setTimeout(async () => {
            if (global.gameNumber[senderJid]) {
                const target = global.gameNumber[senderJid].target;
                
                // خصم نقاط عند الفشل (500 نقطة)
                let points = fs.existsSync(pointsFile) ? fs.readJsonSync(pointsFile) : {};
                points[senderNumber] = Math.max(0, (points[senderNumber] || 0) - 500);
                fs.writeJsonSync(pointsFile, points, { spaces: 2 });

                await sock.sendMessage(from, { 
                    text: `⌛ *انتهى الوقت!* الخسارة قاسية...\n\n❁ الرقم كان: *${target}*\n❁ العقاب: *-500 نقاط* 📉\n❁ رصيدك الآن: *${points[senderNumber]}*` 
                });
                delete global.gameNumber[senderJid];
            }
        }, 60000); // دقيقة واحدة للحل

        global.gameNumber[senderJid] = {
            target: targetNumber,
            timeout: timeout
        };

        const startText = `
╭──〔 🎮 *لـعـبـة خـمـن* 〕──╮
┃
┃ 🤫 اخترت رقم في مخي من *1* لـ *100*
┃ 💡 حاول تعرفه.. أنا بقولك أكبر أو أصغر
┃
┃ 💰 الربح: *+500* | الخسارة: *-500*
┃ ⏱️ الوقت: دقيقة واحدة
┃
╰───〔 *𝗔𝗥𝗖𝗘𝗡* 〕───╯`.trim();

        await sock.sendMessage(from, { text: startText }, { quoted: msg });
    }
};