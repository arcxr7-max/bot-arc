// plugins/دعاء.js
const axios = require('axios');

// رابط الأدعية من GitHub (ضع الرابط الصحيح هنا)
const DUAA_URL = 'https://raw.githubusercontent.com/arcxr7-max/ARC/refs/heads/main/ad3eya.json';

module.exports = {
    category: 'islamic',
    command: ['دعاء'],
    description: '🤲 عرض دعاء عشوائي',
    usage: '.دعاء',
    
    async execute(sock, msg) {
        const chatId = msg.key.remoteJid;

        // تفاعل فوري
        await sock.sendMessage(chatId, { react: { text: '🤲', key: msg.key } });

        try {
            // جلب الأدعية من الرابط
            const response = await axios.get(DUAA_URL, { timeout: 10000 });
            const ad3eyaList = response.data;

            // التحقق من صحة البيانات
            if (!Array.isArray(ad3eyaList) || ad3eyaList.length === 0) {
                throw new Error('قائمة الأدعية فارغة أو غير صالحة');
            }

            // اختيار دعاء عشوائي
            const randomDuaa = ad3eyaList[Math.floor(Math.random() * ad3eyaList.length)];
            
            // تنسيق الرسالة (بنفس تنسيق .حديث)
            const message = `*🤲 دعاء اليوم:*\n\n${randomDuaa}\n\n━━━━━━━━━━━━━━━━━━\n✨ *اللهم آمين* ✨`;
            
            // إرسال الدعاء
            await sock.sendMessage(chatId, { text: message }, { quoted: msg });
            
            // تفاعل نجاح
            await sock.sendMessage(chatId, { react: { text: '🤲', key: msg.key } });

        } catch (error) {
            console.error('خطأ في جلب الأدعية:', error);
            await sock.sendMessage(chatId, { 
                text: '❌ *حدث خطأ أثناء جلب الأدعية*\n📌 تأكد من صحة الرابط أو حاول لاحقًا.'
            }, { quoted: msg });
            
            // تفاعل خطأ
            await sock.sendMessage(chatId, { react: { text: '❌', key: msg.key } });
        }
    }
};