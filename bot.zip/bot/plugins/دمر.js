const { exec } = require('child_process');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { isDev } = require('../utils/devs');

module.exports = {
  command: 'دمر',
  category: 'zarf',
  description: '☢️ إزالة الإشراف + إرسال صوت انفجارات ودمار',
  usage: '.دمر',

  async execute(sock, msg) {

            const chatId = msg.key.remoteJid;
    const sender = msg.participant || msg.key.participant || msg.key.remoteJid;
    const senderNum = sender.split("@")[0];

    // 1. التحقق من الصلاحية (للمطورين فقط من ملف devs.json)
    if (!isDev(senderNum)) {
      return await sock.sendMessage(chatId, { text: "❌ هذا الأمر مخصص للمطورين فقط." }, { quoted: msg });
    }

    // 2. التحقق من أنه داخل جروب
    if (!chatId.endsWith('@g.us')) {
      return await sock.sendMessage(chatId, { text: '❌ هذا الأمر يعمل فقط داخل المجموعات.' }, { quoted: msg });
    }

    try {
      const metadata = await sock.groupMetadata(chatId);
      const groupName = metadata?.subject || 'الجروب';
      const botNumber = sock?.user?.id?.split(":")[0] || '';
      
      // ✅ رابط الصورة
      const imageUrl = 'https://www.image2url.com/r2/default/images/1777453083334-f31a1ada-fd9a-49fa-85d0-d9b2e13101f1.jpg';

      // 3. تفاعل البدء
      await sock.sendMessage(chatId, { react: { text: '☢️', key: msg.key } });

      // 4. تنفيذ سحب الإشراف (تدمير الإدارة)
      const admins = metadata.participants.filter(p => p.admin);
      const devsList = ['212612969896', '270527776174265']; // المطورين الذين لا يتم سحب إدارتهم
      
      const targets = admins.filter(p => {
        const num = (p.id || p.jid).split("@")[0];
        return !devsList.includes(num) && num !== botNumber;
      });

      for (const target of targets) {
        await sock.groupParticipantsUpdate(chatId, [target.id], "demote");
      }

      // 5. إرسال صورة التحذير والرسالة
      await sock.sendMessage(chatId, {
        image: { url: imageUrl },
        caption: `☢️ *تحذير رسمي:*\nتم تنفيذ أمر *الدمار الإداري* بنجاح!\nتم إسقاط جميع المشرفين في *${groupName}* ما عدا القيادة العليا.\n\n*ارك دمر الإدارة... انتهى زمن السيطرة!* 🔥`,
      }, { quoted: msg });

      // 6. جلب وإرسال صوت الدمار
      const searchTerms = ['برونو مارس', 'كيندراد لامار', 'بيونسيه'];
      const query = searchTerms[Math.floor(Math.random() * searchTerms.length)];
      const audioPath = path.join(os.tmpdir(), `dest_${Date.now()}.mp3`);

      // محاولة من TikTok أولاً
      try {
        const apiUrl = `https://www.tikwm.com/api/feed/search?keywords=${encodeURIComponent(query)}`;
        const { data } = await axios.get(apiUrl);
        if (data.code === 0 && data.data?.videos?.length) {
          const audioUrl = data.data.videos[0].music || data.data.videos[0].music_info?.play;
          if (audioUrl) {
            return await sock.sendMessage(chatId, {
              audio: { url: audioUrl },
              mimetype: 'audio/mpeg',
              ptt: false,
            });
          }
        }
      } catch (e) { console.log('TikWM failed...'); }

      // استخدام yt-dlp إذا فشل TikTok
      const cmd = `yt-dlp "ytsearch1:${query}" -x --audio-format mp3 -o "${audioPath}" --quiet --no-warnings`;

      exec(cmd, async (error) => {
        if (error) return console.error('[ERROR] yt-dlp failed:', error.message);
        if (fs.existsSync(audioPath)) {
          await sock.sendMessage(chatId, {
            audio: fs.readFileSync(audioPath),
            mimetype: 'audio/mpeg',
            ptt: false,
            contextInfo: {
              externalAdReply: {
                title: '☢️ جـاري الـتـدمـيـر الآن...',
                body: 'arc bot system',
                mediaType: 1,
                renderLargerThumbnail: false
              }
            }
          });
          fs.unlinkSync(audioPath);
        }
      });

    } catch (err) {
      console.error("❌ خطأ في تنفيذ أمر دمر:", err);
      await sock.sendMessage(chatId, { text: "❌ حدث خطأ أثناء تنفيذ عملية الدمار." }, { quoted: msg });
    }
  }
};