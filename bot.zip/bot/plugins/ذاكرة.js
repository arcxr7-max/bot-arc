const config = require('../config');
const fs = require('fs');
const path = require('path');

const pointsFile = path.join(__dirname, '../data/points.json');

function getPoints() {
    if (!fs.existsSync(pointsFile)) return {};
    return JSON.parse(fs.readFileSync(pointsFile, 'utf8'));
}

function savePoints(points) {
    fs.writeFileSync(pointsFile, JSON.stringify(points, null, 2));
}

if (!global.memoryGames) global.memoryGames = {};

// دالة تأخير
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

module.exports = {
    command: 'ذاكرة',
    description: '🧠 تذكر الرقم المكون من 6 أرقام',
    usage: '.ذاكرة',
    category: 'game',

    async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
                const chatId = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;
        const senderNumber = sender.split('@')[0];

        if (global.memoryGames[senderNumber]) {
            return sock.sendMessage(chatId, { text: '⚠️ لديك لعبة نشطة! أجب على الرقم' }, { quoted: msg });
        }

        // توليد رقم عشوائي من 6 أرقام (100000 إلى 999999)
        const secretNumber = Math.floor(Math.random() * 900000) + 100000;
        
        global.memoryGames[senderNumber] = { secretNumber, chatId, time: Date.now() };

        // إرسال الرسالة الأولى
        const sentMsg = await sock.sendMessage(chatId, {
            text: `🧠 *لعبة الذاكرة*\n\nتذكر هذا الرقم:\n*${secretNumber}*\n\nسيتم إخفاؤه بعد 3 ثواني...`
        }, { quoted: msg });

        // انتظار 3 ثواني
        await sleep(3000);

        // تعديل الرسالة نفسها إلى السؤال
        if (global.memoryGames[senderNumber]) {
            try {
                await sock.sendMessage(chatId, {
                    text: `🤔 *ما هو الرقم الذي ظهر؟*\n💰 الجائزة: 100 نقطة\n⏰ لديك 15 ثانية`,
                    edit: sentMsg.key
                });
            } catch(e) {
                // إذا فشل التعديل، نرسل رسالة جديدة
                await sock.sendMessage(chatId, {
                    text: `🤔 *ما هو الرقم الذي ظهر؟*\n💰 الجائزة: 100 نقطة\n⏰ لديك 15 ثانية`
                });
            }
        }

        // مؤقت 15 ثانية للإجابة
        setTimeout(async () => {
            if (global.memoryGames[senderNumber]) {
                const game = global.memoryGames[senderNumber];
                delete global.memoryGames[senderNumber];
                try {
                    await sock.sendMessage(chatId, {
                        text: `⌛ *انتهى الوقت!*\nالرقم كان: ${game.secretNumber}`,
                        edit: sentMsg.key
                    });
                } catch(e) {
                    await sock.sendMessage(chatId, { text: `⌛ انتهى الوقت! الرقم كان: ${game.secretNumber}` });
                }
            }
        }, 15000);
    }
};