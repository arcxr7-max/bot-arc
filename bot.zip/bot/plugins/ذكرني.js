// plugins/ذكرني.js
module.exports = {
    command: ['ذكرني'],
    category: 'tools',
    description: '⏰ منبه ذكي لتذكيرك بالمهام داخل الشات',

    async execute(sock, msg) {
        try {
            const from = msg.key.remoteJid;
            const body = msg.message?.extendedTextMessage?.text || msg.message?.conversation || '';
            const args = body.trim().split(/\s+/).slice(1);

            const minutes = parseInt(args[0]);
            const reminderText = args.slice(1).join(' ').trim();

            if (isNaN(minutes) || !reminderText) {
                return await sock.sendMessage(from, { 
                    text: '❌ *طريقة الاستخدام الخاطئة!*\n\nاكتب الأمر كالتالي: `.ذكرني [عدد الدقائق] [الشيء المراد تذكيره]`\n\n💡 مثال:\n`.ذكرني 5 شرب الماء`' 
                }, { quoted: msg });
            }

            await sock.sendMessage(from, { text: `⏰ تم ضبط المنبه بنجاح! سأقوم بتذكيرك بعد *${minutes}* دقيقة من الآن.` }, { quoted: msg });

            // تشغيل التذكير في الخلفية بعد الوقت المحدد دون الحاجة لهاندلر
            setTimeout(async () => {
                const userJid = msg.key.participant || msg.key.remoteJid;
                const alertMessage = `🔔 *تنبيه المنبه الذكي!* 🔔\n\n👤 يا @${userJid.split('@')[0]} لقد طلبت مني تذكيرك بـ:\n📝 *${reminderText}*`;

                await sock.sendMessage(from, { 
                    text: alertMessage, 
                    mentions: [userJid] 
                });
            }, minutes * 60000); // تحويل الدقائق إلى مللي ثانية

        } catch (error) {
            console.error(error);
        }
    }
};