const config = require('../config');
const fs = require('fs');
const path = require('path');

const guildsFile = path.join(__dirname, '../data/guilds.json');

function loadGuilds() {
  if (!fs.existsSync(guildsFile)) return {};
  return JSON.parse(fs.readFileSync(guildsFile, 'utf8'));
}

function saveGuilds(data) {
  fs.writeFileSync(guildsFile, JSON.stringify(data, null, 2));
}

module.exports = {
  category: 'group',
  command: 'ربط',
  description: '🔗 ربط هذا القروب الأساسي بنقابة موجودة',
  usage: '.ربط [معرف النقابة]',

  async execute(sock, msg, args) {
        // [ARCEN-SECURITY-START]
const senderNum = (msg.key.participant || msg.key.remoteJid).split('@')[0];
const { isDev } = require('../utils/devs');
const _fs = require('fs');
const _path = require('path');
const eliteFilePath = _path.join(process.cwd(), 'data', 'elite.json');
let eliteNumbers = [];
if (_fs.existsSync(eliteFilePath)) {
try { eliteNumbers = JSON.parse(_fs.readFileSync(eliteFilePath, 'utf-8')).eliteNumbers || []; } catch(e){}
}
const groupMetadata = msg.key.remoteJid.endsWith('@g.us') ? await sock.groupMetadata(msg.key.remoteJid) : null;
const isAdmin = groupMetadata ? groupMetadata.participants.find(p => p.id.split('@')[0] === senderNum)?.admin : false;
if (!isDev(senderNum) && !eliteNumbers.includes(senderNum) && !isAdmin) return sock.sendMessage(msg.key.remoteJid, { text: '🛡️ ┋ هذا الأمر يتطلب صلاحيات المشرفين أو المطور أو النخبة!' }, { quoted: msg });
        // [ARCEN-SECURITY-END]
        
    const chatId = msg.key.remoteJid;
    const sender = msg.key.participant || msg.key.remoteJid;
    const senderNumber = sender.split('@')[0];

    // التأكد من أن الأمر في قروب
    if (!chatId.endsWith('@g.us')) {
      return sock.sendMessage(chatId, { text: '❌ استخدم هذا الأمر في القروب الأساسي' }, { quoted: msg });
    }

    // قراءة النص مباشرة
    let fullText = '';
    if (msg.message?.conversation) fullText = msg.message.conversation;
    else if (msg.message?.extendedTextMessage?.text) fullText = msg.message.extendedTextMessage.text;
    else fullText = '';

    const withoutCommand = fullText.replace(/^\.ربط\s/, '').trim();
    const guildId = withoutCommand;

    if (!guildId) {
      return sock.sendMessage(chatId, { text: '❌ استخدم: .ربط [معرف النقابة]\nمثال: .ربط guild_1778849629356' }, { quoted: msg });
    }

    let guilds = loadGuilds();
    console.log('📂 النقابات الموجودة:', Object.keys(guilds));

    const guild = guilds[guildId];

    if (!guild) {
      return sock.sendMessage(chatId, {
        text: `❌ معرف النقابة غير صحيح\n\nالمعرفات المتاحة:\n${Object.keys(guilds).join('\n') || 'لا توجد نقابات'}`
      }, { quoted: msg });
    }

    if (guild.mainGroupId) {
      return sock.sendMessage(chatId, { text: `❌ هذه النقابة مرتبطة بالفعل بقروب آخر` }, { quoted: msg });
    }

    const metadata = await sock.groupMetadata(chatId);
    guild.mainGroupId = chatId;
    guild.mainGroupName = metadata.subject;
    saveGuilds(guilds);

    await sock.sendMessage(chatId, {
      text: `✅ تم الربط بنجاح!\n\n🔗 القروب الأساسي: ${metadata.subject}\n🏛️ النقابة المرتبطة: ${guild.name}\n\n📌 الآن يمكن للأعضاء استخدام:\n\`.لقبي [اللقب]\` - لاختيار لقب\n\`.لقبي\` - لعرض لقبك\n\`.لقبي @منشن\` - لعرض لقب العضو`
    }, { quoted: msg });

    console.log('✅ تم ربط القروب:', chatId, 'مع النقابة:', guildId);
  }
};