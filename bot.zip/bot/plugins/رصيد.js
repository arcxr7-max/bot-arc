const config = require('../config');
const fs = require('fs');
const path = require('path');

const pointsFile = path.join(__dirname, '../data/points.json');

function loadPoints() {
    if (!fs.existsSync(pointsFile)) return {};
    return JSON.parse(fs.readFileSync(pointsFile, 'utf8'));
}

module.exports = {
    command: 'رصيده',
    description: '💰 عرض رصيد الشخص الذي ترد على رسالته',
    usage: '.رصيده (رد على رسالة الشخص)',
    category: 'bank',

    async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
                const chatId = msg.key.remoteJid;
        
        // التحقق من وجود رد
        const quotedMsg = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const targetJid = msg.message?.extendedTextMessage?.contextInfo?.participant;
        
        if (!targetJid || !quotedMsg) {
            return sock.sendMessage(chatId, {
                text: '❌ لازم ترد على رسالة الشخص'
            }, { quoted: msg });
        }
        
        const targetNumber = targetJid.split('@')[0];
        const points = loadPoints();
        const balance = points[targetNumber] || 0;
        
        await sock.sendMessage(chatId, {
            text: `رصيده هو ${balance}💸`
        }, { quoted: msg });
    }
};