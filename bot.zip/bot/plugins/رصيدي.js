const config = require('../config');
const fs = require('fs');
const path = require('path');

const pointsFile = path.join(__dirname, '../data/points.json');

function loadPoints() {
    if (!fs.existsSync(pointsFile)) return {};
    return JSON.parse(fs.readFileSync(pointsFile, 'utf8'));
}

module.exports = {
    command: 'رصيدي',
    description: '💰 عرض رصيدك الحالي',
    usage: '.رصيدي',
    category: 'bank',

    async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
                const chatId = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;
        const senderNumber = sender.split('@')[0];

        const points = loadPoints();
        const balance = points[senderNumber] || 0;

        await sock.sendMessage(chatId, {
            text: `💰 *رصيدك الحالي:* ${balance} نقطة`
        }, { quoted: msg });
    }
};