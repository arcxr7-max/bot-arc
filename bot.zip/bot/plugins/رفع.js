const config = require('../config');
const { isElite } = require('../haykala/elite');

module.exports = {
    category: 'group',
    command: 'رفع',
    description: '👑 ترقية عضو أو أكثر إلى مشرف بأسلوب ملكي (حصري للنخبة)',

    async execute(sock, msg, args = []) {
        // [ARCEN-SECURITY-START]
        const senderNum = (msg.key.participant || msg.key.remoteJid).split('@')[0];
        const { isDev } = require('../utils/devs');
        const _fs = require('fs');
        const _path = require('path');
        const eliteFilePath = _path.join(process.cwd(), 'data', 'elite.json');
        let eliteNumbers = [];
        if (_fs.existsSync(eliteFilePath)) {
            try { eliteNumbers = JSON.parse(_fs.readFileSync(eliteFilePath, 'utf-8')).eliteNumbers || []; } catch(e){}
        }
        
        const chatId = msg.key.remoteJid;
        if (!chatId.endsWith('@g.us')) {
            return sock.sendMessage(chatId, {
                text: '🚫 This command works in groups only!'
            }, { quoted: msg });
        }

        const groupMetadata = await sock.groupMetadata(chatId);
        const checkAdmin = groupMetadata ? groupMetadata.participants.find(p => p.id.split('@')[0] === senderNum)?.admin : false;
        
        if (!isDev(senderNum) && !eliteNumbers.includes(senderNum) && !checkAdmin) {
            return sock.sendMessage(chatId, { text: '🛡️ ┋ هذا الأمر يتطلب صلاحيات المشرفين أو المطور أو النخبة!' }, { quoted: msg });
        }
        // [ARCEN-SECURITY-END]

        const sender = msg.key.participant || msg.participant || msg.key.remoteJid;
        const groupParticipants = groupMetadata.participants;

        const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
        const contextParticipant = msg.message?.extendedTextMessage?.contextInfo?.participant;
        if (contextParticipant) {
            mentioned.push(contextParticipant);
        }

        const numbers = args
            .filter(arg => /^[0-9]+$/.test(arg))
            .map(num => num + '@s.whatsapp.net');

        const targets = [...new Set([...mentioned, ...numbers])];

        if (targets.length === 0 || (targets.length === 1 && targets[0] === sender)) {
            return sock.sendMessage(chatId, {
                text: '⚠️ يا زعيم، يجب عليك الرد على رسالة العضو أو عمل منشن له لرفعه!'
            }, { quoted: msg });
        }

        const senderName = (await sock.onWhatsApp(sender))?.[0]?.notify || `@${sender.split('@')[0]}`;

        for (const target of targets) {
            if (target === sender) continue;

            const participant = groupParticipants.find(p => p.id === target);

            if (!participant) {
                await sock.sendMessage(chatId, {
                    text: `❌ العضو غير موجود في المجموعة: ${target.replace(/@s\.whatsapp\.net$/, '')}`
                }, { quoted: msg });
                continue;
            }

            if (participant.admin === 'admin' || participant.admin === 'superadmin') {
                await sock.sendMessage(chatId, {
                    text: `ℹ️ @${target.split('@')[0]} هو مشرف بالفعل.`,
                    mentions: [target]
                }, { quoted: msg });
                continue;
            }

            try {
                await sock.groupParticipantsUpdate(chatId, [target], 'promote');

                const targetName = (await sock.onWhatsApp(target))?.[0]?.notify || `@${target.split('@')[0]}`;

                // 🌟 القالب الملكي الفخم الجديد للرفع
                const message = `
⚡┃ تـمّ تـعـيـين مـشـرف جـديـد مـلـكـي
━━━━━━━━━━━━━━━━━━━━━━

‹ 👑 › الـعـضـو الـمُـرقّـى : ${targetName}ِ
‹ ⚜️ › الـرُّتـبـة الـجـديـدة : إدارة الـمـجـمـوعـة 🛡️
‹ ⚡ › بـواسـطـة الـقـائـد : ${senderName}ِ

━━━━━━━━━━━━━━━━━━━━━━
🦅┃ مـرحـبـاً بـك فـي عـرش الـقـيـادة والـتـنـظـيـم!
💬┃ يـرجـى الـتـزام الـعـدل وتـطـبـيـق الـقـوانـيـن.
━━━━━━━━━━━━━━━━━━━━━━
✨┃ 𝗕𝗢𝗧 : ${config.botName || '𝗔𝗥𝗖𝗘𝗡'}`.trim();

                await sock.sendMessage(chatId, {
                    text: message,
                    mentions: [target, sender]
                }, { quoted: msg });

            } catch (error) {
                await sock.sendMessage(chatId, {
                    text: `❌ فشل الترقية: ${target.replace(/@s\.whatsapp\.net$/, '')} – ${error.message}`
                }, { quoted: msg });
            }
        }
    }
};