const config = require('../config');
const fs = require('fs');
const path = require('path');

const accountsFile = path.join(__dirname, '../data/bankAccounts.json');

function loadAccounts() {
    if (!fs.existsSync(accountsFile)) return {};
    return JSON.parse(fs.readFileSync(accountsFile, 'utf8'));
}

module.exports = {
    category: 'bank',
    command: 'رقمي',
    description: '🔢 عرض رقم حسابك البنكي',
    usage: '.رقمي',
    
    async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
                const chatId = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;
        const senderNumber = sender.split('@')[0];

        const accounts = loadAccounts();
        const account = accounts[senderNumber];
        
        if (!account) {
            return sock.sendMessage(chatId, {
                text: '❌ ليس لديك حساب بنكي!\nاستخدم .انشاء لإنشاء حساب'
            }, { quoted: msg });
        }

        // ✅ رسالة قصيرة جداً: الرقم فقط
        await sock.sendMessage(chatId, {
            text: `${account.accountNumber}`
        }, { quoted: msg });
    }
};