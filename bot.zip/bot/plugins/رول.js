// plugins/game/rol.js

module.exports = {
  command: 'رول',
  category: 'game',
  description: '🎲 اختيار عشوائي لشخص أو أكثر من المجموعة',
  usage: '.رول [عدد الفائزين]',

  async execute(sock, msg, args) {
    try {
      const from = msg.key.remoteJid;
      const sender = msg.key.participant || msg.key.remoteJid;

      // ✅ التحقق من أنها مجموعة
      if (!from || !from.endsWith('@g.us')) {
        return sock.sendMessage(from, {
          text: '❌ هذا الأمر يعمل فقط في المجموعات.'
        }, { quoted: msg });
      }

      // ✅ تحديد عدد الفائزين
      let count = 1;
      if (args && args.length > 0) {
        count = parseInt(args[0]) || 1;
      }
      if (count < 1) count = 1;
      if (count > 3) count = 3;

      // ✅ جلب أعضاء المجموعة
      const metadata = await sock.groupMetadata(from);
      
      // ✅ التأكد من وجود participants
      if (!metadata || !metadata.participants || metadata.participants.length === 0) {
        return sock.sendMessage(from, {
          text: '❌ لا يوجد أعضاء في المجموعة.'
        }, { quoted: msg });
      }

      const participants = metadata.participants.map(p => p.id);

      // ✅ استبعاد البوت
      const botNumber = sock.user.id.split(':')[0];
      const filtered = participants.filter(p => {
        if (!p) return false;
        const num = p.split('@')[0];
        return num && num !== botNumber;
      });

      if (!filtered || filtered.length === 0) {
        return sock.sendMessage(from, {
          text: '❌ لا يوجد أعضاء في المجموعة.'
        }, { quoted: msg });
      }

      // ✅ خلط واختيار عشوائي
      const shuffled = filtered.sort(() => Math.random() - 0.5);
      const winners = shuffled.slice(0, Math.min(count, shuffled.length));

      if (!winners || winners.length === 0) {
        return sock.sendMessage(from, {
          text: '❌ لا يوجد فائزين.'
        }, { quoted: msg });
      }

      // ✅ بناء الرسالة
      let winnerText = '';
      if (winners.length === 1) {
        winnerText = `🎉 *الفائز هو:*\n\n@${winners[0].split('@')[0]}`;
      } else {
        winnerText = `🎉 *الفائزون هم:*\n\n${winners.map((w, i) => `${i + 1}. @${w.split('@')[0]}`).join('\n')}`;
      }

      const message = `
▣━━━━━━━━━⊶𔒝⊷━━━━━━━━━▣
◞ اعلان الفائزين ◜

${winnerText}

⋆ ❪ مبروك للفائزين ❫ ⌲
▣━━━━━━━━━⊶𔒝⊷━━━━━━━━━▣
      `;

      await sock.sendMessage(from, {
        text: message,
        mentions: winners
      }, { quoted: msg });

    } catch (error) {
      console.error('❌ خطأ في أمر رول:', error);
      // ✅ إرسال رسالة خطأ للمستخدم
      const from = msg.key.remoteJid;
      await sock.sendMessage(from, {
        text: '❌ حدث خطأ أثناء تنفيذ الأمر.'
      }, { quoted: msg });
    }
  }
};