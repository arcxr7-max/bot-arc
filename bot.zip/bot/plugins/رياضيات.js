const config = require('../config');
const fs = require('fs');
const path = require('path');

const pointsFile = path.join(__dirname, '../data/points.json');

function getPoints() {
    if (!fs.existsSync(pointsFile)) return {};
    return JSON.parse(fs.readFileSync(pointsFile, 'utf8'));
}

function savePoints(points) {
    fs.writeFileSync(pointsFile, JSON.stringify(points, null, 2));
}

function generateQuestion() {
    const operations = ['+', '-', '×', '÷'];
    const op = operations[Math.floor(Math.random() * operations.length)];
    let a, b, answer, text;
    
    if (op === '+') {
        a = Math.floor(Math.random() * 50) + 1;
        b = Math.floor(Math.random() * 50) + 1;
        answer = a + b;
        text = `${a} + ${b} = ?`;
    } 
    else if (op === '-') {
        a = Math.floor(Math.random() * 50) + 30;
        b = Math.floor(Math.random() * a) + 1;
        answer = a - b;
        text = `${a} - ${b} = ?`;
    }
    else if (op === '×') {
        a = Math.floor(Math.random() * 10) + 1;
        b = Math.floor(Math.random() * 10) + 1;
        answer = a * b;
        text = `${a} × ${b} = ?`;
    }
    else {
        b = Math.floor(Math.random() * 10) + 1;
        answer = Math.floor(Math.random() * 10) + 1;
        a = b * answer;
        text = `${a} ÷ ${b} = ?`;
    }
    
    return { text, answer };
}

if (!global.mathGames) global.mathGames = {};

module.exports = {
    command: 'رياضيات',
    description: '🧮 حل المسألة الرياضية واربح نقاط',
    usage: '.رياضيات',
    category: 'game',

    async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
                const chatId = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;
        const senderNumber = sender.split('@')[0];

        // ✅ التحقق: إذا كان هناك لعبة نشطة، لا تبدأ لعبة جديدة
        if (global.mathGames[senderNumber]) {
            return sock.sendMessage(chatId, {
                text: '⚠️ لديك سؤال نشط بالفعل! أجب عليه أولاً.'
            }, { quoted: msg });
        }

        const question = generateQuestion();
        
        global.mathGames[senderNumber] = {
            answer: question.answer,
            chatId: chatId,
            time: Date.now(),
            active: true
        };

        await sock.sendMessage(chatId, {
            text: `🧮 *تحدي الرياضيات*\n\n${question.text}\n\n⌛ أجب خلال 30 ثانية\n💰 الجائزة: +30 نقطة`
        }, { quoted: msg });

        // ✅ مؤقت 30 ثانية
        setTimeout(async () => {
            if (global.mathGames[senderNumber] && global.mathGames[senderNumber].active) {
                const game = global.mathGames[senderNumber];
                delete global.mathGames[senderNumber];
                await sock.sendMessage(chatId, { 
                    text: `⌛ *انتهى الوقت!*\nالجواب الصحيح: ${game.answer}\nحاول مرة أخرى بـ .رياضيات`
                });
            }
        }, 30000);
    }
};