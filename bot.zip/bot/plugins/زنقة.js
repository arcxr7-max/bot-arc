const config = require('../config');
const fs = require('fs');
const path = require('path');

const pointsFile = path.join(__dirname, '../data/points.json');

function getPoints() {
    if (!fs.existsSync(pointsFile)) return {};
    return JSON.parse(fs.readFileSync(pointsFile, 'utf8'));
}

function savePoints(points) {
    fs.writeFileSync(pointsFile, JSON.stringify(points, null, 2));
}

if (!global.numberGames) global.numberGames = {};

module.exports = {
    command: 'زنقة',
    description: '🔢 أكمل المتسلسلة العددية',
    usage: '.زنقة',
    category: 'game',

    async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
                const chatId = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;
        const senderNumber = sender.split('@')[0];

        if (global.numberGames[senderNumber]) {
            return sock.sendMessage(chatId, { text: '⚠️ لديك لعبة نشطة!' }, { quoted: msg });
        }

        const start = Math.floor(Math.random() * 20) + 1;
        const diff = Math.floor(Math.random() * 5) + 1;
        const sequence = [start, start + diff, start + diff * 2];
        const nextNumber = start + diff * 3;

        global.numberGames[senderNumber] = { nextNumber, chatId, time: Date.now() };

        await sock.sendMessage(chatId, {
            text: `🔢 *أكمل المتسلسلة*\n\n${sequence.join(', ')}, ?\n\n💰 الجائزة: 40 نقطة\n⏰ لديك 20 ثانية`
        }, { quoted: msg });

        setTimeout(() => {
            if (global.numberGames[senderNumber]) {
                delete global.numberGames[senderNumber];
                sock.sendMessage(chatId, { text: `⌛ انتهى الوقت! الإجابة: ${nextNumber}` });
            }
        }, 20000);
    }
};