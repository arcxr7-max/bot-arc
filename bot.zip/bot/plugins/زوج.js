const config = require('../config');
const fs = require('fs');
const path = require('path');

const dbDir = path.join(process.cwd(), 'db');
const dbFile = path.join(dbDir, 'marriages.json');

if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });
if (!fs.existsSync(dbFile)) fs.writeFileSync(dbFile, '{}');

const couplesEmojis = ['💑', '👩‍❤️‍👨', '💕', '💞', '💖', '💘'];

function loadMarriages() {
    try { return JSON.parse(fs.readFileSync(dbFile, 'utf8')); } catch { return {}; }
}

function getRandomEmoji() {
    return couplesEmojis[Math.floor(Math.random() * couplesEmojis.length)];
}

module.exports = {
    category: 'fun',
    command: ['زوج'],
    description: 'عرض الزيجات المسجلة بشكل منسق وجميل',
    usage: '.زوج عرض',

    async execute(sock, msg) {
        let fullText = '';
        if (msg.message?.conversation) fullText = msg.message.conversation;
        else if (msg.message?.extendedTextMessage?.text) fullText = msg.message.extendedTextMessage.text;
        
        const args = fullText.trim().split(/\s+/).slice(1);
        const chatId = msg.key.remoteJid;

        if (args.length === 0 || args[0].toLowerCase() !== 'عرض') {
            await sock.sendMessage(chatId, {
                text: '⚠️ يرجى كتابة الأمر بشكل صحيح:\n.زوج عرض',
            }, { quoted: msg });
            return;
        }

        const allMarriages = loadMarriages();
        const currentGroupMarriages = allMarriages[chatId] || {};
        const entries = Object.entries(currentGroupMarriages);

        if (entries.length === 0) {
            await sock.sendMessage(chatId, {
                text: '❌ لا توجد زيجات مسجلة حالياً.',
            }, { quoted: msg });
            return;
        }

        const displayed = new Set();
        let text = `💞✨ قائمة الزيجات المسجلة ✨💞\n\nعدد الزيجات: ${Math.floor(entries.length / 2)}\n\n`;

        for (const [partner1, [name1, partner2]] of entries) {
            if (displayed.has(partner1) || displayed.has(partner2)) continue;

            const emoji = getRandomEmoji();
            text += `${emoji}  @${partner1.split('@')[0]}  ❤️  @${partner2.split('@')[0]}\n`;
            text += '─────────────────\n';
            displayed.add(partner1);
            displayed.add(partner2);
        }

        text += `\n🌹 نتمنى للجميع حياة مليئة بالحب والسعادة 🌹`;

        await sock.sendMessage(chatId, {
            text,
            mentions: Array.from(displayed),
        }, { quoted: msg });
    }
};