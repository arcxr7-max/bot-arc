const config = require('../config');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

const dbDir = path.join(process.cwd(), 'db');
const dbFile = path.join(dbDir, 'marriages.json');

if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });
if (!fs.existsSync(dbFile)) fs.writeFileSync(dbFile, '{}');

function loadMarriages() {
    try { return JSON.parse(fs.readFileSync(dbFile, 'utf8')); } catch { return {}; }
}

function saveMarriages(data) {
    fs.writeFileSync(dbFile, JSON.stringify(data, null, 2));
}

module.exports = {
    command: 'زوجني',
    description: '💍 يزوجك من شخص عشوائي ويحفظ الزواج في السجل الخاص',
    usage: '.زوجني',
    category: 'fun',

    async execute(sock, msg) {
        const chatId = msg.key.remoteJid;
        const senderId = msg.key.participant || msg.key.remoteJid;

        if (!msg.key.participant) {
            return sock.sendMessage(chatId, {
                text: '❌ هذا الأمر يعمل فقط بالداخل.',
            }, { quoted: msg });
        }

        const allMarriages = loadMarriages();
        if (!allMarriages[chatId]) allMarriages[chatId] = {};
        const currentGroupMarriages = allMarriages[chatId];

        if (currentGroupMarriages[senderId]) {
            const currentPartner = currentGroupMarriages[senderId][1];
            return sock.sendMessage(chatId, {
                text: `⚠️ أنت متزوج بالفعل من: @${currentPartner.split('@')[0]} ! لا يمكنك الزواج مجدداً إلا بعد الطلاق باستخدام أمر .طلاق`,
                mentions: [currentPartner]
            }, { quoted: msg });
        }

        try {
            const metadata = await sock.groupMetadata(chatId);
            const participants = metadata.participants
                .filter(p => p.id !== senderId && !p.admin && !currentGroupMarriages[p.id])
                .map(p => p.id);

            if (participants.length === 0) {
                return sock.sendMessage(chatId, {
                    text: '❌ لا يوجد أحد أعزب حالياً!',
                }, { quoted: msg });
            }

            const randomPartner = participants[Math.floor(Math.random() * participants.length)];

            const partnerTag = '@' + randomPartner.split('@')[0];
            const senderTag = '@' + senderId.split('@')[0];

            const imageUrl = 'https://raw.githubusercontent.com/arcxr7-max/ARC/refs/heads/main/1777455051968-aef804cb-cd31-4ea4-bef7-195e21788262.jpg';
            const response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
            const buffer = Buffer.from(response.data, 'utf-8');

            currentGroupMarriages[senderId] = [senderTag, randomPartner];
            currentGroupMarriages[randomPartner] = [partnerTag, senderId];
            
            allMarriages[chatId] = currentGroupMarriages;
            saveMarriages(allMarriages);

            const caption = `
💞👰‍♀️ حفل زفاف جديد! 🤵💍

🎉 ألف مبروك [ ${senderTag} 💘 ${partnerTag} ]

✨ لقد تم عقد قرانكم على سنة الله ورسوله.

💐 نتمنى لكم حياة مليئة بالحب والفرح!

╰─⟡ 𝗔𝗥𝗖 𝗕𝗢𝗧 ⦿
            `.trim();

            await sock.sendMessage(chatId, {
                image: buffer,
                caption,
                mentions: [senderId, randomPartner],
            }, { quoted: msg });

        } catch (err) {
            console.error('❌ خطأ في أمر زوجني:', err);
            await sock.sendMessage(chatId, {
                text: `❌ حصل خطأ أثناء محاولة الزواج:\n\`\`\`${err.message}\`\`\``
            }, { quoted: msg });
        }
    }
};