const fs = require('fs');
const path = require('path');
const axios = require('axios');

const pointsFile = path.join(__dirname, '../data/points.json');
const animeGames = new Map();

// رابط الأسئلة المباشر من GitHub
const QUESTIONS_URL = 'https://raw.githubusercontent.com/arcxr7-max/ARC/a068b387dc52de2fb8b2ab73ecbf686ddd6ff7ff/soal.json';

function loadPoints() {
    if (!fs.existsSync(pointsFile)) fs.writeFileSync(pointsFile, '{}');
    return JSON.parse(fs.readFileSync(pointsFile));
}

function addPoints(user, amount) {
    const points = loadPoints();
    points[user] = (points[user] || 0) + amount;
    fs.writeFileSync(pointsFile, JSON.stringify(points, null, 2));
    return points[user];
}

module.exports = {
    command: 'سؤال',
    description: '🎮 مسابقة الانمي الكبرى لربح النقاط',
    category: 'game',

    async execute(sock, msg) {
        const chatId = msg.key.remoteJid;

        // التحقق من وجود لعبة جارية
        if (animeGames.has(chatId)) {
            return await sock.sendMessage(chatId, { 
                text: `┃ ⚠️ *تنبيه:* يوجد سؤال قائم بالفعل في هذه المجموعة!` 
            }, { quoted: msg });
        }

        try {
            // جلب الأسئلة مباشرة من الرابط
            const { data: animeQuestions } = await axios.get(QUESTIONS_URL);

            if (!Array.isArray(animeQuestions) || animeQuestions.length === 0) {
                return await sock.sendMessage(chatId, { 
                    text: '┃ ❌ *خطأ:* تعذر تحميل قائمة الأسئلة.' 
                }, { quoted: msg });
            }

            const random = animeQuestions[Math.floor(Math.random() * animeQuestions.length)];
            const cleanAnswer = random.a.trim().replace(/[أإآ]/g, 'ا');

            // إعداد بيانات اللعبة
            const gameData = {
                answer: cleanAnswer,
                original: random.a,
                points: random.p,
                handler: null,
                timeout: null
            };

            const messageText = `
┃ 📊 *الصعوبة:* ${random.d}
┃ ❓ *السؤال:*
┃ ${random.q}

┃ ⏳ *الوقت:* 30 ثانية
┃ 🎁 *الجائزة:* ${random.p} نقطة`.trim();

            await sock.sendMessage(chatId, {
                text: messageText
            }, { quoted: msg });

            // تعريف الـ Handler
            gameData.handler = async ({ messages }) => {
                const reply = messages[0];
                if (!reply.message || reply.key.fromMe) return;

                const from = reply.key.remoteJid;
                if (from !== chatId) return;

                const text = (reply.message.conversation || reply.message.extendedTextMessage?.text || '').trim().toLowerCase().replace(/[أإآ]/g, 'ا');

                if (text === gameData.answer) {
                    // إيقاف كل شيء فوراً
                    clearTimeout(gameData.timeout);
                    sock.ev.off('messages.upsert', gameData.handler);
                    animeGames.delete(chatId);
                    
                    const senderJid = reply.key.participant || reply.key.remoteJid;
                    const user = senderJid.split('@')[0];
                    const totalPoints = addPoints(user, gameData.points);

                    await sock.sendMessage(chatId, { react: { text: "🏆", key: reply.key } });
                    
                    const winText = `
┃ 🎉 *إجابة صحيحة!*
┃ 👤 *الفائز:* @${user}
┃ ✅ *الجواب:* ${gameData.original}
┃ 🎁 *الجائزة:* ${gameData.points} نقطة
┃ 💰 *رصيدك الكلي:* ${totalPoints} نقطة`.trim();

                    return await sock.sendMessage(chatId, {
                        text: winText,
                        mentions: [senderJid]
                    }, { quoted: reply });
                }
            };

            // بدء المراقب
            sock.ev.on('messages.upsert', gameData.handler);

            // بدء المؤقت بعد إرسال السؤال
            gameData.timeout = setTimeout(() => {
                if (animeGames.has(chatId)) {
                    sock.ev.off('messages.upsert', gameData.handler);
                    
                    const timeoutText = `
┃ ⏳ *انتهى الوقت!*
┃ ❌ *لم يتمكن أحد من الإجابة.*
┃ ✅ *الجواب الصحيح:* ${gameData.original}`.trim();

                    sock.sendMessage(chatId, {
                        text: timeoutText
                    });
                    animeGames.delete(chatId);
                }
            }, 30000);

            animeGames.set(chatId, gameData);

        } catch (error) {
            console.error('❌ خطأ في أمر سؤال:', error);
            await sock.sendMessage(chatId, { 
                text: '┃ ❌ *خطأ:* تعذر جلب الأسئلة، يرجى المحاولة لاحقاً.' 
            }, { quoted: msg });
        }
    }
};
