const config = require('../config');
module.exports = {
  command: "سبام",
  description: "سبام مخصص بعدد معين ⚠️",
  usage: ".سبام [كلمة] [عدد]",
  category: "fun",

  async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
            try {
      const args = msg.args;
      const jid = msg.key.remoteJid;

      if (!args || args.length < 2) {
        return await sock.sendMessage(jid, { text: "⛔ استخدم الأمر كده:\n.سبام [كلمة] [عدد]" }, { quoted: msg });
      }

      const text = args[0];
      const count = parseInt(args[1]);

      if (isNaN(count) || count <= 0 || count > 100) {
        return await sock.sendMessage(jid, { text: "❌ العدد لازم يكون من 1 إلى 100 فقط." }, { quoted: msg });
      }

      await sock.sendMessage(jid, { text: `📤 جاري إرسال "${text}" ${count} مرة...` }, { quoted: msg });

      for (let i = 0; i < count; i++) {
        try {
          // هنا بنرسل بدون quoted لتفادي المشكلة
          await sock.sendMessage(jid, { text });
          await new Promise(resolve => setTimeout(resolve, 400));
        } catch (err) {
          console.log(`❌ سبام توقف عند الرسالة ${i + 1}:`, err.message);
          break;
        }
      }

    } catch (error) {
      console.error("❌ Spam Command Error:", error);
      await sock.sendMessage(msg.key.remoteJid, {
        text: "⚠️ حدث خطأ أثناء تنفيذ الأمر.",
      });
    }
  }
};