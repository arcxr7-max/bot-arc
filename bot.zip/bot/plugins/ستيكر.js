// plugins/ستيكر.js
const fs = require('fs');
const path = require('path');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

module.exports = {
  command: 'ستيكر',
  description: '🖼️ تحويل الملصق إلى صورة',
  usage: 'ارسل .ستيكر بالرد على ملصق',
  category: 'media',

  async execute(sock, m) {
    const chatId = m.key.remoteJid;

    // البحث عن الملصق (مباشر أو مقتبس)
    const stickerMsg = m.message?.stickerMessage ||
                       m.message?.extendedTextMessage?.contextInfo?.quotedMessage?.stickerMessage;

    if (!stickerMsg) {
      return sock.sendMessage(chatId, {
        text: '❌ الرجاء الرد على ملصق (Sticker) بالأمر .ستيكر'
      }, { quoted: m });
    }

    try {
      // إظهار تفاعل بصري
      await sock.sendMessage(chatId, { react: { text: '🔄', key: m.key } });

      // تحميل محتوى الملصق (WebP)
      const stream = await downloadContentFromMessage(stickerMsg, 'sticker');
      let buffer = Buffer.from([]);
      for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
      }

      // إنشاء مجلد temp داخل البوت
      const tempDir = path.join(__dirname, '../temp');
      if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });

      // حفظ الملف المؤقت بصيغة webp
      const webpPath = path.join(tempDir, `sticker_${Date.now()}.webp`);
      fs.writeFileSync(webpPath, buffer);

      // إرسال الصورة (WebP مدعوم كصورة في الواتساب)
      await sock.sendMessage(chatId, {
        image: buffer,
        caption: '✅ تم تحويل الملصق إلى صورة بنجاح'
      }, { quoted: m });

      // حذف الملف المؤقت
      fs.unlinkSync(webpPath);
      await sock.sendMessage(chatId, { react: { text: '✅', key: m.key } });

    } catch (err) {
      console.error('خطأ في تحويل الملصق:', err);
      await sock.sendMessage(chatId, {
        text: '❌ حدث خطأ أثناء التحويل، تأكد من أن الرد يحتوي على ملصق صالح.'
      }, { quoted: m });
    }
  }
};