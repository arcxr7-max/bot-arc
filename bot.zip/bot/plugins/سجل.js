const config = require('../config');
const fs = require('fs');
const path = require('path');

const guildsFile = path.join(__dirname, '../data/guilds.json');

function loadGuilds() {
    if (!fs.existsSync(guildsFile)) return {};
    return JSON.parse(fs.readFileSync(guildsFile, 'utf8'));
}

function saveGuilds(data) {
    fs.writeFileSync(guildsFile, JSON.stringify(data, null, 2));
}

const ARABIC_LETTERS = ['ا', 'ب', 'ت', 'ث', 'ج', 'ح', 'خ', 'د', 'ذ', 'ر', 'ز', 'س', 'ش', 'ص', 'ض', 'ط', 'ظ', 'ع', 'غ', 'ف', 'ق', 'ك', 'ل', 'م', 'ن', 'ه', 'و', 'ي'];

function getFirstLetter(text) {
    const firstChar = text.charAt(0);
    if (ARABIC_LETTERS.includes(firstChar)) return firstChar;
    return null;
}

async function updateWelcomeGroupDesc(sock, guildData) {
    const titles = guildData.titles || {};
    const takenCount = Object.keys(titles).length;
    const groupName = guildData.welcomeGroupName;

    let description = `عـدد الـقـاب مـؤخـودة ⊰• ${takenCount} •⊱\n`;
    description += `ـ✢ ⊱┄ ┅━ • ${groupName}┆⬪雷 • ━┅ ┈⊰ ✢\n`;

    for (const letter of ARABIC_LETTERS) {
        const userWithThisLetter = Object.entries(titles).find(([id, data]) => data.firstLetter === letter);
        if (userWithThisLetter) {
            description += `ـ• ⊰ ${letter} ⊱\nـ「 ${userWithThisLetter[1].title} 」\n`;
        } else {
            description += `ـ• ⊰ ${letter} ⊱\nـ「」\n`;
        }
    }

    description += `ـ✢ ⊱┄ ┅━ • ┆⬪雷 • ━┅ ┈⊰ ✢\n`;
    description += `ـ◝⚜️┆• ${groupName} •┆⚜️◟ـ`;

    try {
        await sock.groupUpdateDescription(guildData.welcomeGroupId, description);
    } catch (e) {}
}

module.exports = {
    command: 'سجل',
    description: '🛡️ تسجيل أو تعديل لقب عضو آخر (للمشرفين والمطورين والنخبة)',
    usage: '.سجل [@منشن أو بالرد] [اللقب]',
    category: 'group',

    async execute(sock, msg) {
        const chatId = msg.key.remoteJid;

        // 🛡️ فحص الصلاحيات المتوافق مع نظام الحماية الخاص بأوامرك
        const senderNum = (msg.key.participant || msg.key.remoteJid).split('@')[0];
        const { isDev } = require('../utils/devs');
        const eliteFilePath = path.join(process.cwd(), 'data', 'elite.json');
        let eliteNumbers = [];
        if (fs.existsSync(eliteFilePath)) {
            try { eliteNumbers = JSON.parse(fs.readFileSync(eliteFilePath, 'utf-8')).eliteNumbers || []; } catch(e){}
        }
        const groupMetadata = chatId.endsWith('@g.us') ? await sock.groupMetadata(chatId) : null;
        const isAdmin = groupMetadata ? groupMetadata.participants.find(p => p.id.split('@')[0] === senderNum)?.admin : false;
        
        if (!isDev(senderNum) && !eliteNumbers.includes(senderNum) && !isAdmin) {
            return sock.sendMessage(chatId, { text: '🛡️ ┋ هذا الأمر يتطلب صلاحيات المشرفين أو المطور أو النخبة!' }, { quoted: msg });
        }

        // 🎯 1. تحديد الشخص المستهدف (إما عبر المنشن أو عبر الرد على رسالته)
        const mentionedJid = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
        const quotedParticipant = msg.message?.extendedTextMessage?.contextInfo?.participant;
        const targetJid = mentionedJid || quotedParticipant;

        if (!targetJid) {
            return sock.sendMessage(chatId, { text: '⚠️ يرجى الرد على رسالة العضو أو عمل منشن له بعد الأمر وتحديد اللقب!\n\n💡 مثال:\n.سجل @منشن الصقر' }, { quoted: msg });
        }

        // استخراج الرقم الصافي للمستهدف بنفس صيغة تخزين .لقبي
        const targetNumber = targetJid.split('@')[0].split(':')[0];

        // 📝 2. استخراج اللقب من النص وتنظيفه
        let fullText = '';
        if (msg.message?.conversation) fullText = msg.message.conversation;
        else if (msg.message?.extendedTextMessage?.text) fullText = msg.message.extendedTextMessage.text;

        // إزالة الأمر والمنشن من النص للحصول على اللقب الصافي فقط
        let newTitle = fullText.replace(/^\.سجل\s*/, '').replace(new RegExp(`@${targetNumber}\\s*`), '').trim();

        if (!newTitle) {
            return sock.sendMessage(chatId, { text: '❌ يرجى كتابة اللقب المراد تسجيله للعضو بعد المنشن أو الرد.' }, { quoted: msg });
        }

        // 🏛️ 3. تحميل النقابات والبحث عن النقابة المرتبطة
        let guilds = loadGuilds();
        let currentGuild = null;

        for (const [id, guild] of Object.entries(guilds)) {
            if (guild.welcomeGroupId === chatId || guild.mainGroupId === chatId) {
                currentGuild = guild;
                break;
            }
        }

        if (!currentGuild) {
            return sock.sendMessage(chatId, { text: '❌ هذا القروب غير مرتبط بأي نقابة.' }, { quoted: msg });
        }

        if (!currentGuild.titles) currentGuild.titles = {};

        // 🔤 4. الفحوصات (الحرف العربي والتكرار) كما في .لقبي تماماً
        const firstLetter = getFirstLetter(newTitle);
        if (!firstLetter) {
            return sock.sendMessage(chatId, { text: '❌ اللقب يجب أن يبدأ بحرف عربي' }, { msg });
        }

        const existingUser = Object.entries(currentGuild.titles).find(([id, data]) => data.title.toLowerCase() === newTitle.toLowerCase());
        if (existingUser && existingUser[0] !== targetNumber) {
            return sock.sendMessage(chatId, { text: `❌ اللقب "${newTitle}" مأخوذ بالفعل من قبل عضو آخر.` }, { quoted: msg });
        }

        // 💾 5. تخزين البيانات وتحديث الوصف
        if (currentGuild.titles[targetNumber]) {
            delete currentGuild.titles[targetNumber];
        }

        currentGuild.titles[targetNumber] = {
            title: newTitle,
            firstLetter: firstLetter,
            chosenAt: Date.now()
        };

        saveGuilds(guilds);
        await updateWelcomeGroupDesc(sock, currentGuild);

        // إرسال رسالة التأكيد مع منشن للشخص الذي تم تسجيل لقبه
        await sock.sendMessage(chatId, {
            text: `✅ تم تسجيل لقب العضو @${targetNumber} بنجاح.\n🏷️ اللقب: ${newTitle}`,
            mentions: [targetJid]
        }, { quoted: msg });
    }
};