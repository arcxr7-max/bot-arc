const config = require('../config');

module.exports = {
  category: 'fun',
  command: ['سجن'],
  description: 'حبس أحد الأعضاء بشكل رمزي داخل الجروب',
  usage: '.سجن @العضو',
  group: true,

  async execute(sock, msg) {
    const chatId = msg.key.remoteJid;

    // استخراج الشخص المنشن بشكل آمن
    const mentionedJid = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    const mention = mentionedJid[0];

    if (!mention) {
      return await sock.sendMessage(chatId, {
        text: '❌ منشن الشخص اللي عايز تسجنه.'
      }, { quoted: msg });
    }

    try {
      // جلب بيانات أعضاء المجموعة للمنشن المخفي
      const metadata = await sock.groupMetadata(chatId);
      const allMembers = metadata.participants.map(p => p.id);

      // استخراج المعرفات (JID) بشكل آمن
      const senderJid = msg.key.participant || chatId;
      const sender = senderJid.split('@')[0];
      const target = mention.split('@')[0];

      const text = `🔒 تم سجن العضو: @${target}

📛 التهمة: تجاوز حدود الأدب العام 😤
📅 مدة الحبس: غير محددة
👮‍♂️ القاضي: @${sender}

🚨 التنبيه: أي محاولة للهرب هتواجه بعقوبات صارمة 🥶`;

      await sock.sendMessage(chatId, {
        text: text,
        mentions: allMembers, // منشن للجميع
      }, { quoted: msg });

    } catch (error) {
      console.error('❌ خطأ في تنفيذ أمر سجن:', error);
      await sock.sendMessage(chatId, {
        text: '❌ حدث خطأ أثناء تنفيذ أمر السجن.'
      }, { quoted: msg });
    }
  }
};
