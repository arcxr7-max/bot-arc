const config = require('../config');
module.exports = {
    category: 'fun',
  command: ['سجن'],
  description: 'حبس أحد الأعضاء بشكل رمزي داخل الجروب',
    usage: '.سجن @العضو',
  group: true,

  async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
            const mention = msg.mentionedJid && msg.mentionedJid[0];
    if (!mention) return msg.reply('❌ منشن الشخص اللي عايز تسجنه.');

    const metadata = await sock.groupMetadata(msg.chat);
    const allMembers = metadata.participants.map(p => p.id);

    const sender = msg.sender.split('@')[0];
    const target = mention.split('@')[0];

    const text = `🔒 تم سجن العضو: @${target}

📛 التهمة: تجاوز حدود الأدب العام 😤
📅 مدة الحبس: غير محددة
👮‍♂️ القاضي: @${sender}

🚨 التنبيه: أي محاولة للهرب هتواجه بعقوبات صارمة 🥶`;

    await sock.sendMessage(msg.chat, {
      text: text,
      mentions: allMembers, // منشن خفي للجميع
    });
  }
};