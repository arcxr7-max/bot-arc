const config = require('../config');
const fs = require('fs');

module.exports = {
  command: ['سرعه'],
  description: 'حساب سرعة استجابة البوت (Latency) بوحدة الثواني',
  category: 'tools',

  async execute(sock, msg, args = []) {
    try {
      const start = Date.now(); // تسجيل وقت البداية

      // 1. إرسال الرسالة الأولى وتخزين الاستجابة
      const response = await sock.sendMessage(msg.key.remoteJid, {
        text: '_*جــــاري حـــساب ســـرعه البوت..... 🌙*_'
      }, { quoted: msg });

      const end = Date.now(); // تسجيل الوقت بعد الإرسال
      const pingSeconds = ((end - start) / 1000).toFixed(2); // تحويل لثواني

      // تنسيق النص النهائي
      const resultText = `*ســـرعه الانــترنت عـــند الـــبوت حالــيا هــي ${pingSeconds} ثانية🔥*`;

      // قراءة الصورة المصغرة إن وجدت
      const imagePath = "image.jpeg";
      const hasImage = fs.existsSync(imagePath);
      const imageBuffer = hasImage ? fs.readFileSync(imagePath) : null;

      // 2. تعديل الرسالة الأولى نفسها
      await sock.sendMessage(msg.key.remoteJid, {
        text: resultText,
        edit: response.key, // هنا يتم تحديد الرسالة المراد تعديلها
        contextInfo: {
          externalAdReply: {
            title: "© ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴀʀᴄ ᴇʟɪᴛᴇ",
            body: "تم حساب سرعة البوت بنجاح 🎉",
            thumbnail: imageBuffer,
            mediaType: 1,
            sourceUrl: "https://t.me/Sanji_Bot_Channel",
            renderLargerThumbnail: false,
            showAdAttribution: true
          }
        }
      });

    } catch (err) {
      await sock.sendMessage(msg.key.remoteJid, {
        text: `⚠️ حدث خطأ: ${err.message || err.toString()}`,
      }, { quoted: msg });
    }
  }
};
