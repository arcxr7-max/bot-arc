const config = require('../config');
const fs = require('fs');
const path = require('path');

const pointsFile = path.join(__dirname, '../data/points.json');
const protectedFile = path.join(__dirname, '../data/protected.json');
const robDataFile = path.join(__dirname, '../data/robData.json');

// وقت التهدئة (7 دقائق = 420000 مللي ثانية)
const COOLDOWN_TIME = 420000;

function getPoints() {
    if (!fs.existsSync(pointsFile)) return {};
    return JSON.parse(fs.readFileSync(pointsFile, 'utf8'));
}

function savePoints(points) {
    fs.writeFileSync(pointsFile, JSON.stringify(points, null, 2), 'utf8');
}

function getProtected() {
    if (!fs.existsSync(protectedFile)) return {};
    return JSON.parse(fs.readFileSync(protectedFile, 'utf8'));
}

function getRobData() {
    if (!fs.existsSync(robDataFile)) return {};
    return JSON.parse(fs.readFileSync(robDataFile, 'utf8'));
}

function saveRobData(data) {
    fs.writeFileSync(robDataFile, JSON.stringify(data, null, 2), 'utf8');
}

function getRemainingTime(lastTime, cooldown = COOLDOWN_TIME) {
    if (!lastTime || lastTime === 0) return 'الآن';
    
    const now = Date.now();
    const diff = lastTime + cooldown - now;
    if (diff <= 0) return 'الآن';
    
    const minutes = Math.floor(diff / 60000);
    const seconds = Math.floor((diff % 60000) / 1000);
    
    if (minutes > 0) {
        return `${minutes} دقيقة ${seconds} ثانية`;
    }
    return `${seconds} ثانية`;
}

module.exports = {
    category: 'fun',
        command: 'سرقة',
    description: '💰 اسرق نقاط من شخص',
    usage: '.سرقة (رد على رسالة الشخص)',
    
    async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
                const chatId = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;
        const senderNumber = sender.split('@')[0];
        const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const victimJid = msg.message?.extendedTextMessage?.contextInfo?.participant;

        // ❌ 1. التحقق من وجود رد
        if (!victimJid || !quoted) {
            return sock.sendMessage(chatId, {
                text: '❌ لازم ترد على رسالة الشخص اللي تبي تسرقه.'
            }, { quoted: msg });
        }

        const victimNumber = victimJid.split('@')[0];

        // ❌ 2. منع سرقة النفس
        if (senderNumber === victimNumber) {
            return sock.sendMessage(chatId, {
                text: '❌ ما تقدر تسرق نفسك! جرب شخص ثاني.'
            }, { quoted: msg });
        }

        let points = getPoints();
        let protected = getProtected();
        let robData = getRobData();
        const now = Date.now();
        
        const victimTotal = points[victimNumber] || 0;
        const victimProtected = protected[victimNumber] || 0;
        const victimAvailable = victimTotal - victimProtected;
        
        const lastRobTime = robData[senderNumber]?.lastTime || 0;
        const lastVictim = robData[senderNumber]?.lastVictim || null;

        // ✅ ترتيب الأولويات في الرسائل:
        
        // 1️⃣ أولاً: التحقق من أن الضحية عنده نقود قابلة للسرقة (غير محمية)
        if (victimAvailable <= 0) {
            return sock.sendMessage(chatId, {
                text: `🛡️ *${victimNumber} محمي* .. حاول مع شخص ثاني`
            }, { quoted: msg });
        }
        
        // 2️⃣ ثانياً: التحقق من فترة التهدئة (7 دقائق)
        if (lastRobTime && (now - lastRobTime) < COOLDOWN_TIME) {
            const timeLeft = getRemainingTime(lastRobTime);
            return sock.sendMessage(chatId, {
                text: `⏳ *انتهت محاولاتك* .. انتضر ${timeLeft}`
            }, { quoted: msg });
        }
        
        // 3️⃣ ثالثاً: التحقق من تكرار نفس الضحية
        if (lastVictim === victimNumber) {
            return sock.sendMessage(chatId, {
                text: `🔄 *سرقته قبل* .. حاول مع شخص ثاني`
            }, { quoted: msg });
        }
        
        // 4️⃣ رابعاً: التحقق من أن الضحية عنده نقود كافية (أقل من 500)
        if (victimAvailable < 500) {
            return sock.sendMessage(chatId, {
                text: `🔄 *الشخص هذا فقير* .. حاول مع شخص ثاني`
            }, { quoted: msg });
        }

        // ✅ تنفيذ السرقة
        const maxRob = Math.min(200, victimAvailable);
        const stolenAmount = Math.floor(Math.random() * maxRob) + 1;

        points[senderNumber] = (points[senderNumber] || 0) + stolenAmount;
        points[victimNumber] = victimTotal - stolenAmount;
        savePoints(points);

        robData[senderNumber] = {
            lastTime: now,
            lastVictim: victimNumber
        };
        saveRobData(robData);

        // ✅ رسالة النجاح
        await sock.sendMessage(chatId, {
            text: `خود يا سارق ${stolenAmount} 💸`,
            mentions: [sender]
        }, { quoted: msg });
    }
};