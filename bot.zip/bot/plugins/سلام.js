const config = require('../config');
const path = require('path');

module.exports = {
  command: 'سلام',
  description: '👋 توديع مع صوت ومنشن ورسالة مزخرفة',
  category: 'fun',

  async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
            const jid = msg.key.remoteJid;
    const isGroup = jid.endsWith('@g.us');
    const audioPath = path.join(__dirname, '../resources/bob.m4a');

    try {
      // جلب المشاركين (لعمل منشن خفي)
      const mentions = isGroup
        ? (await sock.groupMetadata(jid)).participants.map(p => p.id)
        : [];

      await sock.sendMessage(jid, {
        audio: { url: audioPath },
        mimetype: 'audio/mpeg',
        ptt: true,
        caption: '『 ⚠️ 𝗕𝗔𝗧𝗠𝗔𝗡 غادر الساحة لبعض من الوقت... 』',
        mentions
      }, { quoted: msg });

    } catch (err) {
      console.error('✗✗ خطأ في أمر سلام:', err);
      await sock.sendMessage(jid, {
        text: '❌ حصل خطأ أثناء إرسال رسالة المغادرة.',
      }, { quoted: msg });
    }
  }
};