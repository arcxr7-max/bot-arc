// plugins/سنة.js
const axios = require('axios');

// رابط السنن من GitHub (ضع رابط الـ JSON الخاص بك هنا)
const SUNAN_URL = 'https://raw.githubusercontent.com/arcxr7-max/ARC/refs/heads/main/sunan.json';

module.exports = {
    category: 'islamic',
    command: ['سنه'],
    description: '☀️ عرض سنة نبوية عشوائية',
    usage: '.سنة',
    
    async execute(sock, msg) {
        const chatId = msg.key.remoteJid;

        // تفاعل فوري
        await sock.sendMessage(chatId, { react: { text: '☀️', key: msg.key } });

        try {
            // جلب السنن من الرابط
            const response = await axios.get(SUNAN_URL, { timeout: 10000 });
            const sunanList = response.data;

            // التحقق من صحة البيانات
            if (!Array.isArray(sunanList) || sunanList.length === 0) {
                throw new Error('قائمة السنن فارغة أو غير صالحة');
            }

            // اختيار سنة عشوائية
            const randomSunna = sunanList[Math.floor(Math.random() * sunanList.length)];
            
            // تنسيق الرسالة
            const message = `*☀️ سنة اليوم:*\n\n${randomSunna}\n\n━━━━━━━━━━━━━━━━━━\n✨ *اللهم اجعلنا من متبعي السنة* ✨`;
            
            // إرسال السنة
            await sock.sendMessage(chatId, { text: message }, { quoted: msg });
            
            // تفاعل نجاح
            await sock.sendMessage(chatId, { react: { text: '☀️', key: msg.key } });

        } catch (error) {
            console.error('خطأ في جلب السنن:', error);
            await sock.sendMessage(chatId, { 
                text: '❌ *حدث خطأ أثناء جلب السنن النبوية*\n📌 تأكد من صحة الرابط أو حاول لاحقًا.'
            }, { quoted: msg });
            
            // تفاعل خطأ
            await sock.sendMessage(chatId, { react: { text: '❌', key: msg.key } });
        }
    }
};