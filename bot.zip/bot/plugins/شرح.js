const config = require('../config');
const path = require('path');
const { getPlugins } = require('../handlers/plugins');

module.exports = {
  command: ['شرح'],
  description: '🎮 يعرض شرحًا مفصلًا لكل أمر متاح بإيموجيات النيازك والألعاب ☄️',
  category: 'tools',

  async execute(sock, msg) {
    const chatId = msg.key.remoteJid;

    try {
      const plugins = getPlugins();
      if (!plugins || Object.keys(plugins).length === 0) {
        return await sock.sendMessage(chatId, {
          text: '☄️ لا توجد أوامر متاحة حاليًا في البوت.',
        }, { quoted: msg });
      }

      let menu = '☄️ *دليـل الأوامـر والألعـاب المفصّـل* 🎮\n\n';
      const processedCommands = new Set();
      let totalCommands = 0;

      for (const cmdName in plugins) {
        const plugin = plugins[cmdName];
        const commands = Array.isArray(plugin.command) ? plugin.command : [plugin.command];
        const mainCommand = commands[0];

        if (!mainCommand || processedCommands.has(mainCommand)) continue;
        processedCommands.add(mainCommand);
        totalCommands++;

        const category = plugin.category || 'عام';
        const description = plugin.description || 'لا يوجد وصف متاح';
        const usage = plugin.usage ? `\n📌 *الاستخدام:* \`${plugin.usage}\`` : '';

        menu += `☄️ ──── ❲ *${mainCommand.toUpperCase()}* ❳ ──── 🎮\n`;
        menu += `🎯 *الأمر:* .${mainCommand}\n`;
        menu += `⚡ *الفئة:* ${category}\n`;
        menu += `💥 *الوصف:* ${description}${usage}\n\n`;
      }

      menu += `📊 *إجمالي الأوامر المتاحة:* ${totalCommands} أمرًا ☄️`;

      await sock.sendMessage(chatId, {
        text: menu.trim()
      }, { quoted: msg });

    } catch (err) {
      console.error('❌ خطأ في أمر شرح:', err);
      await sock.sendMessage(chatId, {
        text: '💥 حدث خطأ أثناء عرض قائمة الشرح.'
      }, { quoted: msg });
    }
  }
};
