const config = require('../config');
const fs = require('fs');
const path = require('path');

const file = path.join(__dirname, '../data/complaints.json');
const devJid = '201028489465@s.whatsapp.net';

if (!fs.existsSync(file)) fs.writeFileSync(file, '[]');

module.exports = {
  command: "شكوى",
  description: "📢 إرسال شكوى لإدارة البوت",
  usage: ".شكوى [نص الشكوى]",

  async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
            const args = msg.args || [];
    const from = msg.key.remoteJid;
    const name = msg.pushName || "عضو مجهول";
    const sender = msg.participant || msg.key.participant || msg.key.remoteJid;

    const complaint = args.join(" ").trim();

    if (!complaint) {
      return await sock.sendMessage(from, {
        text: "📢 اكتب شكواك بعد الأمر.\nمثال: `.شكوى في عضو بيبعت سبام`"
      }, { quoted: msg });
    }

    const formattedDate = new Date().toLocaleString("ar-EG");

    const list = JSON.parse(fs.readFileSync(file));
    list.push({
      name,
      complaint,
      from: sender,
      date: formattedDate
    });
    fs.writeFileSync(file, JSON.stringify(list, null, 2));

    await sock.sendMessage(from, {
      text: "✅ شكواك تم تسجيلها وتم إرسالها للإدارة.\n📌 شكراً لتعاونك!"
    }, { quoted: msg });

    // استخراج اسم الجروب لو الرسالة من جروب
    let groupName = '';
    if (from.endsWith('@g.us')) {
      try {
        const metadata = await sock.groupMetadata(from);
        groupName = metadata.subject || 'جروب غير معروف';
      } catch {
        groupName = 'جروب غير معروف';
      }
    }

    await sock.sendMessage(devJid, {
      text: `📩 *شكوى جديدة من • ${name}*\n\n` +
            `📬 من: wa.me/${sender.split("@")[0]}\n` +
            (groupName ? `👥 الجروب: ${groupName}\n` : '') +
            `📢 الشكوى:\n${complaint}`
    });
  }
};