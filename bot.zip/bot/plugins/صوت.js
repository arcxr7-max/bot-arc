const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');

module.exports = {
    command: ['صوت'],
    category: 'media',
    description: '🗣️ تحويل النص إلى فويس نوت بصيغة Opus حقيقية',

    async execute(sock, msg) {
        try {
            const from = msg.key.remoteJid;
            const body = msg.message?.extendedTextMessage?.text || msg.message?.conversation || '';
            const args = body.trim().split(/\s+/).slice(1);
            const textToSpeak = args.join(' ');

            if (!textToSpeak) {
                return await sock.sendMessage(from, { 
                    text: '❌ يرجى كتابة النص المراد تحويله إلى صوت بعد الأمر.\nمثال: `.صوت السلام عليكم`' 
                }, { quoted: msg });
            }

            // تفاعل تلقائي 🗣️
            await sock.sendMessage(from, { react: { text: "🗣️", key: msg.key } });

            // رابط محرك جوجل الأساسي والمستقر
            const googleTtsUrl = `https://translate.google.com/translate_tts?ie=UTF-8&tl=ar&client=tw-ob&q=${encodeURIComponent(textToSpeak)}`;
            
            // تحديد مسار الملف المؤقت في السيرفر
            const tempOgg = path.join(__dirname, `../temp_${Date.now()}.opus`);

            // 🎯 الخدعة هنا: نستخدم أمر نظام التشغيل الأساسي (ffmpeg) لتحويل الرابط مباشرة إلى opus حقيقي
            // هذا الأمر يقوم بتحميل الصوت وفك ترميزه وتحويله إلى Opus أصلي بدون أي مكتبة npm
            const ffmpegCommand = `ffmpeg -i "${googleTtsUrl}" -c:a libopus -b:a 16k -vbr on "${tempOgg}" -y`;

            exec(ffmpegCommand, async (error) => {
                if (error) {
                    console.error('❌ خطأ أثناء معالجة وتحويل الصوت:', error);
                    return await sock.sendMessage(from, { text: '❌ فشل تحويل الصوت، تأكد من تثبيت ffmpeg على جهازك.' }, { quoted: msg });
                }

                // قراءة ملف الـ Opus الحقيقي الذي تم تحويله بالكامل وإرساله كفويس نوت طبيعي
                const audioBuffer = fs.readFileSync(tempOgg);

                await sock.sendMessage(from, { 
                    audio: audioBuffer, 
                    mimetype: 'audio/ogg; codecs=opus', 
                    ptt: true 
                }, { quoted: msg });

                // حذف الملف المؤقت فوراً بعد الإرسال لتوفير المساحة
                if (fs.existsSync(tempOgg)) fs.unlinkSync(tempOgg);
            });

        } catch (error) {
            console.error('❌ خطأ في أمر تحويل النص إلى صوت:', error);
            await sock.sendMessage(from, { text: '❌ تعذر معالجة الأمر حالياً.' }, { quoted: msg });
        }
    }
};