// plugins/صور.js
const axios = require('axios');

module.exports = {
  command: 'صور',
  description: '🔎 بحث عشوائي عن صور (يفضل المربعة)',
  usage: '.صور [كلمة] [عدد]',
  category: 'media',

  async execute(sock, message) {
    const chatId = message.key.remoteJid;
    let args = message.args || [];

    await sock.sendMessage(chatId, { react: { text: '🖼️', key: message.key } });

    if (args.length === 0) {
      return await sock.sendMessage(chatId, {
        text: '❌ **الرجاء كتابة كلمة البحث**\n📌 مثال: `.صور لوفي` أو `.صور لوفي 5`',
      }, { quoted: message });
    }

    let count = 1;
    if (!isNaN(args[args.length - 1])) {
      count = Math.min(parseInt(args.pop()), 8);
    }
    const query = args.join(' ');
    if (!query) return;

    try {
      const url = `https://www.bing.com/images/search?q=${encodeURIComponent(query)}&FORM=HDRSC2`;
      const { data } = await axios.get(url, {
        headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' },
        timeout: 10000
      });

      let allImages = [];
      const murlRegex = /m="({[\s\S]*?})"/g;
      let match;

      while ((match = murlRegex.exec(data)) !== null) {
        try {
          const rawJson = match[1].replace(/&quot;/g, '"');
          const meta = JSON.parse(rawJson);
          if (meta.murl) {
            const width = meta.w || 0;
            const height = meta.h || 0;
            let isSquare = false;
            if (width && height) {
              const ratio = Math.min(width, height) / Math.max(width, height);
              isSquare = ratio > 0.8;
            }
            allImages.push({ url: meta.murl, isSquare });
          }
        } catch(e) {}
      }

      allImages = allImages.sort(() => Math.random() - 0.5);
      let squareImages = allImages.filter(img => img.isSquare);
      let finalImages = squareImages.length >= count ? squareImages : allImages;
      finalImages = finalImages.slice(0, count);

      if (finalImages.length === 0) {
        return await sock.sendMessage(chatId, { text: '❌ **لم يتم العثور على صور.**' }, { quoted: message });
      }

      for (let i = 0; i < finalImages.length; i++) {
        await sock.sendMessage(chatId, {
          image: { url: finalImages[i].url },
          caption: `📸 **(${i+1}/${finalImages.length})** **${query}**`
        }, { quoted: message });
        await new Promise(res => setTimeout(res, 500));
      }

    } catch (err) {
      console.error(err);
      await sock.sendMessage(chatId, { text: '❌ **حدث خطأ أثناء البحث.**' }, { quoted: message });
    }
  }
};
