const config = require('../config');
const fs = require('fs');
const { join } = require('path');
const { eliteNumbers } = require('../haykala/elite.js');
const { jidDecode } = require('@whiskeysockets/baileys');

const decode = jid => (jidDecode(jid)?.user || jid.split('@')[0]) + '@s.whatsapp.net';
const modesFile = join(process.cwd(), 'data', 'modes.json');

function loadModes() {
    if (!fs.existsSync(modesFile)) {
        if (!fs.existsSync(join(process.cwd(), 'data'))) {
            fs.mkdirSync(join(process.cwd(), 'data'), { recursive: true });
        }
        fs.writeFileSync(modesFile, JSON.stringify({}));
        return {};
    }
    try { return JSON.parse(fs.readFileSync(modesFile, 'utf8')); } catch (e) { return {}; }
}

function saveModes(data) {
    fs.writeFileSync(modesFile, JSON.stringify(data, null, 2));
}

module.exports = {
    command: 'صن',
    description: 'تفعيل أو إيقاف وضع الصيانة والنخبة للجروب الحالي',
    usage: '.صن [on/off]',
    category: 'tools',    

    async execute(sock, msg) {
        try {
            const groupJid = msg.key.remoteJid;
            const sender = decode(msg.key.participant || groupJid);
            const senderLid = sender.split('@')[0];

            if (!groupJid.endsWith('@g.us')) {
                return await sock.sendMessage(groupJid, { text: '🚫 هذا الأمر يعمل فقط داخل المجموعات.' }, { quoted: msg });
            }

            if (!eliteNumbers.includes(senderLid))
                return await sock.sendMessage(groupJid, { text: '❗ لا تملك صلاحية استخدام هذا الأمر.' }, { quoted: msg });

            let fullText = '';
            if (msg.message?.conversation) fullText = msg.message.conversation;
            else if (msg.message?.extendedTextMessage?.text) fullText = msg.message.extendedTextMessage.text;
            
            const args = fullText.trim().split(/\s+/).slice(1);
            const allModes = loadModes();

            if (!args[0]) {
                const currentMode = allModes[groupJid] || '[off]';
                return await sock.sendMessage(groupJid, {
                    text: `وضع النخبة الحالي في هذه المجموعة هو: ${currentMode}`
                }, { quoted: msg });
            }

            const newMode = args[0].toLowerCase();
            if (!['on', 'off'].includes(newMode)) {
                return await sock.sendMessage(groupJid, {
                    text: '❗ الرجاء استخدام: .صن on أو .صن off'
                }, { quoted: msg });
            }

            allModes[groupJid] = `[${newMode}]`;
            saveModes(allModes);

            await sock.sendMessage(groupJid, {
                text: `✅ تم تغيير وضع النخبة في هذه المجموعة إلى: [${newMode}]`
            }, { quoted: msg });

        } catch (error) {
            console.error('❌ خطأ في أمر صن:', error);
            await sock.sendMessage(msg.key.remoteJid, {
                text: `❌ حدث خطأ أثناء تنفيذ الأمر:\n\n${error.message || error.toString()}`
            }, { quoted: msg });
        }
    }
};