const config = require('../config');
const { addKicked } = require('../haykala/dataUtils');

const developers = [
  '201028489465',
  '201555441212',
  '213842713960581',
  '158664983896251'
];

module.exports = {
  command: 'ضيف',
  description: '➕ تسجيل عدد أعضاء كأنك طردتهم يدويًا (للمطور فقط)',
  usage: '.ضيف 100',
  category: 'zarf',

  async execute(sock, msg, args) {
    const sender = msg.key.participant || msg.key.remoteJid;
    const senderId = sender.split('@')[0];

    if (!developers.includes(senderId)) {
      return sock.sendMessage(msg.key.remoteJid, {
        text: '🚫 هذا الأمر مخصص للمطور فقط!',
      }, { quoted: msg });
    }

    const text = msg.message?.extendedTextMessage?.text || msg.message?.conversation || msg.body || '';
    const numberMatch = text.match(/\.?ضيف\s+(\d+)/i);

    if (!numberMatch) {
      return sock.sendMessage(msg.key.remoteJid, {
        text: '❌ يرجى كتابة عدد الطرد. مثال:\n\n.ضيف 100',
      }, { quoted: msg });
    }

    const amount = parseInt(numberMatch[1]);

    // توليد IDS عشوائية بناءً على الوقت + رقم
    const ids = Array.from({ length: amount }, (_, i) =>
      Date.now() + i
    );

    const total = addKicked(ids);

    await sock.sendMessage(msg.key.remoteJid, {
      text: `✅ تم تسجيل ${amount} طرد يدويًا بنجاح!\n📊 العدد الكلي الآن: ${total.toLocaleString()}`,
    }, { quoted: msg });
  }
};