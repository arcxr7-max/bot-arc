const config = require('../config');
const { extractPureNumber, eliteNumbers } = require('../haykala/elite');

module.exports = {
  command: 'طرد',
  description: 'طرد عضو باستخدام منشن أو الرد، مع رسالة وداع مزخرفة',
  category: 'zarf',
  usage: '.طرد @عضو أو بالرد على رسالته',

  async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
            const groupId = msg.key.remoteJid;
    const senderJid = msg.key.participant || msg.participant || msg.key.remoteJid;
    const senderNumber = extractPureNumber(senderJid);

    // جلب معلومات المجموعة
    const groupMetadata = await sock.groupMetadata(groupId);
    const participants = groupMetadata.participants || [];

    const isAdmin = participants.find(p => p.id === senderJid && (p.admin === 'admin' || p.admin === 'superadmin'));

    if (!eliteNumbers.includes(senderNumber) && !isAdmin) {
      return sock.sendMessage(groupId, {
        text: '⛔ هذا الأمر مخصص للمشرفين أو النخبة فقط.',
      }, { quoted: msg });
    }

    const contextInfo = msg.message?.extendedTextMessage?.contextInfo || {};
    const mentioned = contextInfo.mentionedJid || msg.mentionedJid || [];
    let targetJid = null;

    if (mentioned.length > 0) {
      targetJid = mentioned[0];
    } else if (contextInfo.participant) {
      targetJid = contextInfo.participant;
    }

    if (!targetJid) {
      return sock.sendMessage(groupId, {
        text: '⚠️ الاستخدام: .طرد @عضو أو الرد على رسالته.',
      }, { quoted: msg });
    }

    // منع طرد البوت نفسه
    const botNumber = sock.user.id.split(':')[0] + '@s.whatsapp.net';
    if (targetJid === botNumber) {
      return sock.sendMessage(groupId, {
        text: '❌ لا يمكنني طرد نفسي يا ذكي 😎',
      }, { quoted: msg });
    }

    // محاولة جلب صورة البروفايل
    let pfp;
    try {
      pfp = await sock.profilePictureUrl(targetJid, 'image');
    } catch {
      pfp = null;
    }

    const number = targetJid.split('@')[0];
    const goodbyeText = `
⸻⸻⸻ ⌁ 𖤐 𝗘𝗡𝗗 𝗢𝗙 𝗧𝗛𝗘 𝗥𝗢𝗔𝗗 𖤐 ⌁ ⸻⸻⸻

🧨 *𝗨𝗦𝗘𝗥: @${number}ِ*
🚷 *𝗦𝗧𝗔𝗧𝗨𝗦: 𝗘𝗫𝗜𝗧𝗘𝗗*
👣 *𝗠𝗘𝗦𝗦𝗔𝗚𝗘:*  
*خلاص الرحلة خلصت، نتمناك التوفيق في عالم آخر...*  
*مع السلامة يا صديق، كانت الإقامة قصيرة، لكنها محفورة 🖤*

──────────────
`;

    const messageData = {
      mentions: [targetJid],
    };

    if (pfp) {
      messageData.image = { url: pfp };
      messageData.caption = goodbyeText;
    } else {
      messageData.text = goodbyeText;
    }

    try {
      await sock.sendMessage(groupId, messageData, { quoted: msg });

      setTimeout(async () => {
        await sock.groupParticipantsUpdate(groupId, [targetJid], 'remove');
      }, 2000);
    } catch (err) {
      console.error("فشل في تنفيذ أمر الطرد:", err);
      await sock.sendMessage(groupId, {
        text: '❌ حدث خطأ أثناء محاولة الطرد.',
      }, { quoted: msg });
    }
  }
};