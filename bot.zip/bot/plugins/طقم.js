// • Feature : جلب صور تطقيم أولاد عشوائية 
// • Developers : ARCEN Team

module.exports = {
  command: ['طقم'],
  description: 'جلب صور تطقيم أولاد متناسقة (Matching Icons) بشكل عشوائي.',
  category: 'fun',

  async execute(sock, message, args) {
    const from = message.key.remoteJid;

    try {
      // إرسال تفاعل الانتظار لبدء معالجة الصور
      await sock.sendMessage(from, { react: { text: '⏳', key: message.key } });

      // جلب بيانات التطقيم من المستودع
      const response = await fetch('https://raw.githubusercontent.com/Afghhjjkoo/GURU-BOT/main/lib/5%D8%AA%D8%B7%D9%82%D9%8A%D9%85.json');
      if (!response.ok) throw new Error(`فشل جلب البيانات من المصدر: ${response.status}`);
      
      const data = await response.json();
      
      // اختيار طقم عشوائي من المصفوفة
      const randomPair = data[Math.floor(Math.random() * data.length)];
      
      // جلب بافر الصورة الأولى والثانية
      const resCowo = await fetch(randomPair.cowo);
      const bufferCowo = Buffer.from(await resCowo.arrayBuffer());

      const resCiwi = await fetch(randomPair.cewe);
      const bufferCiwi = Buffer.from(await resCiwi.arrayBuffer());

      // إرسال الصورة الأولى (الولد الأول)
      await sock.sendMessage(from, {
        image: bufferCowo,
        caption: '*الولد الأول 🧑🏻*'
      }, { quoted: message });

      // إرسال الصورة الثانية (الولد الثاني)
      await sock.sendMessage(from, {
        image: bufferCiwi,
        caption: '*الولد الثاني 🧑🏼*'
      }, { quoted: message });

      // إرسال تفاعل النجاح
      await sock.sendMessage(from, { react: { text: '✅', key: message.key } });

    } catch (e) {
      console.error(e);
      await sock.sendMessage(from, { react: { text: '❌', key: message.key } });
      await sock.sendMessage(from, { text: '❌ حدث خطأ أثناء جلب صور التطقيم، يرجى المحاولة لاحقاً.' }, { quoted: message });
    }
  }
};