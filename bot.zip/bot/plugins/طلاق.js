const fs = require('fs');
const path = require('path');

const dbDir = path.join(process.cwd(), 'db');
const dbFile = path.join(dbDir, 'marriages.json');

if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });
if (!fs.existsSync(dbFile)) fs.writeFileSync(dbFile, '{}');

function loadMarriages() {
    try { return JSON.parse(fs.readFileSync(dbFile, 'utf8')); } catch { return {}; }
}

function saveMarriages(data) {
    fs.writeFileSync(dbFile, JSON.stringify(data, null, 2));
}

module.exports = {
    command: ['طلاق'],
    category: 'fun',
    description: 'إنهاء الزواج تلقائياً داخل الجروب الحالي',
    usage: '.طلاق',

    async execute(sock, msg, args = []) {
        const sender = msg.key.participant || msg.key.remoteJid || '';
        const chatId = msg.key.remoteJid;

        const allMarriages = loadMarriages();
        const currentGroupMarriages = allMarriages[chatId] || {};

        // 🔍 فحص إذا كان الشخص متزوجاً في هذا الجروب تحديداً
        if (!currentGroupMarriages[sender]) {
            return await sock.sendMessage(chatId, {
                text: 'انت لست متزوجاً اكتب .زوجني لتتزوج ❌️',
            }, { quoted: msg });
        }

        // جلب معرف الشريك تلقائياً من سجل الجروب
        let target = currentGroupMarriages[sender][1];

        // ميزة إضافية: التحقق إذا قام العضو بعمل منشن أو رد لشخص بالخطأ وهو ليس شريكه في هذا الجروب
        const contextInfo = msg.message?.extendedTextMessage?.contextInfo || {};
        const mentionedJid = contextInfo.mentionedJid || [];
        const quotedParticipant = contextInfo.participant;
        const inputTarget = mentionedJid[0] || quotedParticipant;

        if (inputTarget && inputTarget !== target) {
            return await sock.sendMessage(chatId, {
                text: `❌ أنت غير متزوج من هذا الشخص في هذا الجروب! شريكك الحالي هنا هو: @${target.split('@')[0]}`,
                mentions: [target]
            }, { quoted: msg });
        }

        if (target === sender) {
            return await sock.sendMessage(chatId, {
                text: '🤦‍♂️ لا يمكنك تطليق نفسك.',
            }, { quoted: msg });
        }

        // حذف سجل الزواج للطرفين من هذا الجروب فقط
        delete currentGroupMarriages[sender];
        delete currentGroupMarriages[target];
        
        allMarriages[chatId] = currentGroupMarriages;
        saveMarriages(allMarriages);

        const text = `
💔 تم الطلاق بنجاح 💔

👰 الزوجه: @${target.split('@')[0]}ِ
🤵 الزوج: @${sender.split('@')[0]}ِ

نتمنى لكم حياة جديدة مليئة بالخير والسلام. ✨
𝗔𝗥𝗖𝗘𝗡
        `.trim();

        await sock.sendMessage(chatId, {
            text,
            mentions: [sender, target]
        }, { quoted: msg });
    }
};