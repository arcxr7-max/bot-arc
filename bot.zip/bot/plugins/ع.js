const config = require('../config');
module.exports = {
    name: 'تصويت',
    command: ['ع'],
    category: 'fun',
    async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
                const from = msg.key.remoteJid;
        const sender = msg.key.participant || from;
        try {
            let ppUrl = await sock.profilePictureUrl(sender, 'image').catch(() => 'https://qu.ax/x/yfxdM.jpg');
            const voteMsg = await sock.sendMessage(from, { 
                image: { url: ppUrl }, 
                caption: `📊 *تـقـيـيـم صـورة:* @${sender.split('@')[0]}\n\nصوّت الآن بالتفاعل على الصورة!`,
                mentions: [sender]
            }, { quoted: msg });

            await sock.sendMessage(from, { react: { text: "❣️",  key: voteMsg.key } });
        } catch (e) { sock.sendMessage(from, { text: "❌ فشل جلب الصورة" }); }
    }
};