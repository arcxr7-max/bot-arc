const words = [
  { "word": "ليل", "reverse": "نهار" },
  { "word": "يابس", "reverse": "رطب" },
  { "word": "مؤمن", "reverse": "كافر" },
  { "word": "حق", "reverse": "باطل" },
  { "word": "حار", "reverse": "بارد" },
  { "word": "طويل", "reverse": "قصير" },
  { "word": "سعيد", "reverse": "حزين" },
  { "word": "غني", "reverse": "فقير" },
  { "word": "قوي", "reverse": "ضعيف" },
  { "word": "سريع", "reverse": "بطيء" },
  { "word": "نظيف", "reverse": "وسخ" },
  { "word": "حديث", "reverse": "قديم" },
  { "word": "الحياة", "reverse": "الموت" },
  { "word": "الحب", "reverse": "الكراهية" },
  { "word": "السلام", "reverse": "الحرب" },
  { "word": "النور", "reverse": "الظلام" },
  { "word": "السماء", "reverse": "الأرض" },
  { "word": "الفرح", "reverse": "الحزن" },
  { "word": "الصحة", "reverse": "المرض" },
  { "word": "النجاح", "reverse": "الفشل" },
  { "word": "الأمان", "reverse": "الخوف" },
  { "word": "الصدق", "reverse": "الكذب" },
  { "word": "العدل", "reverse": "الظلم" },
  { "word": "الرحمة", "reverse": "القسوة" },
  { "word": "العلم", "reverse": "الجهل" },
  { "word": "القمة", "reverse": "القاع" },
  { "word": "الأول", "reverse": "الأخير" },
  { "word": "الداخل", "reverse": "الخارج" },
  { "word": "الأعلى", "reverse": "الأدنى" },
  { "word": "الشروق", "reverse": "الغروب" },
  { "word": "الولادة", "reverse": "الوفاة" },
  { "word": "البناء", "reverse": "الهدم" },
  { "word": "الاتحاد", "reverse": "الفرقة" },
  { "word": "العز", "reverse": "الذل" },
  { "word": "الأمل", "reverse": "اليأس" },
  { "word": "الرضا", "reverse": "السخط" },
  { "word": "التواضع", "reverse": "الكبر" },
  { "word": "الحلم", "reverse": "الواقع" },
  { "word": "الحرية", "reverse": "العبودية" },
  { "word": "اليقين", "reverse": "الشك" },
  { "word": "الشفاء", "reverse": "الداء" },
  { "word": "القبول", "reverse": "الرفض" },
  { "word": "الطاعة", "reverse": "العصيان" },
  { "word": "الذكرى", "reverse": "النسيان" },
  { "word": "الاستقامة", "reverse": "الانحراف" },
  { "word": "الغضب", "reverse": "الهدوء" },
  { "word": "الجمال", "reverse": "القبح" },
  { "word": "الذكاء", "reverse": "الغباء" },
  { "word": "الشجاعة", "reverse": "الجبن" },
  { "word": "الكرم", "reverse": "البخل" },
  { "word": "الصبر", "reverse": "الجزع" },
  { "word": "الوفاء", "reverse": "الخيانة" },
  { "word": "النظام", "reverse": "الفوضى" },
  { "word": "الغنى", "reverse": "الفقر" },
  { "word": "الرخاء", "reverse": "الشدة" },
  { "word": "اليُسر", "reverse": "العسر" },
  { "word": "القريب", "reverse": "البعيد" },
  { "word": "الحاضر", "reverse": "الغائب" },
  { "word": "المعروف", "reverse": "المنكر" },
  { "word": "الحلال", "reverse": "الحرام" },
  { "word": "الطيب", "reverse": "الخبيث" },
  { "word": "الجماعة", "reverse": "الفرقة" },
  { "word": "الوضوح", "reverse": "الغموض" },
  { "word": "الصعود", "reverse": "النزول" },
  { "word": "الدخول", "reverse": "الخروج" },
  { "word": "الانتصار", "reverse": "الهزيمة" },
  { "word": "الذكر", "reverse": "الأنثى" },
  { "word": "الشباب", "reverse": "الشيخوخة" },
  { "word": "البداية", "reverse": "النهاية" },
  { "word": "الشرق", "reverse": "الغرب" },
  { "word": "الشمال", "reverse": "الجنوب" },
  { "word": "الحلاوة", "reverse": "المرارة" },
  { "word": "النوم", "reverse": "اليقظة" },
  { "word": "الصحو", "reverse": "السكر" },
  { "word": "الحضارة", "reverse": "البداوة" },
  { "word": "المدينة", "reverse": "القرية" },
  { "word": "النفط", "reverse": "الماء" },
  { "word": "النار", "reverse": "الثلج" },
  { "word": "الذهب", "reverse": "التراب" },
  { "word": "الفضة", "reverse": "الحديد" },
  { "word": "القمر", "reverse": "الشمس" },
  { "word": "الكوكب", "reverse": "النجم" },
  { "word": "المحيط", "reverse": "اليابسة" },
  { "word": "النهر", "reverse": "البحر" },
  { "word": "الجبل", "reverse": "السهل" },
  { "word": "الصخر", "reverse": "الرمال" },
  { "word": "المطر", "reverse": "الجفاف" },
  { "word": "الريح", "reverse": "السكون" },
  { "word": "العاصفة", "reverse": "الهدوء" },
  { "word": "البرق", "reverse": "الرعد" },
  { "word": "الضباب", "reverse": "الصحو" },
  { "word": "الغبار", "reverse": "النقاء" }
];

module.exports = {
    command: 'عكس',
    description: '🎮 لعبة المفرد وعكسه (نقاط)',
    category: 'game',

    async execute(sock, msg) {

                const from = msg.key.remoteJid;

        if (!global.gameReverse) global.gameReverse = {};

        if (global.gameReverse[from]) {
            return sock.sendMessage(from, { text: '❌ هناك لعبة جارية بالفعل!' }, { quoted: msg });
        }

        // تم تصحيح اسم المصفوفة هنا من wordsList إلى words
        const item = words[Math.floor(Math.random() * words.length)];

        const timer = setTimeout(() => {
            if (global.gameReverse[from]) {
                sock.sendMessage(from, { text: `⏰ *انتهى الوقت!*\n\n❁ الكلمة كانت: *${item.word}*\n❁ عكسها هو: *${item.reverse}*` });
                delete global.gameReverse[from];
            }
        }, 30000);

        global.gameReverse[from] = {
            word: item.word,
            reverse: item.reverse,
            timer: timer
        };

        const gameText = `*🎮 لـعـبـة عَـكـس*\n\n❓ ما هو عكس كلمة: *${item.word}*؟\n\n💡 أجب بالكلمة مباشرة بدون نقطة.\n\n*𝗔𝗥𝗖𝗘𝗡*`;

        await sock.sendMessage(from, { text: gameText }, { quoted: msg });
    }
};