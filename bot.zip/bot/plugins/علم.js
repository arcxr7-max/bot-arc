const fetch = require('node-fetch');
const fs = require('fs');
const path = require('path');

// مسار ملف النقاط الخاص ببوتك
const pointsFile = path.join(__dirname, '../data/points.json');

if (!global.gameFlag) global.gameFlag = {};

module.exports = {
  command: 'علم',
  description: '🌍 لعبة خمن الدولة من صورة العلم لربح النقاط',
  category: 'game',

  async execute(sock, msg) {

            const chatId = msg.key.remoteJid;

    // منع بدء لعبة جديدة إذا كانت هناك جولة قائمة
    if (global.gameFlag[chatId]) {
      return sock.sendMessage(chatId, { 
        text: "🚫 هناك جولة قائمة بالفعل! جاوب على العلم الحالي أولاً." 
      }, { quoted: msg });
    }

    try {
      // جلب البيانات من الرابط الخارجي (الرابط اللي أنت أعطيته لي)
      const res = await fetch("https://raw.githubusercontent.com/arcxr7-max/ARC/refs/heads/main/flag.json");
      const data = await res.json();
      const country = data[Math.floor(Math.random() * data.length)];

      const caption = `╭─❒ 『 *🏴 خمن العَلَم* 』 ❒─╮\n\n❁ *الجائزة:* ⟶ 💰 500 نقاط\n❁ *الوقت:* ⟶ 30 ثانية\n\n*⟬✨ أسرع واحد يكتب اسم الدولة يربح! ✨⟭*\n\n╰─⟡ 𝗔𝗥𝗖𝗘𝗡 ⦿`;

      const sentMsg = await sock.sendMessage(chatId, { 
        image: { url: country.img }, 
        caption 
      }, { quoted: msg });

      global.gameFlag[chatId] = {
        answer: country.name.toLowerCase().trim(),
        img: country.img,
        msgId: sentMsg.key.id,
        timeout: setTimeout(async () => {
          if (global.gameFlag[chatId]) {
            const answer = global.gameFlag[chatId].answer;
            delete global.gameFlag[chatId];
            await sock.sendMessage(chatId, { text: `⌛ انتهى الوقت! الإجابة الصحيحة كانت: *${answer}*` });
          }
        }, 30000)
      };

    } catch (e) {
      console.error(e);
      await sock.sendMessage(chatId, { text: "❌ حدث خطأ أثناء جلب العلم، حاول مرة أخرى." });
    }
  }
};