module.exports = {
    status: "on",
    name: 'Calculate Age',
    command: ['عمر'],
    category: 'fun',
    description: 'يحسب العمر بدقة بالسنوات والأشهر والأيام بناءً على تاريخ الميلاد',
    usage: '.عمر',
    hidden: false,

    async execute(sock, msg) {
        try {
            const chatId = msg.key.remoteJid;
            const body = msg.message?.extendedTextMessage?.text || msg.message?.conversation || '';
            const args = body.trim().split(/\s+/).slice(1);
            const inputDate = args[0];

            // التحقق من إدخال التاريخ
            if (!inputDate) {
                return sock.sendMessage(chatId, { 
                    text: '❌ يرجى إدخال تاريخ الميلاد بالشكل الصحيح.\nمثال: .عمر 2000/5/15 أو .عمر 1995-12-30' 
                }, { quoted: msg });
            }

            // توحيد الفواصل لتكون متوافقة مع نظام التواريخ
            const formattedDate = inputDate.replace(/\//g, '-');
            const birthDate = new Date(formattedDate);

            // التحقق من صحة التاريخ المدخل برمجياً
            if (isNaN(birthDate.getTime())) {
                return sock.sendMessage(chatId, { 
                    text: '❌ التاريخ غير صحيح! يرجى استخدام الصيغة: السنة/الشهر/اليوم\nمثال: 2002/8/24' 
                }, { quoted: msg });
            }

            const today = new Date();

            // منع إدخال تاريخ في المستقبل
            if (birthDate > today) {
                return sock.sendMessage(chatId, { text: '⚠️ هل أنت قادم من المستقبل؟ يرجى إدخال تاريخ ميلاد صحيح!' }, { quoted: msg });
            }

            // حساب الفروقات الزمنية بدقة
            let years = today.getFullYear() - birthDate.getFullYear();
            let months = today.getMonth() - birthDate.getMonth();
            let days = today.getDate() - birthDate.getDate();

            if (days < 0) {
                const lastMonth = new Date(today.getFullYear(), today.getMonth(), 0);
                days += lastMonth.getDate();
                months--;
            }

            if (months < 0) {
                months += 12;
                years--;
            }

            // تنسيق رسالة النتيجة الفخمة
            const ageText = `📅 ┋ حـسـاب الـعـمـر الـدقـيـق:

◦ 🎂 تاريخ الميلاد: ${inputDate}
◦ ⏳ العمر الآن: ${years} سنة و ${months} شهر و ${days} يوم.

مبارك لك ما مضى من عمرك، وجعل الله أيامك القادمة مليئة بالخير والبركة!`;

            await sock.sendMessage(chatId, { text: ageText }, { quoted: msg });

        } catch (error) {
            console.error('❌ Error in age command:', error);
            await sock.sendMessage(msg.key.remoteJid, { text: '❌ حدث خطأ داخلي أثناء حساب العمر.' }, { quoted: msg });
        }
    }
};