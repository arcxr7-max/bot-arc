const fetch = require('node-fetch');
const fs = require('fs');
const path = require('path');

// مسار ملف النقاط الخاص ببوتك
const pointsFile = path.join(__dirname, '../data/points.json');

// قائمة الأسماء العشوائية للخيارات الخاطئة
const NAMES = [
  "ايرين","نيزوكو","سوكونا","موازن","كيلوا","غون","ايتاتشي","ساسكي","دابي","اوبيتو",
  "نوبارا","ليفاي","يوتا","فريدا","شيده","ياماتو","نامي","ايمو","انيا","جينبي",
  "بوروتو","شانكس","لاو","لوفي","زورو","اكازا","ميكاسا","رين","دوما","كانيكي",
  "غوجو","ساي","نيجي","انمي","ساكورا","اوريتشمارو","ماهيتو","جيرايا","روبين",
  "سانجي","ميهوك","كايدو","مايكي","كورابيكا","شيغاراكي","تينغن","تانجيرو",
  "ميدوريا","كونان","الكيورا","شوتو","غاتارو","بارو","غارة","باكوغو","ماكيما",
  "توجا","باين","كوراما"
];

const shuffle = (arr) => arr.sort(() => Math.random() - 0.5);

if (!global.gameEye) global.gameEye = {};

module.exports = {
  command: 'عين',
  description: '👁 لعبة خمن الشخصية (جولة واحدة)',
  category: 'game',

  async execute(sock, msg) {

            const chatId = msg.key.remoteJid;
    
    // إذا كانت هناك جولة قائمة فعلاً، لا تبدأ جولة جديدة
    if (global.gameEye[chatId]?.current) {
        const g = global.gameEye[chatId].current;
        return await sock.sendMessage(chatId, { image: { url: g.img }, caption: g.caption });
    }

    try {
      // استخدام رابط الـ Raw الخاص بك من GitHub
      const response = await fetch("https://raw.githubusercontent.com/arcxr7-max/ARC/refs/heads/main/eye.json");
      const data = await response.json();
      const char = data[Math.floor(Math.random() * data.length)];

      const wrong = shuffle([...NAMES]).filter(n => n !== char.name).slice(0, 3);
      const opts = shuffle([char.name, ...wrong]);

      const caption = `╭─❒ 『 *👁 خمن عين الأنمي* 』 ❒─╮\n\n❁ *الجائزة:* ⟶ 💰 500 نقاط\n\n1. ${opts[0]}\n2. ${opts[1]}\n3. ${opts[2]}\n4. ${opts[3]}\n\n*⟬✨ أسرع واحد يكتب الحل يربح! ✨⟭*\n\n╰─⟡ 𝗔𝗥𝗖𝗘𝗡 ⦿`;

      const sentMsg = await sock.sendMessage(chatId, { image: { url: char.img }, caption });

      global.gameEye[chatId] = {
        current: {
          answer: char.name.toLowerCase(),
          opts: opts.map(o => o.toLowerCase()),
          img: char.img,
          caption,
          id: sentMsg.key.id,
          timer: setTimeout(async () => {
            if (global.gameEye[chatId]?.current) {
              const ans = global.gameEye[chatId].current.answer;
              delete global.gameEye[chatId]; // مسح الحالة عند انتهاء الوقت
              await sock.sendMessage(chatId, { text: `⌛ انتهى الوقت! الإجابة كانت: *${ans}*` });
            }
          }, 30000)
        }
      };
    } catch (e) {
      console.error(e);
      await sock.sendMessage(chatId, { text: "❌ فشل في جلب البيانات من الرابط." });
    }
  }
};