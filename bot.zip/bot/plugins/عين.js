const axios = require('axios');
const fs = require('fs');
const path = require('path');

const pointsFile = path.join(__dirname, '../data/points.json');

const NAMES = [
  "ايرين","نيزوكو","سوكونا","موازن","كيلوا","غون","ايتاتشي","ساسكي","دابي","اوبيتو",
  "نوبارا","ليفاي","يوتا","فريدا","شيده","ياماتو","نامي","ايمو","انيا","جينبي",
  "بوروتو","شانكس","لاو","لوفي","زورو","اكازا","ميكاسا","رين","دوما","كانيكي",
  "غوجو","ساي","نيجي","انمي","ساكورا","اوريتشمارو","ماهيتو","جيرايا","روبين",
  "سانجي","ميهوك","كايدو","مايكي","كورابيكا","شيغاراكي","تينغن","تانجيرو",
  "ميدوريا","كونان","الكيورا","شوتو","غاتارو","بارو","غارة","باكوغو","ماكيما",
  "توجا","باين","كوراما"
];

const shuffle = (arr) => arr.sort(() => Math.random() - 0.5);

if (!global.gameEye) global.gameEye = {};

module.exports = {
  command: 'عين',
  description: '👁 لعبة خمن الشخصية (جولة واحدة)',
  category: 'game',

  async execute(sock, msg) {
    const chatId = msg.key.remoteJid;
    
    if (global.gameEye[chatId]?.current) {
      const g = global.gameEye[chatId].current;
      return await sock.sendMessage(chatId, { image: { url: g.img }, caption: g.caption });
    }

    try {
      // ✅ استخدام axios بدل fetch
      const response = await axios.get("https://raw.githubusercontent.com/arcxr7-max/ARC/refs/heads/main/eye.json", {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Android 14; Mobile; rv:125.0) Gecko/125.0 Firefox/125.0'
        },
        timeout: 10000
      });

      const data = response.data;

      if (!Array.isArray(data) || data.length === 0) {
        throw new Error('البيانات فارغة أو غير صحيحة');
      }

      const char = data[Math.floor(Math.random() * data.length)];

      if (!char.name || !char.img) {
        throw new Error('بيانات الشخصية ناقصة');
      }

      const wrong = shuffle([...NAMES]).filter(n => n !== char.name).slice(0, 3);
      const opts = shuffle([char.name, ...wrong]);

      const caption = `╭─❒ 『 *👁 خمن عين الأنمي* 』 ❒─╮\n\n❁ *الجائزة:* ⟶ 💰 500 نقاط\n\n1. ${opts[0]}\n2. ${opts[1]}\n3. ${opts[2]}\n4. ${opts[3]}\n\n*⟬✨ أسرع واحد يكتب الحل يربح! ✨⟭*\n\n╰─⟡ 𝗔𝗥𝗖𝗘𝗡 ⦿`;

      const sentMsg = await sock.sendMessage(chatId, { image: { url: char.img }, caption });

      global.gameEye[chatId] = {
        current: {
          answer: char.name.toLowerCase(),
          opts: opts.map(o => o.toLowerCase()),
          img: char.img,
          caption,
          id: sentMsg.key.id,
          timer: setTimeout(async () => {
            if (global.gameEye[chatId]?.current) {
              const ans = global.gameEye[chatId].current.answer;
              delete global.gameEye[chatId];
              await sock.sendMessage(chatId, { text: `⌛ انتهى الوقت! الإجابة كانت: *${ans}*` });
            }
          }, 30000)
        }
      };

    } catch (e) {
      console.error('❌ خطأ في عين:', e.message);
      await sock.sendMessage(chatId, { 
        text: `❌ فشل في جلب البيانات: ${e.message}` 
      });
    }
  }
};