const config = require('../config');
module.exports = {
    command: 'تجاوز',
    description: 'تفعيل أو إلغاء تجاوز النخبة بكلمة سر (للمطور فقط)',
    hidden: true,
    onlyDev: true,
    category: 'dev',

    async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
                const sender = msg.senderNumber;
        const allowedDev = '201028489465'; // رقمك فقط

        if (sender !== allowedDev) return;

        const parts = msg.body.trim().split(" ");
        const password = parts[1];

        const secretKey = 'OARCO'; // ✴️ غيّرها لو حبيت

        if (password !== secretKey) {
            return sock.sendMessage(msg.key.remoteJid, {
                text: '🚫 كلمة السر غير صحيحة. حاول مرة أخرى.'
            }, { quoted: msg });
        }

        global.disableEliteCheck = !global.disableEliteCheck;

        const status = global.disableEliteCheck ? '🟢 تم تفعيل وضع التجاوز.\nيمكنك الآن استخدام أوامر النخبة.' : '🔴 تم إلغاء وضع التجاوز.\nالتحقق من النخبة مفعل الآن.';

        await sock.sendMessage(msg.key.remoteJid, {
            text: `*🔐 تجاوز النخبة:*\n${status}`
        }, { quoted: msg });
    }
};