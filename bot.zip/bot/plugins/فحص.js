const config = require('../config');
// plugins/فحص.js
module.exports = {
category: 'control',
command: 'فحص',
async execute(sock, msg) {
// [ARCEN-SECURITY-START]
const senderNum = (msg.key.participant || msg.key.remoteJid).split('@')[0];
const { isDev } = require('../utils/devs');
const _fs = require('fs');
const _path = require('path');
const eliteFilePath = _path.join(process.cwd(), 'data', 'elite.json');
let eliteNumbers = [];
if (_fs.existsSync(eliteFilePath)) {
try { eliteNumbers = JSON.parse(_fs.readFileSync(eliteFilePath, 'utf-8')).eliteNumbers || []; } catch(e){}
}
// ⚠️ رسالة الحماية المثبتة والمحدثة بناءً على طلبك
if (!isDev(senderNum)) return sock.sendMessage(msg.key.remoteJid, { text: '⚠️ ┋ عذراً، هذا الأمر مخصص للمطور الأساسي فقط!' }, { quoted: msg });
// [ARCEN-SECURITY-END]

const fs = require('fs');
const path = require('path');

const backupsPath = path.join(__dirname, '..', 'backups');

if (!fs.existsSync(backupsPath)) {
return sock.sendMessage(msg.key.remoteJid, { text: '📁 مجلد backups غير موجود' }, { quoted: msg });
}

const files = fs.readdirSync(backupsPath);

let text = `📁 مجلد backups\n📊 عدد الملفات: ${files.length}\n\n`;

for (const file of files) {
const ext = path.extname(file);
const stats = fs.statSync(path.join(backupsPath, file));
const size = (stats.size / 1024).toFixed(2) + ' KB';
text += `📄 ${file}\n   └─ الامتداد: ${ext || 'بدون امتداد'} | الحجم: ${size}\n\n`;
}

await sock.sendMessage(msg.key.remoteJid, { text: text }, { quoted: msg });
}
};