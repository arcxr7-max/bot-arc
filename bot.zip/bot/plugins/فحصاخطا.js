const { isDev } = require('../utils/devs');
const fs = require('fs');
const path = require('path');

// مصفوفة مؤقتة في الذاكرة لتسجيل الأخطاء فور حدوثها أثناء تشغيل البوت
if (!global.errorLogs) {
    global.errorLogs = [];
}

// التقاط الأخطاء الكبيرة التي قد تسبب توقف البوت وحفظها في الذاكرة
process.on('uncaughtException', (err) => {
    if (global.errorLogs) {
        global.errorLogs.push({
            time: new Date().toLocaleTimeString(),
            message: err.message,
            stack: err.stack ? err.stack.split('\n').slice(0, 3).join('\n') : 'لا يوجد تفاصيل للسطر'
        });
        if (global.errorLogs.length > 15) global.errorLogs.shift(); // الاحتفاظ بآخر 15 خطأ فقط
    }
});

module.exports = {
category: 'control',
command: ['اخطاء'],
description: '📊 فحص سجل أخطاء السيرفر والـ Terminal الداخلية للبوت.',
usage: '.اخطاء',

async execute(sock, msg) {
const chatId = msg.key.remoteJid;
const senderNum = (msg.key.participant || msg.key.remoteJid).split('@')[0];

// 🛡️ جدار الحماية للمطور الأساسي فقط
if (!isDev(senderNum)) {
return sock.sendMessage(chatId, { text: '⚠️ ┋ عذراً، هذا الأمر مخصص للمطور الأساسي فقط!' }, { quoted: msg });
}

await sock.sendMessage(chatId, { react: { text: '🔍', key: msg.key } });

if (!global.errorLogs || global.errorLogs.length === 0) {
    return sock.sendMessage(chatId, {
        text: '✅ <b>تقرير فحص النظام:</b>\n\nالـ Terminal مستقرة تماماً ولا توجد أي أخطاء برمجية مسجلة حالياً في الخلفية.'
    }, { quoted: msg });
}

let report = `📊 <b>تقرير فحص أخطاء الـ Terminal والنظام:</b>\n`;
report += `⚠️ تم رصد عدد ( ${global.errorLogs.length} ) أخطاء مؤخراً:\n\n`;

global.errorLogs.forEach((err, index) => {
    report += `<b>[${index + 1}] 🕒 الوقت: ${err.time}</b>\n`;
    report += `❌ <b>الخطأ:</b> <code>${err.message}</code>\n`;
    report += `📍 <b>مكان الخطأ:</b>\n<code>${err.stack}</code>\n`;
    report += `──────────────────\n`;
});

await sock.sendMessage(chatId, { text: report }, { quoted: msg });
}
};