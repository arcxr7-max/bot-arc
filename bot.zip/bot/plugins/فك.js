const config = require('../config');
const fs = require('fs');
const path = require('path');

const guildsFile = path.join(__dirname, '../data/guilds.json');

function loadGuilds() {
  if (!fs.existsSync(guildsFile)) return {};
  return JSON.parse(fs.readFileSync(guildsFile, 'utf8'));
}

function saveGuilds(data) {
  fs.writeFileSync(guildsFile, JSON.stringify(data, null, 2));
}

module.exports = {
  category: 'group',
  command: 'فك',
  description: '🔓 فك ربط وحذف النقابة بالكامل من المجموعات',
  usage: '.فك',

  async execute(sock, msg) {
        // [ARCEN-SECURITY-START]
const senderNum = (msg.key.participant || msg.key.remoteJid).split('@')[0];
const { isDev } = require('../utils/devs');
const _fs = require('fs');
const _path = require('path');
const eliteFilePath = _path.join(process.cwd(), 'data', 'elite.json');
let eliteNumbers = [];
if (_fs.existsSync(eliteFilePath)) {
try { eliteNumbers = JSON.parse(_fs.readFileSync(eliteFilePath, 'utf-8')).eliteNumbers || []; } catch(e){}
}
const groupMetadata = msg.key.remoteJid.endsWith('@g.us') ? await sock.groupMetadata(msg.key.remoteJid) : null;
const isAdmin = groupMetadata ? groupMetadata.participants.find(p => p.id.split('@')[0] === senderNum)?.admin : false;
if (!isDev(senderNum) && !eliteNumbers.includes(senderNum) && !isAdmin) return sock.sendMessage(msg.key.remoteJid, { text: '🛡️ ┋ هذا الأمر يتطلب صلاحيات المشرفين أو المطور أو النخبة!' }, { quoted: msg });
        // [ARCEN-SECURITY-END]
        
    const chatId = msg.key.remoteJid;
    const sender = msg.key.participant || msg.key.remoteJid;
    const senderNumber = sender.split('@')[0];

    // التأكد من أن الأمر يتم تنفيذه داخل مجموعة
    if (!chatId.endsWith('@g.us')) {
      return sock.sendMessage(chatId, { text: '❌ هذا الأمر يعمل فقط في المجموعات' }, { quoted: msg });
    }

    let guilds = loadGuilds();
    let foundGuildId = null;
    let guildData = null;

    // البحث عن النقابة المرتبطة بهذا القروب (سواء كان استقبال أو أساسي)
    for (const [id, guild] of Object.entries(guilds)) {
      if (guild.welcomeGroupId === chatId || guild.mainGroupId === chatId) {
        foundGuildId = id;
        guildData = guild;
        break;
      }
    }

    if (!foundGuildId) {
      return sock.sendMessage(chatId, { text: '❌ هذا القروب غير مرتبط بأي نقابة' }, { quoted: msg });
    }

    // حفظ معلومات القروبين قبل الحذف
    const welcomeGroup = guildData.welcomeGroupId;
    const mainGroup = guildData.mainGroupId;

    // حذف النقابة بالكامل
    delete guilds[foundGuildId];
    saveGuilds(guilds);

    let response = `✅ تم فك الربط وحذف النقابة\n\n`;
    response += `🗑️ تم حذف النقابة: ${guildData.name}\n`;

    if (welcomeGroup === chatId) {
      response += `📌 هذا القروب كان قروب الاستقبال\n`;
    }
    if (mainGroup === chatId) {
      response += `📌 هذا القروب كان القروب الأساسي\n`;
    }
    if (welcomeGroup && welcomeGroup !== chatId) {
      response += `\n⚠️ قروب الاستقبال (${guildData.welcomeGroupName || 'المسمى غير متاح'}) تم فكه أيضاً\n`;
    }
    if (mainGroup && mainGroup !== chatId) {
      response += `⚠️ القروب الأساسي (${guildData.mainGroupName || 'المسمى غير متاح'}) تم فكه أيضاً\n`;
    }

    response += `\n📌 يمكنك الآن إنشاء نقابة جديدة باستخدام .نقابة`;

    await sock.sendMessage(chatId, { text: response }, { quoted: msg });
  }
};