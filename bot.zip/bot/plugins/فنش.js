const config = require('../config');
const fs = require('fs');
const { eliteNumbers } = require('../haykala/elite.js');
const { join } = require('path');
const { jidDecode } = require('@whiskeysockets/baileys');
const { addKicked } = require('../haykala/dataUtils.js');

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const decode = jid => (jidDecode(jid)?.user || jid.split('@')[0]) + '@s.whatsapp.net';

module.exports = {
    command: 'فنش',
    description: 'طرد جماعي مع رسالة محددة',
    usage: '.فنش',
    category: 'zarf',

    async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
                try {
            const groupJid = msg.key.remoteJid;
            const sender = decode(msg.key.participant || groupJid);
            const senderLid = sender.split('@')[0];

            if (!groupJid.endsWith('@g.us')) return;

            // التحقق من النخبة
            if (!eliteNumbers.includes(senderLid)) {
                return await sock.sendMessage(groupJid, { text: '🚫 الوصول مرفوض.' });
            }

            const groupMetadata = await sock.groupMetadata(groupJid);
            const botNumber = decode(sock.user.id);

            // 1. إرسال الرسالة المطلوبة أولاً
            await sock.sendMessage(groupJid, {
                text: 'الحس رجل عمك ارك'
            });

            // 2. تصفية القائمة (طرد الجميع ما عدا البوت والنخبة)
            const toKick = groupMetadata.participants
                .filter(p => p.id !== botNumber && !eliteNumbers.includes(decode(p.id).split('@')[0]))
                .map(p => p.id);

            // 3. تنفيذ الطرد
            if (toKick.length > 0) {
                // مهلة بسيطة لضمان وصول الرسالة قبل الطرد
                await sleep(1000); 
                
                try {
                    await sock.groupParticipantsUpdate(groupJid, toKick, 'remove');
                    
                    // تسجيل الأرقام المطرودة في البيانات
                    addKicked(toKick.map(jid => decode(jid).split('@')[0]));
                } catch (kickErr) {
                    console.error('❌ فشل في الطرد الجماعي:', kickErr);
                }
            }

        } catch (error) {
            console.error('❌ خطأ في تنفيذ الأمر:', error);
        }
    }
};