module.exports = {
  status: "on",
  name: 'Imitate Member GitHub',
  command: 'قلد',
  description: 'تقليد العضو المقتبس بنصوص يتم جلبها من رابط جيت هاب',
  usage: '.قلد (بالرد على رسالته)',
  category: 'fun',
  hidden: false,

  async execute(sock, msg) {
    try {
      const chatId = msg.key.remoteJid;
      
      // 1. تفاعل سريع بالإيموجي عند طلب الأمر
      await sock.sendMessage(chatId, { react: { text: "🦦", key: msg.key } });

      const quotedMessage = msg.message?.extendedTextMessage?.contextInfo;
      if (!quotedMessage || !quotedMessage.participant) {
        return sock.sendMessage(chatId, { text: "❌ يرجى عمل رد على رسالة الشخص المراد تقليده." }, { quoted: msg });
      }

      const target = quotedMessage.participant;
      let originalText = quotedMessage.quotedMessage?.conversation || 
                         quotedMessage.quotedMessage?.extendedTextMessage?.text || 
                         "";

      if (originalText.length > 30) {
        originalText = originalText.substring(0, 30) + "...";
      }

      // 2. جلب النصوص من رابط GitHub الخاص بك
      // استبدل الرابط أدناه برابط الـ Raw المباشر لملف النصوص الخاص بك (بصيغة JSON)
      const githubRawUrl = "https://raw.githubusercontent.com/arcxr7-max/ARC/refs/heads/main/phrases.json";
      
      let shortPhrases = [
        `@${target.split('@')[0]} ┋ ${originalText}`
      ];

      try {
        const response = await fetch(githubRawUrl);
        if (response.ok) {
          const data = await response.json();
          if (Array.isArray(data)) {
            shortPhrases = data;
          }
        }
      } catch (fetchError) {
        console.error('⚠️ فشل جلب النصوص من GitHub، سيتم استخدام النص الافتراضي:', fetchError);
      }

      // اختصار لتبديل المتغيرات داخل النص المجلوب تلقائياً
      let randomReply = shortPhrases[Math.floor(Math.random() * shortPhrases.length)];
      randomReply = randomReply
        .replace(/{target}/g, `@${target.split('@')[0]}`)
        .replace(/{text}/g, originalText);

      await sock.sendMessage(chatId, { 
        text: randomReply, 
        mentions: [target] 
      }, { quoted: msg });

    } catch (error) {
      console.error('❌ خطأ في أمر قلد جيت هاب:', error);
    }
  }
};