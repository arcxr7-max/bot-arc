const config = require('../config');
const fs = require('fs-extra');
const path = require('path');
const { isElite } = require('../haykala/elite');

// مسار ملف حفظ قوانين وحالة المجموعات
const rulesFile = path.join(__dirname, '../data/group_rules.json');

function loadRules() {
    if (!fs.existsSync(rulesFile)) {
        fs.ensureDirSync(path.dirname(rulesFile));
        fs.writeJsonSync(rulesFile, {});
        return {};
    }
    return fs.readJsonSync(rulesFile);
}

function saveRules(data) {
    fs.writeJsonSync(rulesFile, data, { spaces: 2 });
}

module.exports = {
    command: ['قوانين'],
    description: '📜 تعيين وعرض وقفل/فتح قوانين المجموعة حسب الرتب',
    category: 'group',

    async execute(sock, msg) {
        try {
            const from = msg.key.remoteJid;
            const senderJid = msg.key.participant || from;
            const senderNumber = senderJid.split('@')[0];

            // التحقق من أن الأمر يتم تنفيذه داخل مجموعة
            if (!from.endsWith('@g.us')) {
                return await sock.sendMessage(from, { text: '🚫 هذا الأمر يعمل فقط داخل المجموعات.' }, { quoted: msg });
            }

            // جلب النص المكتوب بعد الأمر
            const body = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
            const currentPrefix = config.prefix || '.';
            const argsText = body.slice(currentPrefix.length + 'قوانين'.length).trim();

            const allRules = loadRules();
            
            // التأكد من هيكلة البيانات للجروب الحالي
            if (!allRules[from]) {
                allRules[from] = { text: '', status: 'open' };
            }

            // جلب صلاحيات المشرفين وفحص النخبة/المطور
            const isEliteUser = await isElite(senderNumber);
            const groupMetadata = await sock.groupMetadata(from);
            const isGroupAdmin = groupMetadata.participants.find(p => p.id === senderJid)?.admin;

            // 1️⃣ [قسم قفل وفتح القوانين] - للمشرفين والمطورين والنخبة
            if (argsText === 'قفل') {
                if (!isEliteUser && !isGroupAdmin) {
                    return await sock.sendMessage(from, { text: '⚠️ ┋ عذراً، هذا الأمر مخصص للمشرفين والإدارة فقط لقفل القوانين!' }, { quoted: msg });
                }
                allRules[from].status = 'close';
                saveRules(allRules);
                return await sock.sendMessage(from, { text: '🔒 تم قفل عرض قوانين المجموعة بنجاح عن الأعضاء.' }, { quoted: msg });
            }

            if (argsText === 'فتح') {
                if (!isEliteUser && !isGroupAdmin) {
                    return await sock.sendMessage(from, { text: '⚠️ ┋ عذراً، هذا الأمر مخصص للمشرفين والإدارة فقط لفتح القوانين!' }, { quoted: msg });
                }
                allRules[from].status = 'open';
                saveRules(allRules);
                return await sock.sendMessage(from, { text: '🔓 تم فتح قوانين المجموعة، يمكن لجميع الأعضاء عرضها الآن.' }, { quoted: msg });
            }

            // 2️⃣ [قسم كتابة وتعديل النص] - للمشرفين والمطورين والنخبة فقط
            if (argsText.length > 0) {
                if (!isEliteUser && !isGroupAdmin) {
                    return await sock.sendMessage(from, { text: '⚠️ ┋ عذراً، تعديل أو إضافة القوانين مخصص فقط للمشرفين، النخبة، أو المطور!' }, { quoted: msg });
                }

                // شرط الـ 20 حرفاً للأمان
                if (argsText.length < 20) {
                    return await sock.sendMessage(from, { 
                        text: `⚠️ ┋ عذراً، يجب أن يكون نص القوانين مفصلاً (أكثر من 20 حرفاً).\n\n📝 النص الحالي طوله: *${argsText.length}* حرفاً فقط.` 
                    }, { quoted: msg });
                }

                // تحديث النص الجديد وحفظه
                allRules[from].text = argsText;
                saveRules(allRules);

                return await sock.sendMessage(from, {
                    text: '✅ *تم تحديث قوانين المجموعة بنجاح!*\n\nيمكن للأعضاء عرضها بكتابة: *.قوانين*'
                }, { quoted: msg });
            }

            // 3️⃣ [قسم عرض القوانين لوحده] - متاح للجميع (إذا كانت الحالة مفتوحة)
            if (allRules[from].status === 'close' && !isEliteUser && !isGroupAdmin) {
                return await sock.sendMessage(from, { text: '🚫 ┋ عذراً، عرض القوانين مقفل حالياً في هذه المجموعة من قبل الإدارة.' }, { quoted: msg });
            }

            const currentRulesText = allRules[from].text;

            if (!currentRulesText || currentRulesText.trim() === '') {
                return await sock.sendMessage(from, {
                    text: '📝 *لا توجد قوانين محددة لهذه المجموعة بعد.*\n\n💡 (للمشرفين والنخبة) اكتب لتحديدها:\n*.قوانين + نص القوانين الجديد*'
                }, { quoted: msg });
            }

            // عرض القوانين المعتمدة للجروب
            const rulesMessage = `
📜 *قـوانـيـن الـمـجـمـوعـة* 📜
━━━━━━━━━━━━━━━━━━━

${currentRulesText}

━━━━━━━━━━━━━━━━━━━
✨ الرجاء من الجميع الالتزام لتجنب الطرد.
`.trim();

            await sock.sendMessage(from, { text: rulesMessage }, { quoted: msg });

        } catch (error) {
            console.error('❌ خطأ في نظام صلاحيات القوانين:', error);
        }
    }
};