const fs = require('fs');
const path = require('path');

const file = path.join(__dirname, '../data/bot-ratings.json');
const devJid = '212777634520@s.whatsapp.net';

if (!fs.existsSync(file)) fs.writeFileSync(file, '[]');

module.exports = {
  command: "قيم",
  description: "🌟 قيّم البوت بإدخال رقم من 1 إلى 5 ورؤية الإحصائيات",
  usage: ".قيم [1 - 5]",

  async execute(sock, msg) {
    const from = msg.key.remoteJid;
    const sender = msg.participant || msg.key.participant || msg.key.remoteJid;
    const name = msg.pushName || "عضو";
    const args = msg.args.join(" ").trim();

    // 1. قراءة التقييمات الحالية
    let list = JSON.parse(fs.readFileSync(file));
    const previousRating = list.find(item => item.from === sender);

    // دالة لحساب وتنسيق إحصائيات المقيمين للجميع
    const getStatsText = () => {
      const totalUsers = list.length;
      if (totalUsers === 0) return "لا توجد تقييمات مسجلة حتى الآن.";

      const counts = { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 };
      let sumStars = 0;

      list.forEach(item => {
        if (counts[item.rating] !== undefined) {
          counts[item.rating]++;
        }
        sumStars += item.rating;
      });

      const average = (sumStars / totalUsers).toFixed(1);

      let breakdownText = "";
      for (let i = 5; i >= 1; i--) {
        const count = counts[i];
        const percentage = Math.round((count / totalUsers) * 100);
        const filledBars = Math.round((percentage / 100) * 8);
        const progressBar = "█".repeat(filledBars) + "░".repeat(8 - filledBars);

        breakdownText += `${i} ⭐ | ${progressBar} | ${percentage}% (${count})\n`;
      }

      return { average, totalUsers, breakdownText };
    };

    // 2. إذا لم يدخل المستخدم رقم التقييم أو أدخل رقماً خاطئاً
    const stars = parseInt(args);
    if (isNaN(stars) || stars < 1 || stars > 5) {
      const stats = getStatsText();

      // إذا كان قد قّيم سابقاً وأرسل الأمر بدون رقم، نعرض له تقييمه مع الإحصائيات
      if (previousRating) {
        const prevStarsDisplay = "⭐".repeat(previousRating.rating);
        return await sock.sendMessage(from, {
          text: `⚠️ لقد قمت بتقييم البوت سابقاً!\n\n` +
                `📅 معرّف/تاريخ التقييم: ${previousRating.date}\n` +
                `🌟 تقييمك المسجل: ${prevStarsDisplay} (${previousRating.rating} من 5)\n\n` +
                `📊 إحصائيات تقييم البوت العامة:\n` +
                `⭐ المعدل العام: ${stats.average} / 5.0\n` +
                `👥 إجمالي المقيّمين: ${stats.totalUsers} مستخدم\n\n` +
                `📈 توزيع النجوم:\n` +
                `${stats.breakdownText}\n` +
                `شكراً لتقييمك لـ 𝗔𝗥𝗖𝗘𝗡 🜲`
        }, { quoted: msg });
      }

      // إذا لم يقيم سابقاً وأرسل الأمر بدون رقم
      return await sock.sendMessage(from, {
        text: "❗ أرسل رقم لتقييم البوت من 1 إلى 5، مثال:\n`.قيم 5`"
      }, { quoted: msg });
    }

    // 3. منع التقييم المكرر عند إدخال رقم جديد
    if (previousRating) {
      const stats = getStatsText();
      const prevStarsDisplay = "⭐".repeat(previousRating.rating);
      return await sock.sendMessage(from, {
        text: `⚠️ لا يمكنك التقييم أكثر من مرة!\n\n` +
              `📅 معرّف/تاريخ التقييم: ${previousRating.date}\n` +
              `🌟 تقييمك المسجل: ${prevStarsDisplay} (${previousRating.rating} من 5)\n\n` +
              `📊 إحصائيات تقييم البوت العامة:\n` +
              `⭐ المعدل العام: ${stats.average} / 5.0\n` +
              `👥 إجمالي المقيّمين: ${stats.totalUsers} مستخدم\n\n` +
              `📈 توزيع النجوم:\n` +
              `${stats.breakdownText}\n` +
              `شكراً لتقييمك لـ 𝗔𝗥𝗖𝗘𝗡 🜲`
      }, { quoted: msg });
    }

    // 4. تسجيل تقييم جديد مع التاريخ بصيغة Timestamp الرقمية
    const starDisplay = "⭐".repeat(stars);
    const timeStampDate = Date.now().toString(); // يُخرج رقم طويل مثل 1786134154432

    const newRatingData = {
      name,
      rating: stars,
      from: sender,
      date: timeStampDate
    };

    list.push(newRatingData);
    fs.writeFileSync(file, JSON.stringify(list, null, 2));

    // 5. جلب الإحصائيات بعد الحذف/الإضافة
    const stats = getStatsText();

    // استخراج اسم الجروب إن وجد
    let groupName = '';
    if (from.endsWith('@g.us')) {
      try {
        const metadata = await sock.groupMetadata(from);
        groupName = metadata.subject || 'جروب غير معروف';
      } catch {
        groupName = 'جروب غير معروف';
      }
    }

    // 6. رسالة التأكيد والإحصائيات
    const userMessage = 
      `✨ تم تسجيل تقييمك بنجاح\n` +
      `📅 معرّف التقييم: ${timeStampDate}\n` +
      `🌟 تقييمك المقدم: ${starDisplay} (${stars} من 5)\n\n` +
      `📊 إحصائيات تقييم البوت العامة:\n` +
      `⭐ المعدل العام: ${stats.average} / 5.0\n` +
      `👥 إجمالي المقيّمين: ${stats.totalUsers} مستخدم\n\n` +
      `📈 توزيع النجوم:\n` +
      `${stats.breakdownText}\n` +
      `شكراً لتقييمك لـ 𝗔𝗥𝗖𝗘𝗡 🜲`;

    await sock.sendMessage(from, { text: userMessage }, { quoted: msg });

    // 7. إشعار للمطور
    await sock.sendMessage(devJid, {
      text: `🌟 *تقييم جديد من • ${name}*\n\n` +
            `📬 من: wa.me/${sender.split('@')[0]}\n` +
            (groupName ? `👥 الجروب: ${groupName}\n` : '') +
            `⭐ التقييم: ${stars} نجوم\n` +
            `📅 التاريخ (Timestamp): ${timeStampDate}\n` +
            `📊 المتوسط الحالي للبوت: ${stats.average} ⭐ (${stats.totalUsers} تقييم)`
    });
  }
};
