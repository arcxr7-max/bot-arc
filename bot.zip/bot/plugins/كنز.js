const fs = require('fs');
const path = require('path');

const resourcesFile = path.join(__dirname, '../data/resources.json');
const cooldownFile = path.join(__dirname, '../data/searchCooldown.json');

function loadResources() {
    if (!fs.existsSync(resourcesFile)) return {};
    return JSON.parse(fs.readFileSync(resourcesFile, 'utf8'));
}

function saveResources(data) {
    fs.writeFileSync(resourcesFile, JSON.stringify(data, null, 2));
}

function loadCooldown() {
    if (!fs.existsSync(cooldownFile)) return {};
    return JSON.parse(fs.readFileSync(cooldownFile, 'utf8'));
}

function saveCooldown(data) {
    fs.writeFileSync(cooldownFile, JSON.stringify(data, null, 2));
}

const COOLDOWN_TIME = 900000; // 15 دقيقة

function getRemainingTime(lastTime) {
    const diff = lastTime + COOLDOWN_TIME - Date.now();
    if (diff <= 0) return null;
    const minutes = Math.floor(diff / 60000);
    const seconds = Math.floor((diff % 60000) / 1000);
    return `${minutes} دقيقة ${seconds} ثانية`;
}

function getReturnTime(lastTime) {
    const returnTime = new Date(lastTime + COOLDOWN_TIME);
    const hours = returnTime.getHours().toString().padStart(2, '0');
    const minutes = returnTime.getMinutes().toString().padStart(2, '0');
    return `${hours}:${minutes}`;
}

function generateResources() {
    return {
        gold: Math.floor(Math.random() * 10) + 1,
        iron: Math.floor(Math.random() * 15) + 1,
        wood: Math.floor(Math.random() * 20) + 1,
        stone: Math.floor(Math.random() * 15) + 1
    };
}

module.exports = {
    command: 'كنز',
    description: '🏴‍☠️ ابحث عن الكنز واحصل على موارد (مرة كل 15 دقيقة)',
    usage: '.كنز',
    category: 'game',

    async execute(sock, msg) {

                const chatId = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;
        const senderNumber = sender.split('@')[0];

        let cooldown = loadCooldown();
        const lastSearch = cooldown[senderNumber] || 0;
        const remaining = getRemainingTime(lastSearch);

        if (remaining) {
            return sock.sendMessage(chatId, {
                text: `⏳ انتظر ${remaining} ثم حاول مرة أخرى`
            }, { quoted: msg });
        }

        const resources = generateResources();
        const totalItems = resources.gold + resources.iron + resources.wood + resources.stone;

        let userResources = loadResources();
        if (!userResources[senderNumber]) {
            userResources[senderNumber] = { gold: 0, iron: 0, wood: 0, stone: 0 };
        }
        
        userResources[senderNumber].gold += resources.gold;
        userResources[senderNumber].iron += resources.iron;
        userResources[senderNumber].wood += resources.wood;
        userResources[senderNumber].stone += resources.stone;
        saveResources(userResources);

        const now = Date.now();
        cooldown[senderNumber] = now;
        saveCooldown(cooldown);

        const returnTime = getReturnTime(now);

        const message = `🏴‍☠️ *عملية بحث عن الكنز* 🕵🏻‍♂️\n\n` +
            `🎁 *ربحت معانا بكج موارد* 🎁\n` +
            `📦 *العدد* ↤ *${totalItems}*\n` +
            `⚱️ *الذهب* ↤ *${resources.gold}*\n` +
            `⚙️ *الحديد* ↤ *${resources.iron}*\n` +
            `🪵 *الخشب* ↤ *${resources.wood}*\n` +
            `🧱 *الحجر* ↤ *${resources.stone}*\n\n` +
            `• للبحث عن الكنز\n• تعال بعد ↤ ${returnTime}`;

        await sock.sendMessage(chatId, { text: message }, { quoted: msg });
    }
};