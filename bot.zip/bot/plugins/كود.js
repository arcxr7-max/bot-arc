const config = require('../config');
const fs = require('fs');
const path = require('path');
const { isElite, extractPureNumber } = require('../haykala/elite');

module.exports = {
    command: 'كود',
    category: 'tools',
    description: 'يعرض محتوى ملف بلوجين كرسالة نصية نظيفة تماماً بدون نجوم التنسيق (لالنخبة فقط)',

    async execute(sock, msg, args = []) {
        try {
            const jid = msg.key.remoteJid;
            const senderJid = msg.key.participant || msg.participant || jid;
            const senderNumber = extractPureNumber(senderJid);

            if (!isElite(senderNumber)) {
                return sock.sendMessage(jid, { text: '🚫 هذا الأمر مخصص للنخبة فقط.' }, { quoted: msg });
            }

            const pluginsFolder = path.resolve(process.cwd(), 'plugins');
            const allFiles = fs.readdirSync(pluginsFolder).filter(f => f.endsWith('.js'));

            let pluginName = args.join(' ').trim();

            if (!pluginName) {
                const messageText = (msg.message?.conversation || '') || (msg.message?.extendedTextMessage?.text || '');
                const parts = messageText.trim().split(/\s+/);
                if (parts.length > 1) {
                    pluginName = parts.slice(1).join(' ').trim();
                }
            }

            if (!pluginName) {
                const list = allFiles.map(f => `⚡ ${f}`).join('\n');
                return sock.sendMessage(jid, {
                    text: `📂 قائمة البلوجينات: (${allFiles.length})\n\n${list}`
                }, { quoted: msg });
            }

            if (!pluginName.endsWith('.js')) pluginName += '.js';

            if (!allFiles.includes(pluginName)) {
                return sock.sendMessage(jid, {
                    text: `❌ البلوجين ${pluginName} غير موجود ضمن مجلد plugins.`
                }, { quoted: msg });
            }

            const filePath = path.join(pluginsFolder, pluginName);
            let code = fs.readFileSync(filePath, 'utf-8');

            // 🧼 1. تنظيف النجوم المزدوجة العادية ومسافاتها
            code = code.replace(/\*\*/g, '');

            // 🧼 2. تنظيف النجوم العشوائية التي تأتي في أول السطر أو آخره بسبب نسخ الواتساب للخط العريض
            code = code.split('\n').map(line => {
                let trimmed = line.trim();
                // إذا كان السطر يبدأ بنجمة وينتهي بنجمة (تنسيق واتساب مكسور)
                if (trimmed.startsWith('*') && trimmed.endsWith('*') && trimmed.length > 1) {
                    return trimmed.slice(1, -1);
                }
                // إزالة النجوم من الأطراف فقط مع الحفاظ على الأكواد الداخلية
                return line.replace(/^\*|\*$/g, '');
            }).join('\n');

            // 📝 تجهيز الرسالة النصية داخل قالب كود نظيف مقروء للواتساب
            const responseText = `📜 *كود البلوجين:* \`${pluginName}\`\n\n\`\`\`\n${code}\n\`\`\``;

            // إرسال الكود النهائي النظيف والمحمي
            await sock.sendMessage(jid, { text: responseText }, { quoted: msg });

        } catch (error) {
            return sock.sendMessage(msg.key.remoteJid, {
                text: `❌ حدث خطأ:\n${error.message || error.toString()}`
            }, { quoted: msg });
        }
    }
};