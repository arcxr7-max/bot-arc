// • Feature : عرض لقب عضو آخر عبر المنشن أو الرد
// • Developers : ARCEN Team

const fs = require('fs');
const path = require('path');

const guildsFile = path.join(__dirname, '../data/guilds.json');

function loadGuilds() {
  if (!fs.existsSync(guildsFile)) return {};
  return JSON.parse(fs.readFileSync(guildsFile, 'utf8'));
}

module.exports = {
  command: ['لقبه'],
  description: 'عرض لقب عضو آخر في النقابة من خلال الرد عليه أو عمل منشن.',
  category: 'group',

  async execute(sock, msg) {
    const chatId = msg.key.remoteJid;

    // التأكد من أن الأمر يتم تنفيذه داخل مجموعة
    if (!chatId.endsWith('@g.us')) {
      return sock.sendMessage(chatId, { text: '❌ هذا الأمر مخصص للمجموعات المرتبطة بنقابة فقط.' }, { quoted: msg });
    }

    // 1. تحديد الشخص المستهدف (إما عبر المنشن أو عبر الرد على رسالته)
    const mentionedJid = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
    const quotedParticipant = msg.message?.extendedTextMessage?.contextInfo?.participant;
    
    const targetJid = mentionedJid || quotedParticipant;

    if (!targetJid) {
      return sock.sendMessage(chatId, { 
        text: '⚠️ *يرجى الرد على رسالة العضو أو عمل منشن له بعد الأمر!*\n\n💡 *مثال:*\n.لقبه @منشن' 
      }, { quoted: msg });
    }

    const targetNumber = targetJid.split('@')[0];

    // 2. تحميل النقابات والبحث عن النقابة المرتبطة بهذا القروب
    let guilds = loadGuilds();
    let currentGuild = null;

    for (const guild of Object.values(guilds)) {
      if (guild.welcomeGroupId === chatId || guild.mainGroupId === chatId) {
        currentGuild = guild;
        break;
      }
    }

    if (!currentGuild) {
      return sock.sendMessage(chatId, { text: '❌ هذا القروب غير مرتبط بأي نقابة حالياً.' }, { quoted: msg });
    }

    if (!currentGuild.titles) currentGuild.titles = {};

    // 3. جلب اللقب وعرضه للمجموعة
    const userTitle = currentGuild.titles[targetNumber];

    if (userTitle) {
      return sock.sendMessage(chatId, {
        text: `🏷️ لقب العضو @${targetNumber} في هذه النقابة هو: *${userTitle.title}*`,
        mentions: [targetJid]
      }, { quoted: msg });
    } else {
      return sock.sendMessage(chatId, {
        text: `❌ العضو @${targetNumber} لم يقم باختيار لقب في هذه النقابة بعد.`,
        mentions: [targetJid]
      }, { quoted: msg });
    }
  }
};