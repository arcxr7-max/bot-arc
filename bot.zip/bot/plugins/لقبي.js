const config = require('../config');
const fs = require('fs');
const path = require('path');

const guildsFile = path.join(__dirname, '../data/guilds.json');

function loadGuilds() {
  if (!fs.existsSync(guildsFile)) {
    console.log('❌ ملف guilds.json غير موجود');
    return {};
  }
  return JSON.parse(fs.readFileSync(guildsFile, 'utf8'));
}

function saveGuilds(data) {
  fs.writeFileSync(guildsFile, JSON.stringify(data, null, 2));
}

const ARABIC_LETTERS = ['ا', 'ب', 'ت', 'ث', 'ج', 'ح', 'خ', 'د', 'ذ', 'ر', 'ز', 'س', 'ش', 'ص', 'ض', 'ط', 'ظ', 'ع', 'غ', 'ف', 'ق', 'ك', 'ل', 'م', 'ن', 'ه', 'و', 'ي'];

function getFirstLetter(text) {
  const firstChar = text.charAt(0);
  if (ARABIC_LETTERS.includes(firstChar)) return firstChar;
  return null;
}

async function updateWelcomeGroupDesc(sock, guildData) {
  const titles = guildData.titles || {};
  const takenCount = Object.keys(titles).length;
  const groupName = guildData.welcomeGroupName;

  let description = `عـدد الـقـاب مـؤخـودة ⊰• ${takenCount} •⊱\n`;
  description += `ـ✢ ⊱┄ ┅━ • ${groupName}┆⬪雷 • ━┅ ┈⊰ ✢\n`;

  for (const letter of ARABIC_LETTERS) {
    const userWithThisLetter = Object.entries(titles).find(([id, data]) => data.firstLetter === letter);
    if (userWithThisLetter) {
      description += `ـ• ⊰ ${letter} ⊱\nـ「 ${userWithThisLetter[1].title} 」\n`;
    } else {
      description += `ـ• ⊰ ${letter} ⊱\nـ「」\n`;
    }
  }

  description += `ـ✢ ⊱┄ ┅━ • ┆⬪雷 • ━┅ ┈⊰ ✢\n`;
  description += `ـ◝⚜️┆• ${groupName} •┆⚜️◟ـ`;

  try {
    await sock.groupUpdateDescription(guildData.welcomeGroupId, description);
  } catch (e) {}
}

module.exports = {
  command: 'لقبي',
  description: '🏷️ اختيار أو عرض لقبك',
  usage: '.لقبي [اللقب]',
  category: 'group',

  async execute(sock, msg) {
    const chatId = msg.key.remoteJid;
    const sender = msg.key.participant || msg.key.remoteJid;
    const senderNumber = sender.split('@')[0];

    console.log('🔍 .لقبي تنفيذ في:', chatId);

    let fullText = '';
    if (msg.message?.conversation) fullText = msg.message.conversation;
    else if (msg.message?.extendedTextMessage?.text) fullText = msg.message.extendedTextMessage.text;
    else fullText = '';

    const withoutCommand = fullText.replace(/^\.لقبي\s/, '').trim();
    const newTitle = withoutCommand;

    let guilds = loadGuilds();
    let currentGuild = null;

    // البحث عن النقابة المرتبطة بهذا القروب
    for (const [id, guild] of Object.entries(guilds)) {
      if (guild.welcomeGroupId === chatId || guild.mainGroupId === chatId) {
        currentGuild = guild;
        console.log('✅ تم العثور على النقابة:', id);
        break;
      }
    }

    if (!currentGuild) {
      console.log('❌ لا نقابة مرتبطة');
      return sock.sendMessage(chatId, { text: '❌ هذا القروب غير مرتبط بأي نقابة' }, { quoted: msg });
    }

    if (!currentGuild.titles) currentGuild.titles = {};

    // 🛠️ التعديل الذكي هنا: التحقق أولاً إذا كان العضو يطلب عرض لقبه فقط بدون كتابة لقب جديد
    if (!newTitle || newTitle === '.لقبي') {
      const myTitle = currentGuild.titles[senderNumber];
      if (myTitle) {
        return sock.sendMessage(chatId, {
          text: `🏷️ لقبك الحالي هو: *${myTitle.title}*`
        }, { quoted: msg });
      } else {
        return sock.sendMessage(chatId, { 
          text: '❌ لم تقم باختيار لقب بعد! يرجى الذهاب إلى قروب الاستقبال وكتابة: *.لقبي [لقبك]*' 
        }, { quoted: msg });
      }
    }

    // 🔒 الآن يتم فحص مكان المجموعات فقط إذا كان العضو يحاول "تسجيل أو تغيير" اللقب
    if (currentGuild.welcomeGroupId !== chatId) {
      return sock.sendMessage(chatId, { text: '❌ لا يمكنك اختيار أو تغيير لقب من هنا. اذهب إلى قروب الاستقبال' }, { quoted: msg });
    }

    const firstLetter = getFirstLetter(newTitle);
    if (!firstLetter) {
      return sock.sendMessage(chatId, { text: '❌ اللقب يجب أن يبدأ بحرف عربي' }, { quoted: msg });
    }

    // الفحص للتأكد من أن اللقب الكامل غير مكرر
    const existingUser = Object.entries(currentGuild.titles).find(([id, data]) => data.title.toLowerCase() === newTitle.toLowerCase());
    if (existingUser && existingUser[0] !== senderNumber) {
      return sock.sendMessage(chatId, { text: `❌ اللقب "${newTitle}" مأخوذ بالفعل من قبل عضو آخر.` }, { quoted: msg });
    }

    if (currentGuild.titles[senderNumber]) {
      delete currentGuild.titles[senderNumber];
    }

    currentGuild.titles[senderNumber] = {
      title: newTitle,
      firstLetter: firstLetter,
      chosenAt: Date.now()
    };

    saveGuilds(guilds);
    await updateWelcomeGroupDesc(sock, currentGuild);

    await sock.sendMessage(chatId, {
      text: `✅ تم اختيار لقبك بنجاح: ${newTitle}`
    }, { quoted: msg });
  }
};