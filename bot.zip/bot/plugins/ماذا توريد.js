const config = require('../config');
const path = require('path');

module.exports = {
  command: 'عبد',
  description: '🎤 إرسال صوت الحضور مع منشن خفي',
  category: 'fun',

  async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
            const jid = msg.key.remoteJid;
    const isGroup = jid.endsWith('@g.us');
    const audioPath = path.join(__dirname, '../resources/abd.mp3'); // ← تم تغيير الملف هنا

    try {
      // جلب المشاركين في الجروب (لو جروب)
      const mentions = isGroup
        ? (await sock.groupMetadata(jid)).participants.map(p => p.id)
        : [];

      await sock.sendMessage(jid, {
        audio: { url: audioPath },
        mimetype: 'audio/mpeg',
        ptt: true,
        mentions // منشن خفي
      }, { quoted: msg });

    } catch (err) {
      console.error('✗✗ خطأ في أمر حضر:', err);
      await sock.sendMessage(jid, {
        text: '❌ حصل خطأ أثناء إرسال الصوت.',
      }, { quoted: msg });
    }
  }
};