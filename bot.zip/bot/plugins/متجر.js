const config = require('../config');
const fs = require('fs');
const path = require('path');

const resourcesFile = path.join(__dirname, '../data/resources.json');
const shopFile = path.join(__dirname, '../data/shop.json');
const inventoryFile = path.join(__dirname, '../data/inventory.json');

function loadResources() {
    if (!fs.existsSync(resourcesFile)) return {};
    return JSON.parse(fs.readFileSync(resourcesFile, 'utf8'));
}

function saveResources(data) {
    fs.writeFileSync(resourcesFile, JSON.stringify(data, null, 2));
}

function loadShop() {
    if (!fs.existsSync(shopFile)) {
        const defaultShop = {
            "دراجة": { name: "دراجة", emoji: "🚲", price: { wood: 20, iron: 5 } },
            "سيارة": { name: "سيارة", emoji: "🚗", price: { gold: 5, iron: 30 } },
            "يخت": { name: "يخت", emoji: "⛵", price: { gold: 10, iron: 20, wood: 50 } },
            "طائرة": { name: "طائرة", emoji: "✈️", price: { gold: 20, iron: 50, wood: 30 } },
            "فيلا": { name: "فيلا", emoji: "🏠", price: { gold: 30, wood: 50, stone: 100 } }
        };
        fs.writeFileSync(shopFile, JSON.stringify(defaultShop, null, 2));
        return defaultShop;
    }
    return JSON.parse(fs.readFileSync(shopFile, 'utf8'));
}

function loadInventory() {
    if (!fs.existsSync(inventoryFile)) return {};
    return JSON.parse(fs.readFileSync(inventoryFile, 'utf8'));
}

function saveInventory(data) {
    fs.writeFileSync(inventoryFile, JSON.stringify(data, null, 2));
}

function getTotalItems(inventory) {
    let total = 0;
    for (const item of Object.values(inventory)) {
        total += item;
    }
    return total;
}

function getOwnerTitle(totalItems) {
    if (totalItems >= 50) return '👑 ملك الأسطوري';
    if (totalItems >= 30) return '💎 التاجر الكبير';
    if (totalItems >= 20) return '🥇 المستثمر الذهبي';
    if (totalItems >= 10) return '🥈 جامع التحف';
    if (totalItems >= 5) return '🥉 المقتني';
    return '🪨 مبتدئ';
}

function formatPrice(price) {
    let text = '';
    if (price.gold) text += `⚱️ ${price.gold} `;
    if (price.iron) text += `⚙️ ${price.iron} `;
    if (price.wood) text += `🪵 ${price.wood} `;
    if (price.stone) text += `🧱 ${price.stone} `;
    return text.trim();
}

module.exports = {
    command: 'متجر',
    description: '🛒 شراء ممتلكات',
    usage: '.متجر | .متجر [المنتج] [العدد]',
    category: 'shop',

    async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
                const chatId = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;
        const senderNumber = sender.split('@')[0];

        let fullText = '';
        if (msg.message?.conversation) fullText = msg.message.conversation;
        else if (msg.message?.extendedTextMessage?.text) fullText = msg.message.extendedTextMessage.text;
        else fullText = '';

        const withoutCommand = fullText.replace(/^\.متجر\s*/, '').trim();
        const parts = withoutCommand.split(/\s+/);
        const productName = parts[0]?.toLowerCase();
        const amount = parseInt(parts[1]) || 1;

        let shop = loadShop();
        let resources = loadResources();
        let userRes = resources[senderNumber] || { gold: 0, iron: 0, wood: 0, stone: 0 };
        let inventory = loadInventory();

        if (!inventory[senderNumber]) inventory[senderNumber] = {};

        // عرض المتجر
        if (!productName) {
            let text = `🛒 *المتجر*\n\n`;
            for (const [key, item] of Object.entries(shop)) {
                text += `${item.emoji} *${item.name}* - ${formatPrice(item.price)}\n\n`;
            }
            text += `📌 استخدم: .متجر [المنتج] [العدد]\n📌 مثال: .متجر سيارة 2`;
            return sock.sendMessage(chatId, { text }, { quoted: msg });
        }

        // البحث عن المنتج
        let product = null;
        let productKey = null;
        for (const [key, item] of Object.entries(shop)) {
            if (key.toLowerCase() === productName || item.name.toLowerCase() === productName) {
                product = item;
                productKey = key;
                break;
            }
        }

        if (!product) {
            return sock.sendMessage(chatId, { text: `❌ المنتج غير موجود` }, { quoted: msg });
        }

        if (amount > 100) {
            return sock.sendMessage(chatId, { text: `❌ الحد الأقصى للشراء هو 100 قطعة` }, { quoted: msg });
        }

        // حساب السعر الإجمالي والتحقق
        let hasEnough = true;
        let missingResource = '';
        
        for (const [res, val] of Object.entries(product.price)) {
            const required = val * amount;
            if ((userRes[res] || 0) < required) {
                hasEnough = false;
                missingResource = res;
                break;
            }
        }

if (!hasEnough) {
    const resourceNames = { gold: 'الذهب⚱️', iron: 'الحديد⚙️', wood: 'الخشب🪵', stone: 'الحجر🧱' };
    const required = product.price[missingResource] * amount;
    const current = userRes[missingResource] || 0;
    const needed = required - current;
    return sock.sendMessage(chatId, { text: `❌ تحتاج إلى ${resourceNames[missingResource]} ${needed} إضافية` }, { quoted: msg });
}
        // خصم الموارد
        for (const [res, val] of Object.entries(product.price)) {
            userRes[res] -= val * amount;
        }
        resources[senderNumber] = userRes;
        saveResources(resources);

        // إضافة إلى المخزون
        inventory[senderNumber][productKey] = (inventory[senderNumber][productKey] || 0) + amount;
        saveInventory(inventory);

        await sock.sendMessage(chatId, {
            text: `✅ *تم شراء ${product.emoji} ${product.name} × ${amount}*`
        }, { quoted: msg });
    }
};