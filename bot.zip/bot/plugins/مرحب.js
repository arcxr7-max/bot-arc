module.exports = {
  command: 'مرحب',
  desc: 'يرسل رسالة ترحيب جماعية مخفية لجميع الأعضاء الجدد',
  usage: '.مرحب',
  group: true,

  async execute(sock, msg) {

            try {
      const groupId = msg.key.remoteJid;

      let groupName = 'المجموعة';
      let participants = [];

      if (groupId.endsWith('@g.us')) {
        try {
          const metadata = await sock.groupMetadata(groupId);
          groupName = metadata.subject || groupName;
          participants = metadata.participants || [];
        } catch (e) {
          console.log("فشل في جلب بيانات الجروب:", e.message);
        }
      }

      // استخراج JIDs كل الأعضاء
      const allMembers = participants.map(p => p.id).filter(jid => jid !== sock.user.id);

const caption = `
⸻⸻⸻ ⌁ 🜲 𝐀𝐑𝐂 𝐒𝐘𝐒𝐓𝐄𝐌 𝐋𝐎𝐆𝐈𝐍 🜲 ⌁ ⸻⸻⸻

⚡ 𝙏𝙊 𝘼𝙇𝙇 𝙉𝙀𝙒 𝘼𝘾𝘾𝙀𝙎𝙎𝙊𝙍𝙎:
🔹 𝙔𝙊𝙐 𝘼𝙍𝙀 𝙉𝙊𝙒 𝙋𝘼𝙍𝙏 𝙊𝙁 𝙏𝙃𝙀 𝙉𝙀𝙅𝙐𝙎
🔹 𝙎𝙏𝘼𝙔 𝘼𝙇𝙄𝙂𝙉𝙀𝘿, 𝙍𝙀𝙎𝙋𝙀𝘾𝙏 𝙏𝙃𝙀 𝘾𝙊𝘿𝙀

⸻⸻⸻ ⊛ 𝗔𝗥𝗖𝗘𝗡 𝐈𝐒 𝐖𝐀𝐓𝐂𝐇𝐈𝐍𝐆 ⊛ ⸻⸻⸻

🌐 *أهــلًا بك في نظام المجمـوعة المتطور*
🛡️ *تم منحك حق الدخول إلى قاعدة بياناتنا*
🚀 *نتمنى لك تجربة تقنية فريدة وتفاعلًا قويًا*
⚠️ *النظام يراقب الالتزام بالقوانين، كن إيجابيًا*

╭━━〔🜲 𝗔𝗥𝗖𝗘𝗡 🜲〕━━╮
🔹 *نَحْنُ لَا نَصْنَعُ البُوتَات فَقَط، نَحْنُ نَصْنَعُ القُوَّة*
╰━━━━━━━━━━━━━━━━━━━━━━╯
`.trim();

      await sock.sendMessage(groupId, {
        text: caption,
        mentions: allMembers, // منشن مخفي
      }, { quoted: msg });

    } catch (err) {
      console.error("❌ خطأ في أمر الترحيب الجماعي:", err);
      await sock.sendMessage(msg.key.remoteJid, {
        text: '⚠️ حصل خطأ أثناء إرسال رسالة الترحيب.',
      }, { quoted: msg });
    }
  }
};