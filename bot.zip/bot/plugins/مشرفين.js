const fs = require('fs');
const path = require('path');

module.exports = {
    command: 'مشرفين',
    description: 'عرض منشنات المشرفين مع عددهم',
    category: 'group',
    usage: '.مشرفين',

    async execute(sock, msg, mdata) {
        try {
            const chatId = msg.key.remoteJid;
            
            // ✅ التحقق من أنه داخل جروب
            if (!chatId.endsWith('@g.us')) {
                return sock.sendMessage(chatId, {
                    text: '❌ هذا الأمر يعمل فقط داخل المجموعات.'
                }, { quoted: msg });
            }

            const groupMetadata = mdata || await sock.groupMetadata(chatId);
            const admins = groupMetadata.participants.filter(p => p.admin);
            
            if (admins.length === 0) {
                return sock.sendMessage(chatId, {
                    text: '👑 لا يوجد مشرفين في هذه المجموعة.'
                }, { quoted: msg });
            }

            const mentions = admins.map(a => a.id);
            
            // ✅ بناء القائمة
            let adminLines = '';
            admins.forEach((admin, idx) => {
                adminLines += `${idx + 1}. @${admin.id.split('@')[0]}\n`;
            });

            const messageText = `👑 *المشرفين (${admins.length})*\n\n${adminLines}\n╰─⟡ 𝗔𝗥𝗖𝗘𝗡`;

            // ✅ جلب صورة الجروب
            let groupImg;
            try {
                groupImg = await sock.profilePictureUrl(chatId, 'image');
            } catch (e) {
                groupImg = 'https://i.imgur.com/ErsJ1VY.jpeg';
            }

            // ✅ إرسال الرسالة
            await sock.sendMessage(chatId, {
                image: { url: groupImg },
                caption: messageText,
                mentions: mentions
            }, { quoted: msg });

        } catch (err) {
            console.error('🚨 خطأ في عرض المشرفين:', err);
            await sock.sendMessage(msg.key.remoteJid, {
                text: '❌ حصل خطأ أثناء استخراج المشرفين.'
            }, { quoted: msg });
        }
    }
};