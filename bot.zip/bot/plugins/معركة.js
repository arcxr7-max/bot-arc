const config = require('../config');
const fs = require('fs');
const path = require('path');

const pointsFile = path.join(__dirname, '../data/points.json');

function getPoints() {
    if (!fs.existsSync(pointsFile)) return {};
    return JSON.parse(fs.readFileSync(pointsFile, 'utf8'));
}

function savePoints(points) {
    fs.writeFileSync(pointsFile, JSON.stringify(points, null, 2));
}

function formatNumber(num) {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
}

// شخصيات الأنمي (أسعار أقل ومناسبة للمبتدئين)
const animeCharacters = [
    { id: 1, name: "ناروتو", anime: "ناروتو", power: 50, reward: 100, minLevel: 0, emoji: "🍥", skill: "راسينغان" },
    { id: 2, name: "ساسكي", anime: "ناروتو", power: 55, reward: 120, minLevel: 0, emoji: "⚡", skill: "تشيدوري" },
    { id: 3, name: "لوفي", anime: "ون بيس", power: 60, reward: 150, minLevel: 1, emoji: "👒", skill: "غوم غوم" },
    { id: 4, name: "زورو", anime: "ون بيس", power: 65, reward: 180, minLevel: 1, emoji: "🗡️", skill: "سانتوري" },
    { id: 5, name: "تانجيرو", anime: "ديمون سلاير", power: 45, reward: 80, minLevel: 0, emoji: "🗡️", skill: "هينوكامي" },
    { id: 6, name: "غوكو", anime: "دراغون بول", power: 80, reward: 250, minLevel: 2, emoji: "🐉", skill: "كاميها ميها" },
    { id: 7, name: "فيجيتا", anime: "دراغون بول", power: 85, reward: 280, minLevel: 2, emoji: "👑", skill: "غاليك غان" },
    { id: 8, name: "إيتاتشي", anime: "ناروتو", power: 70, reward: 200, minLevel: 1, emoji: "👁️", skill: "تسوكويومي" },
    { id: 9, name: "غوجو", anime: "جوجوتسو", power: 100, reward: 400, minLevel: 3, emoji: "👁️", skill: "لانهائي" },
    { id: 10, name: "سوكونا", anime: "جوجوتسو", power: 120, reward: 600, minLevel: 4, emoji: "👹", skill: "القاطع" }
];

// حساب مستوى اللاعب (أسهل للوصول)
function getPlayerLevel(points) {
    if (points >= 10000) return 10;
    if (points >= 5000) return 8;
    if (points >= 3000) return 6;
    if (points >= 2000) return 5;
    if (points >= 1000) return 4;
    if (points >= 500) return 3;
    if (points >= 200) return 2;
    if (points >= 50) return 1;
    return 0;
}

// اختيار عدو عشوائي
function getRandomEnemy(level) {
    const available = animeCharacters.filter(c => c.minLevel <= level + 1);
    if (available.length === 0) return animeCharacters[0];
    return available[Math.floor(Math.random() * available.length)];
}

// المعركة (لا تخسر نقوداً إذا كان الرصيد قليلاً)
function battle(playerLevel, enemy, currentPoints) {
    const playerPower = (playerLevel * 30) + (Math.random() * 60) + 20;
    const enemyPower = enemy.power + (Math.random() * 40);
    
    let result, reward;
    
    if (playerPower > enemyPower) {
        result = 'win';
        reward = enemy.reward;
    } else if (enemyPower > playerPower + 30) {
        result = 'loss';
        // لا تخسر أكثر من 30% من الرصيد
        const maxLoss = Math.max(10, Math.floor(currentPoints * 0.3));
        reward = -Math.min(maxLoss, Math.floor(enemy.reward / 2));
    } else {
        result = 'draw';
        reward = Math.floor(enemy.reward / 3);
    }
    
    return { result, reward, playerPower: Math.floor(playerPower), enemyPower: Math.floor(enemyPower) };
}

module.exports = {
    command: 'معركة',
    description: '⚔️ خوض معركة ضد شخصيات الأنمي',
    usage: '.معركة',
    category: 'game',

    async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
                const chatId = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;
        const senderNumber = sender.split('@')[0];

        let points = getPoints();
        let playerPoints = points[senderNumber] || 0;
        
        // إعطاء نقاط ابتدائية إذا كان الرصيد صفر أو سالب
        if (playerPoints <= 0) {
            playerPoints = 100;
            points[senderNumber] = playerPoints;
            savePoints(points);
        }
        
        const playerLevel = getPlayerLevel(playerPoints);
        const enemy = getRandomEnemy(playerLevel);
        const battleResult = battle(playerLevel, enemy, playerPoints);
        
        const newPoints = playerPoints + battleResult.reward;
        points[senderNumber] = Math.max(0, newPoints);
        savePoints(points);
        
        const resultEmoji = battleResult.result === 'win' ? '🏆' : (battleResult.result === 'loss' ? '💀' : '🤝');
        const resultText = battleResult.result === 'win' ? 'فوز!' : (battleResult.result === 'loss' ? 'خسارة!' : 'تعادل!');
        
        const text = `⚔️ *معركة ضد ${enemy.anime}* ⚔️\n\n` +
            `👤 مستواك: ${playerLevel}\n` +
            `👹 ${enemy.emoji} ${enemy.name} (قوة ${enemy.power})\n` +
            `🎯 ${enemy.skill}\n\n` +
            `📊 النتيجة\n` +
            `⚔️ قوتك: ${battleResult.playerPower}\n` +
            `👹 قوة العدو: ${battleResult.enemyPower}\n\n` +
            `${resultEmoji} *${resultText}*\n\n` +
            `💰 ${battleResult.reward >= 0 ? '+' : ''}${battleResult.reward} نقطة\n` +
            `💰 رصيدك: ${Math.max(0, newPoints)} نقطة`;
        
        await sock.sendMessage(chatId, { text }, { quoted: msg });
    }
};