const config = require('../config');
const { getProfilePicture } = require('@whiskeysockets/baileys');

module.exports = {
  command: 'معلومات',
  description: 'جلب معلومات الجروب مثل الاسم والوصف والصورة',
  usage: '.معلومات',
  async execute(sock, m) {
    try {
      const jid = m.key.remoteJid;

      // تأكد أن الأمر داخل جروب
      if (!jid.endsWith('@g.us')) {
        return await sock.sendMessage(jid, {
          text: `╭──⪧\n❌ *هذا الأمر يعمل فقط داخل المجموعات.*\n╰──⪦`,
        }, { quoted: m });
      }

      // جلب معلومات الجروب
      const metadata = await sock.groupMetadata(jid);
      const name = metadata.subject || 'بدون اسم';
      const description = metadata.desc || 'لا يوجد وصف.';
      const picture = await sock.profilePictureUrl(jid, 'image').catch(() => null);

      // رسالة مزخرفة فخمة
      const message = `
╭━━━━━━〔 💎 𝗚𝗥𝗢𝗨𝗣 𝗜𝗡𝗙𝗢 💎 〕━━━━━━╮
┃ 🏷️ *الاسم:* ${name}
┃ 🗒️ *الوصف:* ${description}
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯
      `.trim();

      // إرسال صورة الجروب أولًا (إن وجدت)
      if (picture) {
        await sock.sendMessage(jid, {
          image: { url: picture },
          caption: message,
        }, { quoted: m });
      } else {
        await sock.sendMessage(jid, {
          text: message,
        }, { quoted: m });
      }

    } catch (err) {
      console.error(err);
      await sock.sendMessage(m.key.remoteJid, {
        text: `╭──⪧\n⚠️ *حدث خطأ أثناء جلب معلومات الجروب.*\n╰──⪦`,
      }, { quoted: m });
    }
  }
};