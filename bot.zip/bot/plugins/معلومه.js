const config = require('../config');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

const factsFile = path.join(__dirname, '../data/facts.json');

// ========== تحميل المعلومات من GitHub ==========
async function loadFactsFromGitHub() {
    try {
        const response = await axios.get('https://raw.githubusercontent.com/arcxr7-max/ARC/refs/heads/main/facts.json');
        if (response.status === 200 && Array.isArray(response.data)) {
            fs.writeFileSync(factsFile, JSON.stringify(response.data, null, 2));
            console.log('✅ تم تحميل المعلومات من GitHub');
            return response.data;
        }
        throw new Error('تنسيق غير صحيح');
    } catch (error) {
        console.log('❌ فشل التحميل من GitHub، نستخدم الملف المحلي');
        return loadFactsFromLocal();
    }
}

// ========== تحميل من الملف المحلي ==========
function loadFactsFromLocal() {
    if (fs.existsSync(factsFile)) {
        try {
            const data = JSON.parse(fs.readFileSync(factsFile, 'utf8'));
            if (Array.isArray(data) && data.length > 0) {
                return data;
            }
        } catch (e) {}
    }
    return [];
}

// ========== المتغيرات ==========
let factsCache = [];
let lastSync = 0;

// ========== جلب المعلومات ==========
async function getFacts(forceRefresh = false) {
    const now = Date.now();
    
    if (forceRefresh || (now - lastSync > 300000)) {
        factsCache = await loadFactsFromGitHub();
        lastSync = now;
    }
    
    if (factsCache.length === 0) {
        factsCache = loadFactsFromLocal();
    }
    
    return factsCache;
}

// ========== الأمر ==========
module.exports = {
    category: 'fun',
    command: 'معلومة',
    description: '💡 معلومة عامة أو دينية عشوائية',
    usage: '.معلومة',
  
    async execute(sock, msg) {
        const chatId = msg.key.remoteJid;
        
        try {
            const facts = await getFacts();
            const fact = facts[Math.floor(Math.random() * facts.length)];
            
            const message = `┃  *هل تعلم!؟* 😭✨️

┃ ❓ *المعلومة:*
┃ ${fact}`;

            await sock.sendMessage(chatId, { text: message }, { quoted: msg });
            
        } catch (error) {
            console.error('❌ خطأ في معلومة:', error);
            await sock.sendMessage(chatId, { 
                text: '❌ حدث خطأ أثناء جلب المعلومة' 
            }, { quoted: msg });
        }
    }
};