const config = require('../config');
const fs = require('fs');
const path = require('path');
const { isElite } = require('../haykala/elite');

module.exports = {
category: 'control',
command: ['ملفات'],
description: '📦 استعراض مجلدات وملفات البوت وإرسال الملفات مباشرة.',

async execute(sock, msg) {
// [ARCEN-SECURITY-START]
const senderNum = (msg.key.participant || msg.key.remoteJid).split('@')[0];
const { isDev } = require('../utils/devs');
const _fs = require('fs');
const _path = require('path');
const eliteFilePath = _path.join(process.cwd(), 'data', 'elite.json');
let eliteNumbers = [];
if (_fs.existsSync(eliteFilePath)) {
try { eliteNumbers = JSON.parse(_fs.readFileSync(eliteFilePath, 'utf-8')).eliteNumbers || []; } catch(e){}
}
// ⚠️ رسالة الحماية المحدثة والمثبتة بناءً على طلبك
if (!isDev(senderNum)) return sock.sendMessage(msg.key.remoteJid, { text: '⚠️ ┋ عذراً، هذا الأمر مخصص للمطور الأساسي فقط!' }, { quoted: msg });
// [ARCEN-SECURITY-END]

const fullText = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
const commandName = fullText.split(' ')[0]?.toLowerCase();
const inputText = fullText.slice(commandName.length).trim();
const basePath = path.resolve('./');

function getItems(dirPath) {
const items = fs.readdirSync(dirPath);
const folders = [];
const files = [];

for (let item of items) {
const full = path.join(dirPath, item);
const stats = fs.statSync(full);
if (stats.isDirectory() && (item === 'ملف_الاتصال' || item === 'node_modules')) continue;
if (stats.isDirectory()) folders.push(item);
else files.push(item);
}

return [...folders.map(f => ({ name: f, type: 'folder' })), ...files.map(f => ({ name: f, type: 'file' }))];
}

function levenshteinDistance(a, b) {
if (!a) return b.length;
if (!b) return a.length;
const matrix = [];
for (let i = 0; i <= b.length; i++) matrix[i] = [i];
for (let j = 0; j <= a.length; j++) matrix[0][j] = j;
for (let i = 1; i <= b.length; i++) {
for (let j = 1; j <= a.length; j++) {
matrix[i][j] = b[i - 1] === a[j - 1]
? matrix[i - 1][j - 1]
: Math.min(matrix[i - 1][j - 1] + 1, matrix[i][j - 1] + 1, matrix[i - 1][j] + 1);
}
}
return matrix[b.length][a.length];
}

function findClosestMatch(input, options, maxDistance = 3) {
let closest = null;
let min = Infinity;
for (let option of options) {
const distance = levenshteinDistance(input.toLowerCase(), option.toLowerCase());
if (distance < min && distance <= maxDistance) {
min = distance;
closest = option;
}
}
return closest;
}

const currentItems = getItems(basePath);

if (inputText.includes('/')) {
const [folderPart, filePart] = inputText.split('/');
const folderIndex = parseInt(folderPart) - 1;
if (isNaN(folderIndex) || folderIndex < 0 || folderIndex >= currentItems.length || currentItems[folderIndex].type !== 'folder') {
return await sock.sendMessage(msg.key.remoteJid, {
text: `❌ المجلد رقم ${folderPart} غير صحيح أو مش مجلد.`,
}, { quoted: msg });
}

const selectedFolder = currentItems[folderIndex].name;
const folderPath = path.join(basePath, selectedFolder);
const insideItems = getItems(folderPath);

let selectedFile = '';
if (/^\d+$/.test(filePart)) {
const fileIndex = parseInt(filePart) - 1;
if (fileIndex < 0 || fileIndex >= insideItems.length) {
return await sock.sendMessage(msg.key.remoteJid, {
text: `⚠️ الملف رقم ${filePart} غير موجود داخل المجلد.`,
}, { quoted: msg });
}
selectedFile = insideItems[fileIndex].name;
} else {
const names = insideItems.map(i => i.name);
if (names.includes(filePart)) {
selectedFile = filePart;
} else {
const close = findClosestMatch(filePart, names);
let reply = `❌ "${filePart}" غير موجود داخل المجلد.`;
if (close) reply += `\n🔍 يمكن تقصد: ${close}`;
return await sock.sendMessage(msg.key.remoteJid, { text: reply }, { quoted: msg });
}
}

const finalPath = path.join(folderPath, selectedFile);
const stat = fs.statSync(finalPath);

if (stat.isDirectory()) {
const inner = getItems(finalPath);
const list = inner.map((item, i) =>
`│ ${(i + 1).toString().padEnd(2)}. ${item.type === 'folder' ? '📁' : '📄'} ${item.name}`
).join('\n');

return await sock.sendMessage(msg.key.remoteJid, {
text: `📂 محتويات المجلد "${selectedFile}":\n${list}`
}, { quoted: msg });
}

return await sock.sendMessage(msg.key.remoteJid, {
document: fs.readFileSync(finalPath),
fileName: selectedFile,
mimetype: 'application/octet-stream'
}, { quoted: msg });
}

if (!inputText) {
const list = currentItems.map((item, i) =>
`│ ${(i + 1).toString().padEnd(2)}. ${item.type === 'folder' ? '📁' : '📄'} ${item.name}`
).join('\n');

return await sock.sendMessage(msg.key.remoteJid, {
text: `
📦 محتويات البوت:
${list}

✍️ اكتب:
- .ملفات [رقم أو اسم ملف/مجلد] 📄 أو 📁
- .ملفات [رقم/اسم مجلد]/[رقم/اسم ملف] لفتح ملف داخل مجلد
`.trim()
}, { quoted: msg });
}

let selected = '';
if (/^\d+$/.test(inputText)) {
const index = parseInt(inputText) - 1;
if (index >= 0 && index < currentItems.length) {
selected = currentItems[index].name;
} else {
return await sock.sendMessage(msg.key.remoteJid, {
text: `⚠️ الرقم غير صحيح! اختار رقم بين 1 و ${currentItems.length}`
}, { quoted: msg });
}
} else {
const names = currentItems.map(i => i.name);
if (names.includes(inputText)) {
selected = inputText;
} else {
const close = findClosestMatch(inputText, names);
let reply = `❌ "${inputText}" غير موجود!`;
if (close) reply += `\n🔍 يمكن تقصد: ${close}`;
return await sock.sendMessage(msg.key.remoteJid, { text: reply }, { quoted: msg });
}
}

const selectedPath = path.join(basePath, selected);
const stats = fs.statSync(selectedPath);

if (stats.isDirectory()) {
const insideItems = getItems(selectedPath);
const listInside = insideItems.map((item, i) =>
`│ ${(i + 1).toString().padEnd(2)}. ${item.type === 'folder' ? '📁' : '📄'} ${item.name}`
).join('\n');

return await sock.sendMessage(msg.key.remoteJid, {
text: `
📂 محتويات المجلد "${selected}":
${listInside}
`.trim()
}, { quoted: msg });
}

return await sock.sendMessage(msg.key.remoteJid, {
document: fs.readFileSync(selectedPath),
fileName: selected,
mimetype: 'application/octet-stream'
}, { quoted: msg });
}
};