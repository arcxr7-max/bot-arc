const config = require('../config');
const fs = require('fs');
const path = require('path');

const shopFile = path.join(__dirname, '../data/shop.json');
const inventoryFile = path.join(__dirname, '../data/inventory.json');

function loadShop() {
    if (!fs.existsSync(shopFile)) return {};
    return JSON.parse(fs.readFileSync(shopFile, 'utf8'));
}

function loadInventory() {
    if (!fs.existsSync(inventoryFile)) return {};
    return JSON.parse(fs.readFileSync(inventoryFile, 'utf8'));
}

function getTotalItems(inventory) {
    let total = 0;
    for (const item of Object.values(inventory)) {
        total += item;
    }
    return total;
}

function getOwnerTitle(totalItems) {
    if (totalItems >= 50) return '👑 ملك الأسطوري';
    if (totalItems >= 30) return '💎 التاجر الكبير';
    if (totalItems >= 20) return '🥇 المستثمر الذهبي';
    if (totalItems >= 10) return '🥈 جامع التحف';
    if (totalItems >= 5) return '🥉 المقتني';
    return '🪨 مبتدئ';
}

module.exports = {
    category: 'bank',
    command: 'ممتلكاتي',
    description: '🏠 عرض ممتلكاتك ولقبك',
    usage: '.ممتلكاتي',
    
    async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
                const chatId = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;
        const senderNumber = sender.split('@')[0];

        const shop = loadShop();
        const inventory = loadInventory();
        const userItems = inventory[senderNumber] || {};

        const totalItems = getTotalItems(userItems);
        const title = getOwnerTitle(totalItems);

        // عرض الممتلكات بالتفصيل
        let text = `📦 *ممتلكاتك:* ${totalItems}\n`;
        text += `🏆 *لقبك:* ${title}\n\n`;
        
        // عرض كل منتج وكميته
        let hasItems = false;
        for (const [key, item] of Object.entries(shop)) {
            const count = userItems[key] || 0;
            if (count > 0) {
                text += `${item.emoji} ${item.name}: ${count}\n`;
                hasItems = true;
            }
        }
        
        if (!hasItems) {
            text += `❌ ليس لديك ممتلكات بعد\nاستخدم .متجر [المنتج] [العدد] للشراء`;
        }

        await sock.sendMessage(chatId, { text }, { quoted: msg });
    }
};