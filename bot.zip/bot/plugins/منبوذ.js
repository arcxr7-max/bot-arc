const config = require('../config');
module.exports = {
  command: "منبوذ",
  description: "☠️ يختار شخص منبوذ لمدة 5 دقائق",
  usage: ".منبوذ",

  async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
            const from = msg.key.remoteJid;

    // التأكد أن الرسالة من جروب
    if (!from.endsWith('@g.us')) {
      return sock.sendMessage(from, {
        text: "❌ هذا الأمر يعمل فقط في الجروبات."
      }, { quoted: msg });
    }

    try {
      const group = await sock.groupMetadata(from);
      const participants = group.participants.filter(p => p.id !== msg.sender);
      
      if (participants.length === 0) {
        return sock.sendMessage(from, {
          text: "❗ مفيش أعضاء تانيين أختار منهم المنبوذ."
        }, { quoted: msg });
      }

      const chosen = participants[Math.floor(Math.random() * participants.length)];

      await sock.sendMessage(from, {
        text: `☠️ *المنبوذ الآن هو:* @${chosen.id.split('@')[0]}ِ\n🚫 *يُمنع التواصل معه لمدة 5 دقائق!*\nقانون الغابة بدأ.`,
        mentions: [chosen.id]
      }, { quoted: msg });

    } catch (err) {
      await sock.sendMessage(from, {
        text: "⚠️ حصل خطأ أثناء محاولة اختيار المنبوذ."
      }, { quoted: msg });
      console.error(err);
    }
  }
};