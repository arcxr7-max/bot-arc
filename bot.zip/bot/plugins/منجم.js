const config = require('../config');
const fs = require('fs');
const path = require('path');

const resourcesFile = path.join(__dirname, '../data/resources.json');
const pointsFile = path.join(__dirname, '../data/points.json');

function loadResources() {
    if (!fs.existsSync(resourcesFile)) return {};
    return JSON.parse(fs.readFileSync(resourcesFile, 'utf8'));
}

function saveResources(data) {
    fs.writeFileSync(resourcesFile, JSON.stringify(data, null, 2));
}

function getPoints() {
    if (!fs.existsSync(pointsFile)) return {};
    return JSON.parse(fs.readFileSync(pointsFile, 'utf8'));
}

function savePoints(points) {
    fs.writeFileSync(pointsFile, JSON.stringify(points, null, 2));
}

const COOLDOWN_TIME = 120000; // 2 دقيقة

function getRemainingTime(lastTime) {
    if (!lastTime || lastTime === 0) return 'جاهز';
    const now = Date.now();
    const elapsed = now - lastTime;
    if (elapsed >= COOLDOWN_TIME) return 'جاهز';
    const remaining = COOLDOWN_TIME - elapsed;
    const minutes = Math.floor(remaining / 60000);
    const seconds = Math.floor((remaining % 60000) / 1000);
    if (minutes > 0) return `${minutes}د ${seconds}ث`;
    return `${seconds}ث`;
}

const mineLevels = {
    1: { name: "حجري 🪨", resources: { gold: 0, iron: 1, wood: 0, stone: 5 }, exp: 10 },
    2: { name: "حديدي ⚙️", resources: { gold: 1, iron: 8, wood: 0, stone: 3 }, exp: 25 },
    3: { name: "ذهبي ⚱️", resources: { gold: 5, iron: 10, wood: 0, stone: 10 }, exp: 50 },
    4: { name: "ماسي 💎", resources: { gold: 15, iron: 25, wood: 0, stone: 30 }, exp: 100 }
};

module.exports = {
    command: 'منجم',
    description: '⛏️ اذهب إلى المنجم واستخرج الموارد',
    usage: '.منجم',
    category: 'game',

    async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
                const chatId = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;
        const senderNumber = sender.split('@')[0];

        let resources = loadResources();
        let userRes = resources[senderNumber] || { gold: 0, iron: 0, wood: 0, stone: 0, mineLevel: 1, lastMine: 0 };
        
        if (!resources[senderNumber]) resources[senderNumber] = userRes;
        
        const currentLevel = userRes.mineLevel || 1;
        const mineData = mineLevels[currentLevel];

        const remaining = getRemainingTime(userRes.lastMine);
        if (remaining !== 'جاهز') {
            return sock.sendMessage(chatId, { text: `⏳ انتظر ${remaining}` }, { quoted: msg });
        }

        userRes.gold += mineData.resources.gold;
        userRes.iron += mineData.resources.iron;
        userRes.wood += mineData.resources.wood;
        userRes.stone += mineData.resources.stone;
        
        let points = getPoints();
        points[senderNumber] = (points[senderNumber] || 0) + mineData.exp;
        savePoints(points);
        
        userRes.lastMine = Date.now();
        resources[senderNumber] = userRes;
        saveResources(resources);

        const message = `⛏️ *تعدين ${mineData.name}*\n⚱️+${mineData.resources.gold} ⚙️+${mineData.resources.iron} 🧱+${mineData.resources.stone}\n⭐ +${mineData.exp}`;

        await sock.sendMessage(chatId, { text: message }, { quoted: msg });
    }
};