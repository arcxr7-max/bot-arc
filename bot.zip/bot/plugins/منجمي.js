const config = require('../config');
const fs = require('fs');
const path = require('path');

const resourcesFile = path.join(__dirname, '../data/resources.json');
const pointsFile = path.join(__dirname, '../data/points.json');

function loadResources() {
    if (!fs.existsSync(resourcesFile)) return {};
    return JSON.parse(fs.readFileSync(resourcesFile, 'utf8'));
}

function saveResources(data) {
    fs.writeFileSync(resourcesFile, JSON.stringify(data, null, 2));
}

function getPoints() {
    if (!fs.existsSync(pointsFile)) return {};
    return JSON.parse(fs.readFileSync(pointsFile, 'utf8'));
}

function savePoints(points) {
    fs.writeFileSync(pointsFile, JSON.stringify(points, null, 2));
}

const mineLevels = {
    1: { name: "حجري 🪨", cost: 0, resources: { gold: 0, iron: 1, wood: 0, stone: 5 }, exp: 10 },
    2: { name: "حديدي ⚙️", cost: 500, resources: { gold: 1, iron: 8, wood: 0, stone: 3 }, exp: 25 },
    3: { name: "ذهبي ⚱️", cost: 2000, resources: { gold: 5, iron: 10, wood: 0, stone: 10 }, exp: 50 },
    4: { name: "ماسي 💎", cost: 10000, resources: { gold: 15, iron: 25, wood: 0, stone: 30 }, exp: 100 }
};

function upgradeCost(currentLevel) {
    const nextLevel = currentLevel + 1;
    if (!mineLevels[nextLevel]) return null;
    return mineLevels[nextLevel].cost;
}

module.exports = {
    category: 'bank',
    command: 'منجمي',
    description: '⛏️ عرض معلومات المنجم وتطويره',
    usage: '.منجمي | .منجمي تطوير',
    
    async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
                const chatId = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;
        const senderNumber = sender.split('@')[0];

        let fullText = '';
        if (msg.message?.conversation) fullText = msg.message.conversation;
        else if (msg.message?.extendedTextMessage?.text) fullText = msg.message.extendedTextMessage.text;
        else fullText = '';

        const withoutCommand = fullText.replace(/^\.منجمي\s*/, '').trim();
        const parts = withoutCommand.split(/\s+/);
        const action = parts[0]?.toLowerCase();

        let resources = loadResources();
        let userRes = resources[senderNumber] || { gold: 0, iron: 0, wood: 0, stone: 0, mineLevel: 1, lastMine: 0 };
        
        if (!resources[senderNumber]) resources[senderNumber] = userRes;
        
        const currentLevel = userRes.mineLevel || 1;
        const mineData = mineLevels[currentLevel];

        // ✅ تطوير المنجم (.منجمي تطوير)
        if (action === 'تطوير') {
            const nextLevel = currentLevel + 1;
            const cost = upgradeCost(currentLevel);
            
            if (!cost) {
                return sock.sendMessage(chatId, { text: '🏆 أعلى مستوى!' }, { quoted: msg });
            }
            
            let points = getPoints();
            const userPoints = points[senderNumber] || 0;
            
            if (userPoints < cost) {
                return sock.sendMessage(chatId, { text: `❌ تحتاج ${cost} نقطة` }, { quoted: msg });
            }
            
            points[senderNumber] = userPoints - cost;
            savePoints(points);
            
            userRes.mineLevel = nextLevel;
            resources[senderNumber] = userRes;
            saveResources(resources);
            
            return sock.sendMessage(chatId, { text: `✅ تم التطوير إلى المستوى ${nextLevel}!` }, { quoted: msg });
        }

        // ✅ عرض معلومات المنجم
        let text = `⛏️ *المستوى ${currentLevel}* | ${mineData.name}\n`;
        text += `📦 لكل تعدين: ⚱️ ${mineData.resources.gold} | ⚙️ ${mineData.resources.iron} | 🧱 ${mineData.resources.stone}\n`;
        text += `⭐ خبرة: +${mineData.exp}\n`;
        
        const nextCost = upgradeCost(currentLevel);
        if (nextCost) {
            text += `📌 للتطوير: 💰 ${nextCost} ( .منجمي تطوير )`;
        } else {
            text += `🏆 أعلى مستوى!`;
        }

        await sock.sendMessage(chatId, { text }, { quoted: msg });
    }
};