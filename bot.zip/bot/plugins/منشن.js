const config = require('../config');
const axios = require('axios');

module.exports = {
  command: 'منشن',
  description: '📢 منشن جماعي لكل أعضاء الجروب بالتنسيق المطور',
  usage: '.منشن',
  category: 'tools',

  async execute(sock, msg, args = []) {
        // [ARCEN-SECURITY-START]
        const senderNum = (msg.key.participant || msg.key.remoteJid).split('@')[0];
        const { isDev } = require('../utils/devs'); 
        const _fs = require('fs');
        const _path = require('path');
        const eliteFilePath = _path.join(process.cwd(), 'data', 'elite.json');
        let eliteNumbers = [];
        if (_fs.existsSync(eliteFilePath)) {
            try { eliteNumbers = JSON.parse(_fs.readFileSync(eliteFilePath, 'utf-8')).eliteNumbers || []; } catch(e){}
        }
        const groupMetadata = msg.key.remoteJid.endsWith('@g.us') ? await sock.groupMetadata(msg.key.remoteJid) : null;
        const isAdmin = groupMetadata ? groupMetadata.participants.find(p => p.id.split('@')[0] === senderNum)?.admin : false;
        if (!isDev(senderNum) && !eliteNumbers.includes(senderNum) && !isAdmin) return sock.sendMessage(msg.key.remoteJid, { text: '🛡️ ┋ هذا الأمر يتطلب صلاحيات المشرفين أو المطور أو النخبة!' }, { quoted: msg });
        // [ARCEN-SECURITY-END]
        
    try {
      const groupJid = msg.key.remoteJid;
      if (!groupJid.endsWith('@g.us')) {
        return sock.sendMessage(groupJid, {
          text: '🚫 هذا الأمر يعمل فقط داخل *المجموعات*.'
        }, { quoted: msg });
      }

      const metadata = await sock.groupMetadata(groupJid);
      const participants = metadata.participants;
      const mentions = participants.map(p => p.id);
      const groupName = metadata.subject;
      const memberCount = participants.length;

      // 🖼️ جلب الصورة من رابط مباشر
      const imageUrl = 'https://raw.githubusercontent.com/arcxr7-max/ARC/refs/heads/main/Picsart_26-05-26_12-40-47-350.jpg'; 
      const response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
      const imageBuffer = Buffer.from(response.data, 'utf-8');

      // 👤 الشخص الذي استخدم الأمر
      const senderId = (msg.participant || msg.key.participant || msg.key.remoteJid).split('@')[0];

      // ⏰ التاريخ والوقت
      const now = new Date();
      const time = now.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
      const date = now.toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' });

      // ✍️ بناء قائمة الأعضاء مع إضافة الرموز ٍ و ْ لكل سطر
      const memberLines = participants.map((p, i) => `➤ ${i + 1}. ٍ@${p.id.split('@')[0]}ْ`).join('\n');

      const caption = `
📢 *منشن جماعي لكل الأعضاء* 🪽

╭━━〔 🛡️ *${groupName}* 🛡️ 〕━━╮
📊 *عدد الأعضاء:* ${memberCount}*
📅 *التاريخ:* ${date}*
⏰ *الوقت:* ${time}*
👑 *تم بواسطة:* @${senderId}ٍ*
╰━━━━━━━━━━━━━━━━╯

👥 *الأعضاء:*
${memberLines}
`.trim();

      await sock.sendMessage(groupJid, {
        image: imageBuffer,
        caption,
        mentions
      }, { quoted: msg });

    } catch (err) {
      console.error('❌ خطأ في أمر منشن:', err);
      await sock.sendMessage(msg.key.remoteJid, {
        text: `❌ حصل خطأ:\n\`\`\`${err.message || err.toString()}\`\`\``
      }, { quoted: msg });
    }
  }
};