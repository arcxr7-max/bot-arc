const config = require('../config');
const fs = require('fs');
const path = require('path');
const orgFile = path.join(__dirname, '../data/org.json');

function loadOrg() {
  if (!fs.existsSync(orgFile)) return [];
  return JSON.parse(fs.readFileSync(orgFile));
}

function saveOrg(data) {
  fs.writeFileSync(orgFile, JSON.stringify(data, null, 2));
}

module.exports = {
  command: 'منظمه',
  description: 'إضافة شخص إلى المنظمة.',
  category: 'admin',

  async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
            const groupMetadata = await sock.groupMetadata(msg.from);
    const sender = msg.sender;
    const mention = msg.mentionedJid?.[0];
    if (!mention) return msg.reply('👤 منشن الشخص اللي عايز تضيفه للمنظمة');

    const org = loadOrg();
    if (!org.includes(mention)) {
      org.push(mention);
      saveOrg(org);
      await msg.reply(`🧠 تم إضافة ${mention.split('@')[0]} إلى المنظمة.`);
    } else {
      await msg.reply('⛔ الشخص ده موجود بالفعل في المنظمة.');
    }
  }
};