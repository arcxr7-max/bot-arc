const config = require('../config');
const fs = require('fs');
const path = require('path');

const resourcesFile = path.join(__dirname, '../data/resources.json');

function loadResources() {
    if (!fs.existsSync(resourcesFile)) return {};
    return JSON.parse(fs.readFileSync(resourcesFile, 'utf8'));
}

module.exports = {
    category: 'bank',
    command: 'مواردي',
    description: '📦 عرض مواردك (ذهب، حديد، خشب، حجر)',
    usage: '.مواردي',
    
    async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
                const chatId = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;
        const senderNumber = sender.split('@')[0];

        const resources = loadResources();
        
        // ✅ تأكد من وجود بيانات المستخدم
        console.log('📂 جميع البيانات:', JSON.stringify(resources, null, 2));
        console.log(`🔍 بيانات ${senderNumber}:`, resources[senderNumber]);
        
        const userRes = resources[senderNumber] || { gold: 0, iron: 0, wood: 0, stone: 0 };

        const message = `📦 *مخزونك من الموارد*\n\n` +
            `⚱️ *الذهب:* ${userRes.gold}\n` +
            `⚙️ *الحديد:* ${userRes.iron}\n` +
            `🪵 *الخشب:* ${userRes.wood}\n` +
            `🧱 *الحجر:* ${userRes.stone}\n\n` +
            `🏴‍☠️ استخدم .كنز للبحث عن الكنز\n` +
            `⛏️ استخدم .منجم للتعدين`;

        await sock.sendMessage(chatId, { text: message }, { quoted: msg });
    }
};