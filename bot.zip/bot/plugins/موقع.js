const fetch = require('node-fetch');

module.exports = {
    command: 'موقع',
    description: '📍 يرسل موقع المكان مباشرة على الخريطة',
    category: 'tools',

    async execute(sock, msg) {

                const from = msg.key.remoteJid;
        
        // حل مشكلة الـ join عبر استخراج النص مباشرة من الرسالة
        const body = msg.message?.conversation || 
                     msg.message?.extendedTextMessage?.text || 
                     msg.message?.imageMessage?.caption || "";
                     
        // استخراج اسم المكان بعد كلمة ".موقع "
        const query = body.split(" ").slice(1).join(" ");

        if (!query) {
            return sock.sendMessage(from, { text: '⚠️ اكتب اسم المكان (مثلاً: .موقع حد السوالم)' }, { quoted: msg });
        }

        try {
            // البحث عن الإحداثيات باستخدام Nominatim
            const searchUrl = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(query)}&format=json&limit=1`;
            
            const response = await fetch(searchUrl, {
                headers: { 'User-Agent': 'ARC-Engine-Bot' }
            });
            const data = await response.json();

            if (!data || data.length === 0) {
                return sock.sendMessage(from, { text: '❌ تعذر العثور على هذا الموقع.' }, { quoted: msg });
            }

            const location = data[0];
            const lat = parseFloat(location.lat);
            const lon = parseFloat(location.lon);

            // إرسال الخريطة الحقيقية
            await sock.sendMessage(from, {
                location: {
                    degreesLatitude: lat,
                    degreesLongitude: lon,
                    name: query, 
                    address: location.display_name 
                }
            }, { quoted: msg });

        } catch (error) {
            console.error("Location Error:", error);
            await sock.sendMessage(from, { text: '❌ حدث خطأ أثناء جلب الموقع.' }, { quoted: msg });
        }
    }
};