const axios = require('axios');

module.exports = {
    command: 'موقع',
    description: '📍 يرسل موقع المكان مباشرة على الخريطة',
    category: 'tools',

    async execute(sock, msg) {

        const from = msg.key.remoteJid;
        
        const body = msg.message?.conversation || 
                     msg.message?.extendedTextMessage?.text || 
                     msg.message?.imageMessage?.caption || "";
                     
        const query = body.split(" ").slice(1).join(" ");

        if (!query) {
            return sock.sendMessage(from, { text: '⚠️ اكتب اسم المكان (مثلاً: .موقع حد السوالم)' }, { quoted: msg });
        }

        try {
            const searchUrl = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(query)}&format=json&limit=1`;
            
            const response = await axios.get(searchUrl, {
                headers: { 'User-Agent': 'ARC-Engine-Bot' },
                timeout: 10000
            });

            const data = response.data;

            if (!data || data.length === 0) {
                return sock.sendMessage(from, { text: '❌ تعذر العثور على هذا الموقع.' }, { quoted: msg });
            }

            const location = data[0];
            const lat = parseFloat(location.lat);
            const lon = parseFloat(location.lon);

            // ✅ إرسال الموقع فقط بدون أي رد نصي
            await sock.sendMessage(from, {
                location: {
                    degreesLatitude: lat,
                    degreesLongitude: lon
                }
            });

        } catch (error) {
            console.error("Location Error:", error.message);
            // ✅ حتى الخطأ ما يظهر كرد
        }
    }
};