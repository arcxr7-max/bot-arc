const config = require('../config');
const fs = require('fs');
const path = require('path');

const pointsFile = path.join(__dirname, '../data/points.json');

function getPoints() {
    if (!fs.existsSync(pointsFile)) return {};
    return JSON.parse(fs.readFileSync(pointsFile, 'utf8'));
}

function savePoints(points) {
    fs.writeFileSync(pointsFile, JSON.stringify(points, null, 2));
}

// دالة تأخير
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// الأرقام المزخرفة
const diceEmojis = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣'];

// قوانين اللعبة
function getGameRules() {
    return `🎲 *لعبة النرد*\n\n💰 استخدم: .نرد [المبلغ]\nمثال: .نرد 100\n\n🎲 *قوانين اللعبة:*\n1️⃣ → تخسر 200 نقطة\n2️⃣ → تخسر 100 نقطة\n3️⃣ → لا ربح ولا خسارة\n4️⃣ → ربح 400 نقطة\n5️⃣ → ربح 500 نقطة\n6️⃣ → ربح 600 نقطة`;
}

module.exports = {
    command: 'نرد',
    description: '🎲 ألقي النرد وجرب حظك',
    usage: '.نرد [المبلغ]',
    category: 'game',

    async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
                const chatId = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;
        const senderNumber = sender.split('@')[0];
        
        // قراءة النص مباشرة
        let fullText = '';
        if (msg.message?.conversation) fullText = msg.message.conversation;
        else if (msg.message?.extendedTextMessage?.text) fullText = msg.message.extendedTextMessage.text;
        else fullText = '';
        
        const withoutCommand = fullText.replace(/^\.نرد\s*/, '').trim();
        let betAmount = parseInt(withoutCommand);
        
        let points = getPoints();
        const currentPoints = points[senderNumber] || 0;
        
        // إذا لم يحدد المبلغ، اعرض القوانين
        if (isNaN(betAmount) || betAmount <= 0) {
            return sock.sendMessage(chatId, {
                text: getGameRules()
            }, { quoted: msg });
        }
        
        if (betAmount < 10) {
            return sock.sendMessage(chatId, { text: '❌ الحد الأدنى 10 نقاط' }, { quoted: msg });
        }
        
        if (betAmount > currentPoints) {
            return sock.sendMessage(chatId, { text: `❌ رصيدك: ${currentPoints} نقطة` }, { quoted: msg });
        }
        
        // 🎬 أنميشن الأرقام المتغيرة
        const animMsg = await sock.sendMessage(chatId, {
            text: `🎲 *الرمية:*\n┗━━ •✦• ━━┛\n${diceEmojis[0]}`
        }, { quoted: msg });
        
        // تغيير الأرقام بشكل عشوائي وسريع
        for (let i = 0; i < 12; i++) {
            const randomEmoji = diceEmojis[Math.floor(Math.random() * diceEmojis.length)];
            await sleep(150);
            
            try {
                await sock.sendMessage(chatId, {
                    text: `🎲 *الرمية:*\n┗━━ •✦• ━━┛\n${randomEmoji}`,
                    edit: animMsg.key
                });
            } catch(e) {}
        }
        
        // النتيجة النهائية
        const dice = Math.floor(Math.random() * 6) + 1;
        const finalEmoji = diceEmojis[dice - 1];
        
        let resultText = '';
        let winAmount = 0;
        
        switch(dice) {
            case 1:
                winAmount = -200;
                resultText = `💀 *خسارة!* 💀\n┗━━ •✦• ━━┛\n> رميت ${finalEmoji} خسرت 200 نقطة`;
                break;
            case 2:
                winAmount = -100;
                resultText = `💀 *خسارة!* 💀\n┗━━ •✦• ━━┛\n> رميت ${finalEmoji} خسرت 100 نقطة`;
                break;
            case 3:
                winAmount = 0;
                resultText = `🎲 *تعادل!* 🎲\n┗━━ •✦• ━━┛\n> رميت ${finalEmoji} لا ربح ولا خسارة`;
                break;
            case 4:
                winAmount = 400;
                resultText = `🎉 *ربح!* 🎉\n┗━━ •✦• ━━┛\n> رميت ${finalEmoji} ربحت 400 نقطة`;
                break;
            case 5:
                winAmount = 500;
                resultText = `🏆 *ربح!* 🏆\n┗━━ •✦• ━━┛\n> رميت ${finalEmoji} ربحت 500 نقطة`;
                break;
            case 6:
                winAmount = 600;
                resultText = `👑 *جاكبوت!* 👑\n┗━━ •✦• ━━┛\n> رميت ${finalEmoji} ربحت 600 نقطة`;
                break;
        }
        
        // تحديث النقاط
        const newBalance = currentPoints + winAmount;
        points[senderNumber] = newBalance;
        savePoints(points);
        
        // تعديل الرسالة النهائية
        try {
            await sock.sendMessage(chatId, {
                text: `🎲 *النتيجة ${finalEmoji}*\n\n${resultText}\n💰 راهنت: ${betAmount}\n📊 الربح: ${winAmount >= 0 ? '+' : ''}${winAmount}\n💰 رصيدك: ${newBalance}`,
                edit: animMsg.key
            });
        } catch(e) {
            await sock.sendMessage(chatId, {
                text: `🎲 *النتيجة ${finalEmoji}*\n\n${resultText}\n💰 راهنت: ${betAmount}\n📊 الربح: ${winAmount >= 0 ? '+' : ''}${winAmount}\n💰 رصيدك: ${newBalance}`
            }, { quoted: msg });
        }
    }
};