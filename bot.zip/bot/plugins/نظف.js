const config = require('../config');
const fs = require('fs');
const path = require('path');

// ========== التحقق من المطور من data/devs.json ==========
function loadDevs() {
    const devsFile = path.join(__dirname, '../data/devs.json');
    if (!fs.existsSync(devsFile)) {
        return [];
    }
    try {
        const data = JSON.parse(fs.readFileSync(devsFile, 'utf8'));
        if (Array.isArray(data)) {
            return data;
        }
        return [];
    } catch (e) {
        return [];
    }
}

function isDev(number) {
    if (!number) return false;
    const cleanNumber = number.toString().split('@')[0];
    const devs = loadDevs();
    return devs.includes(cleanNumber);
}

module.exports = {
    category: 'control',
    command: 'نظف',
    description: '🧹 تشغيل/إيقاف التنظيف التلقائي للملفات المؤقتة',

    async execute(sock, msg) {
        try {
            const chatId = msg.key.remoteJid;
            const senderNum = (msg.key.participant || msg.key.remoteJid).split('@')[0];

            // ✅ التحقق من المطور
            if (!isDev(senderNum)) {
                return sock.sendMessage(chatId, {
                    text: '🚫 هذا الأمر للمطورين فقط.'
                }, { quoted: msg });
            }

            // ✅ إذا كان التنظيف شغال، نطفيه
            if (global.cleanInterval) {
                clearInterval(global.cleanInterval);
                global.cleanInterval = null;
                return sock.sendMessage(chatId, { 
                    text: '🧹 تم إيقاف التنظيف التلقائي ⛔️' 
                }, { quoted: msg });
            }

            // ✅ المجلدات والامتدادات
            const folders = ['temp', 'tmp', 'downloads', 'backups', 'data'];
            const exts = ['.bak', '.js.bak', '.jpg', '.jpeg', '.png', '.gif', '.webp', '.mp4', '.mp3', '.wav', '.ogg', '.zip', '.rar', '.log', '.tmp'];

            const runClean = () => {
                let deletedCount = 0;

                for (const folder of folders) {
                    const folderPath = path.join(process.cwd(), folder);
                    if (!fs.existsSync(folderPath)) continue;

                    try {
                        const files = fs.readdirSync(folderPath);
                        for (const file of files) {
                            const ext = path.extname(file).toLowerCase();
                            if (exts.includes(ext)) {
                                try {
                                    fs.unlinkSync(path.join(folderPath, file));
                                    deletedCount++;
                                    console.log(`🗑️ تم حذف: ${file} من ${folder}`);
                                } catch (e) {}
                            }
                        }
                    } catch (e) {}
                }

                // ✅ تنظيف ملفات الجلسة (الاحتفاظ بآخر 30 ملف)
                const sessionDirs = ['session', 'auth_info_baileys', 'ملف_الاتصال'];
                for (const sDir of sessionDirs) {
                    const sessionDir = path.join(process.cwd(), sDir);
                    if (fs.existsSync(sessionDir)) {
                        try {
                            const files = fs.readdirSync(sessionDir);
                            if (files.length > 30) {
                                files.map(f => ({
                                    name: f,
                                    time: fs.statSync(path.join(sessionDir, f)).mtime.getTime()
                                }))
                                .sort((a, b) => b.time - a.time)
                                .slice(30)
                                .forEach(f => {
                                    try {
                                        fs.unlinkSync(path.join(sessionDir, f.name));
                                    } catch (e) {}
                                });
                            }
                        } catch (e) {}
                    }
                }

                if (deletedCount > 0) {
                    console.log(`🧹 تم حذف ${deletedCount} ملف`);
                }
            };

            // ✅ تشغيل فوري
            runClean();

            // ✅ جدولة كل 10 دقائق
            global.cleanInterval = setInterval(() => {
                runClean();
            }, 10 * 60 * 1000);

            await sock.sendMessage(chatId, { react: { text: '🧹', key: msg.key } });
            await sock.sendMessage(chatId, { 
                text: `🧹 تم تشغيل التنظيف التلقائي ✅\n\n📌 سيتم تنظيف الملفات المؤقتة كل 10 دقائق` 
            }, { quoted: msg });

        } catch (error) {
            console.error('❌ خطأ في أمر نظف:', error);
            await sock.sendMessage(msg.key.remoteJid, {
                text: '❌ حدث خطأ أثناء تنفيذ الأمر'
            }, { quoted: msg });
        }
    }
};