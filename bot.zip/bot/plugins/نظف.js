const config = require('../config');
const fs = require('fs');
const path = require('path');
const { isDev } = require('../utils/devs');

module.exports = {
    category: 'control',
    command: 'نظف',
    description: '🧹 تشغيل/إيقاف التنظيف التلقائي الفوري للملفات المؤقتة',

    async execute(sock, msg) {
        try {
            const chatId = msg.key.remoteJid;
            const senderNum = (msg.key.participant || msg.key.remoteJid).split('@')[0];

            if (!isDev(senderNum)) {
                return sock.sendMessage(chatId, {
                    text: '⚠️ ┋ عذراً، هذا الأمر مخصص للمطور الأساسي فقط!'
                }, { quoted: msg });
            }

            if (global.cleanInterval) {
                clearInterval(global.cleanInterval);
                global.cleanInterval = null;
                return sock.sendMessage(chatId, { text: '🧹 تم إيقاف التنظيف التلقائي للسيرفر بنجاح ⛔️' }, { quoted: msg });
            }

            // المجلدات المخصصة للميديا والمخلفات فقط (تم إبعاد مجلدات الأكواد الحساسة للأمان)
            const folders = ['temp', 'tmp', 'downloads', 'backups', 'data'];
            const exts = ['.bak', '.js.bak', '.jpg', '.jpeg', '.png', '.gif', '.webp', '.mp4', '.mp3', '.wav', '.ogg', '.zip', '.rar', '.log', '.tmp'];

            const runInstantClean = () => {
                let deletedCount = 0;

                // 1. تنظيف مجلدات الميديا والمخلفات
                for (const folder of folders) {
                    const folderPath = path.join(process.cwd(), folder);
                    if (!fs.existsSync(folderPath)) continue;

                    try {
                        const files = fs.readdirSync(folderPath);
                        for (const file of files) {
                            if (exts.includes(path.extname(file).toLowerCase())) {
                                try {
                                    fs.unlinkSync(path.join(folderPath, file));
                                    deletedCount++;
                                } catch (e) {}
                            }
                        }
                    } catch (e) {}
                }

                // 2. تنظيف ملفات الاتصال الذكي (البحث عن أي مجلد يحتوي على ملفات الجلسة الشهيرة)
                const possibleSessionDirs = ['session', 'auth_info_baileys', 'ملف_الاتصال', 'AracenSession'];
                for (const sDir of possibleSessionDirs) {
                    const sessionDir = path.join(process.cwd(), sDir);
                    if (fs.existsSync(sessionDir)) {
                        try {
                            const files = fs.readdirSync(sessionDir);
                            // الحفاظ على آخر 60 ملف اتصال لحماية الجلسة وحذف الباقي الزائد
                            if (files.length > 60) {
                                files.map(f => ({
                                    name: f,
                                    time: fs.statSync(path.join(sessionDir, f)).mtime.getTime()
                                }))
                                .sort((a, b) => b.time - a.time)
                                .slice(60)
                                .forEach(f => {
                                    try {
                                        fs.unlinkSync(path.join(sessionDir, f.name));
                                    } catch (e) {}
                                });
                            }
                        } catch (e) {}
                    }
                }
            };

            // تشغيل فوري عند طلب الأمر
            runInstantClean();

            // جدولة التنظيف كل 10 دقائق
            global.cleanInterval = setInterval(() => {
                runInstantClean();
            }, 10 * 60 * 1000);

            await sock.sendMessage(chatId, { react: { text: '🧹', key: msg.key } });
            await sock.sendMessage(chatId, { text: '🧹 تم تشغيل التنظيف التلقائي الفوري وحماية السيرفر بنجاح ☑️' }, { quoted: msg });

        } catch (error) {
            console.error('❌ خطأ في أمر نظف المطور:', error);
        }
    }
};