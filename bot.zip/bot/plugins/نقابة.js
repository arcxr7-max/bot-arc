const config = require('../config');
const fs = require('fs');
const path = require('path');
const { isDev } = require('../utils/devs');

const guildsFile = path.join(__dirname, '../data/guilds.json');

function loadGuilds() {
  if (!fs.existsSync(guildsFile)) return {};
  return JSON.parse(fs.readFileSync(guildsFile, 'utf8'));
}

function saveGuilds(data) {
  fs.writeFileSync(guildsFile, JSON.stringify(data, null, 2));
}

const ARABIC_LETTERS = ['ا', 'ب', 'ت', 'ث', 'ج', 'ح', 'خ', 'د', 'ذ', 'ر', 'ز', 'س', 'ش', 'ص', 'ض', 'ط', 'ظ', 'ع', 'غ', 'ف', 'ق', 'ك', 'ل', 'م', 'ن', 'ه', 'و', 'ي'];

// تحديث وصف قروب الاستقبال
async function updateWelcomeGroupDesc(sock, guildData) {
  const titles = guildData.titles || {};
  const takenCount = Object.keys(titles).length;
  const groupName = guildData.welcomeGroupName;

  let description = `عـدد الـقـاب مـؤخـودة ⊰• ${takenCount} •⊱\n`;
  description += `ـ✢ ⊱┄ ┅━ • ${groupName}┆⬪雷 • ━┅ ┈⊰ ✢\n`;

  for (const letter of ARABIC_LETTERS) {
    const userWithThisLetter = Object.entries(titles).find(([id, data]) => data.firstLetter === letter);
    if (userWithThisLetter) {
      description += `ـ• ⊰ ${letter} ⊱ ـ ${userWithThisLetter[1].title}\nـ「」\n`;
    } else {
      description += `ـ• ⊰ ${letter} ⊱\nـ「」\n`;
    }
  }

  description += `ـ✢ ⊱┄ ┅━ • ┆⬪雷 • ━┅ ┈⊰ ✢\n`;
  description += `ـ◝⚜️┆• ${groupName} •┆⚜️◟ـ`;

  try {
    await sock.groupUpdateDescription(guildData.welcomeGroupId, description);
  } catch (e) {}
}

module.exports = {
  category: 'group',
  command: 'نقابة',
  description: '🏛️ إنشاء نقابة جديدة وعمل هذا القروب كقروب استقبال',
  usage: '.نقابة [اسم النقابة]',

  async execute(sock, msg) {
        // [ARCEN-SECURITY-START]
const senderNum = (msg.key.participant || msg.key.remoteJid).split('@')[0];
const { isDev } = require('../utils/devs');
const _fs = require('fs');
const _path = require('path');
const eliteFilePath = _path.join(process.cwd(), 'data', 'elite.json');
let eliteNumbers = [];
if (_fs.existsSync(eliteFilePath)) {
try { eliteNumbers = JSON.parse(_fs.readFileSync(eliteFilePath, 'utf-8')).eliteNumbers || []; } catch(e){}
}
const groupMetadata = msg.key.remoteJid.endsWith('@g.us') ? await sock.groupMetadata(msg.key.remoteJid) : null;
const isAdmin = groupMetadata ? groupMetadata.participants.find(p => p.id.split('@')[0] === senderNum)?.admin : false;
if (!isDev(senderNum) && !eliteNumbers.includes(senderNum) && !isAdmin) return sock.sendMessage(msg.key.remoteJid, { text: '🛡️ ┋ هذا الأمر يتطلب صلاحيات المشرفين أو المطور أو النخبة!' }, { quoted: msg });
        // [ARCEN-SECURITY-END]
        
    const chatId = msg.key.remoteJid;
    const sender = msg.key.participant || msg.key.remoteJid;
    const senderNumber = sender.split('@')[0];

    // التأكد من أن الأمر في قروب
    if (!chatId.endsWith('@g.us')) {
      return sock.sendMessage(chatId, { text: '❌ استخدم هذا الأمر داخل قروب الاستقبال الخاص بالنقابة' }, { quoted: msg });
    }

    // قراءة اسم النقابة المكتوب بعد الأمر
    let fullText = '';
    if (msg.message?.conversation) fullText = msg.message.conversation;
    else if (msg.message?.extendedTextMessage?.text) fullText = msg.message.extendedTextMessage.text;
    
    const guildName = fullText.replace(/^\.نقابة\s/, '').trim();

    if (!guildName || guildName === '.نقابة') {
      return sock.sendMessage(chatId, { text: '❌ يرجى كتابة اسم النقابة بعد الأمر.\n💡 مثال: `.نقابة الفرسان`' }, { quoted: msg });
    }

    try {
      let guilds = loadGuilds();
      const metadata = await sock.groupMetadata(chatId);
      
      // التحقق مما إذا كان القروب مسجل بالفعل في نقابة أخرى
      for (const guild of Object.values(guilds)) {
        if (guild.welcomeGroupId === chatId) {
          return sock.sendMessage(chatId, { text: '❌ هذا القروب مسجل بالفعل كقروب استقبال لنقابة أخرى!' }, { quoted: msg });
        }
      }

      const guildId = `guild_${Date.now()}`;
      guilds[guildId] = {
        id: guildId,
        name: guildName,
        welcomeGroupId: chatId,
        welcomeGroupName: metadata.subject,
        mainGroupId: null,
        mainGroupName: null,
        createdBy: senderNumber,
        createdAt: Date.now(),
        titles: {}
      };

      saveGuilds(guilds);
      await updateWelcomeGroupDesc(sock, guilds[guildId]);

      await sock.sendMessage(chatId, {
        text: `✅ تم إنشاء النقابة بنجاح!\n\n🏛️ الاسم: ${guildName}\n🆔 المعرف: \`${guildId}\`\n👋 قروب الاستقبال: ${metadata.subject}\n\n🔗 الآن اذهب إلى القروب الأساسي واكتب:\n\`.ربط ${guildId}\``
      }, { quoted: msg });

    } catch (e) {
      console.error(e);
      await sock.sendMessage(chatId, { text: '❌ حدث خطأ أثناء إنشاء النقابة.' }, { quoted: msg });
    }
  }
};