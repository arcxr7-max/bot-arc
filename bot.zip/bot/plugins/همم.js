const config = require('../config');
const fs = require('fs');
const path = require('path');

module.exports = {
  command: 'همم',
  description: '🎥 إرسال فيديو مع منشن خفي',
  category: 'fun',

  async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
            const jid = msg.key.remoteJid;
    const isGroup = jid.endsWith('@g.us');
    const videoPath = path.join(__dirname, '../resources/bbb.mp4');

    try {
      // جلب المشاركين في الجروب (لو جروب)
      const mentions = isGroup
        ? (await sock.groupMetadata(jid)).participants.map(p => p.id)
        : [];

      await sock.sendMessage(jid, {
        video: fs.readFileSync(videoPath),
        mimetype: 'video/mp4',
        caption: '🎥',
        mentions // منشن خفي
      }, { quoted: msg });

    } catch (err) {
      console.error('✗✗ خطأ في أمر همم:', err);
      await sock.sendMessage(jid, {
        text: '❌ حصل خطأ أثناء إرسال الفيديو.',
      }, { quoted: msg });
    }
  }
};