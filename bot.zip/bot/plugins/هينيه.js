const config = require('../config');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

const insultsFile = path.join(__dirname, '../data/insults.json');

// ========== تحميل السبات من GitHub ==========
async function loadInsultsFromGitHub() {
    try {
        const response = await axios.get('https://raw.githubusercontent.com/arcxr7-max/ARC/refs/heads/main/insults.json');
        if (response.status === 200 && Array.isArray(response.data)) {
            fs.writeFileSync(insultsFile, JSON.stringify(response.data, null, 2));
            console.log('✅ تم تحميل السبات من GitHub');
            return response.data;
        }
        throw new Error('تنسيق غير صحيح');
    } catch (error) {
        console.log('❌ فشل التحميل من GitHub، نستخدم الملف المحلي');
        return loadInsultsFromLocal();
    }
}

// ========== تحميل من الملف المحلي ==========
function loadInsultsFromLocal() {
    if (fs.existsSync(insultsFile)) {
        try {
            const data = JSON.parse(fs.readFileSync(insultsFile, 'utf8'));
            if (Array.isArray(data) && data.length > 0) {
                return data;
            }
        } catch (e) {}
    }
    return [];
}

// ========== المتغيرات ==========
let insultsCache = [];
let lastSync = 0;

// ========== جلب السبات ==========
async function getInsults(forceRefresh = false) {
    const now = Date.now();
    
    if (forceRefresh || (now - lastSync > 300000)) {
        insultsCache = await loadInsultsFromGitHub();
        lastSync = now;
    }
    
    if (insultsCache.length === 0) {
        insultsCache = loadInsultsFromLocal();
    }
    
    return insultsCache;
}

// ========== الأمر ==========
module.exports = {
    command: 'هينه',
    description: '😈 إرسال إهانة عشوائية لشخص تم الرد على رسالته أو منشنته.',
    usage: '.هينيه [منشن أو رد على رسالة]',
    category: 'fun',

    async execute(sock, msg) {
        try {
            // تفاعل
            await sock.sendMessage(msg.key.remoteJid, { react: { text: '😈', key: msg.key } });

            const insults = await getInsults();
            
            if (insults.length === 0) {
                return sock.sendMessage(msg.key.remoteJid, {
                    text: '❌ لا توجد سبات متاحة حالياً'
                }, { quoted: msg });
            }

            let targetJid = null;
            let quotedMessageId = null;

            // التحقق من الرد على رسالة
            if (msg.message.extendedTextMessage && msg.message.extendedTextMessage.contextInfo && msg.message.extendedTextMessage.contextInfo.quotedMessage) {
                targetJid = msg.message.extendedTextMessage.contextInfo.participant;
                quotedMessageId = msg.message.extendedTextMessage.contextInfo.stanzaId;
            } 
            // التحقق من المنشن
            else if (msg.message.extendedTextMessage && msg.message.extendedTextMessage.contextInfo && msg.message.extendedTextMessage.contextInfo.mentionedJid && msg.message.extendedTextMessage.contextInfo.mentionedJid.length > 0) {
                targetJid = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];
            } else {
                await sock.sendMessage(
                    msg.key.remoteJid,
                    { text: `❌ يجب عليك الرد على رسالة شخص أو منشنته لاستخدام أمر *هينه*.` },
                    { quoted: msg }
                );
                return;
            }

            if (!targetJid) {
                await sock.sendMessage(
                    msg.key.remoteJid,
                    { text: `❌ لم أتمكن من تحديد الشخص المستهدف. تأكد من أنك ترد على رسالة أو تمنشن شخصًا.` },
                    { quoted: msg }
                );
                return;
            }

            // اختيار سب عشوائي
            const randomInsult = insults[Math.floor(Math.random() * insults.length)];

            // إرسال السب
            if (quotedMessageId) {
                await sock.sendMessage(
                    msg.key.remoteJid,
                    { text: `${randomInsult}` },
                    { quoted: {
                        key: {
                            remoteJid: msg.key.remoteJid,
                            id: quotedMessageId,
                            participant: targetJid
                        },
                        message: {
                            conversation: "Original Message"
                        }
                    }}
                );
            } else {
                await sock.sendMessage(
                    msg.key.remoteJid,
                    { 
                        text: `@${targetJid.split('@')[0]} ${randomInsult}`,
                        mentions: [targetJid]
                    },
                    { quoted: msg }
                );
            }

        } catch (error) {
            console.error('❌ خطأ في تنفيذ أمر "هينيه":', error);
            await sock.sendMessage(msg.key.remoteJid, {
                text: `❌ حدث خطأ أثناء تنفيذ الأمر`
            }, { quoted: msg });
        }
    }
};