const config = require('../config');
const fs = require('fs');
const path = require('path');

module.exports = {
    command: 'هينه',
    description: 'إرسال إهانة عشوائية لشخص تم الرد على رسالته أو منشنته.',
    usage: '.هينيه [منشن أو رد على رسالة]',
    category: 'fun',

    async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
                try {
            // Add this line to make the bot react with 🫦
            await sock.sendMessage(msg.key.remoteJid, { react: { text: '🫦', key: msg.key } });

            const insults = [
                "طيزك أكبر من مايا خليفة.",
                "شكلك جزمة مبلولة.",
                "ريحتك زي قفص قرود.",
                "مخك قد حبة الفول.",
                "انت أهبل من بقرة بتتسوق.",
                "كلامك زي صوت الحمير.",
                "وشك كانه خريطة طرق.",
                "وجودك بيسبب لي صداع.",
                "يا عرة البشر.",
                "انت غلطة في تاريخ البشرية.",
                "شكلك بيقول انك اتولدت في زبالة.",
                "عقلك ده مقاسه صغير جداً.",
                "انت مالكش لازمة زي الزرار في البنطلون القديم.",
                "صوتك بيجيب لي مغص.",
                "حياتك كلها غلط في غلط."
            ];

            let targetJid = null;
            let quotedMessageId = null;

            // Check if the command is a reply to a message
            if (msg.message.extendedTextMessage && msg.message.extendedTextMessage.contextInfo && msg.message.extendedTextMessage.contextInfo.quotedMessage) {
                targetJid = msg.message.extendedTextMessage.contextInfo.participant;
                quotedMessageId = msg.message.extendedTextMessage.contextInfo.stanzaId; // Get the ID of the quoted message
            } 
            // Check if a mention is used
            else if (msg.message.extendedTextMessage && msg.message.extendedTextMessage.contextInfo && msg.message.extendedTextMessage.contextInfo.mentionedJid && msg.message.extendedTextMessage.contextInfo.mentionedJid.length > 0) {
                targetJid = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];
            } else {
                await sock.sendMessage(
                    msg.key.remoteJid,
                    { text: `❌ يجب عليك الرد على رسالة شخص أو منشنته لاستخدام أمر *${this.command}*.` },
                    { quoted: msg }
                );
                return;
            }

            if (!targetJid) {
                await sock.sendMessage(
                    msg.key.remoteJid,
                    { text: `❌ لم أتمكن من تحديد الشخص المستهدف. تأكد من أنك ترد على رسالة أو تمنشن شخصًا.` },
                    { quoted: msg }
                );
                return;
            }

            // Select a random insult
            const randomInsult = insults[Math.floor(Math.random() * insults.length)];

            // Send the insult as a reply to the target's message if it was a reply,
            // otherwise, send it as a regular message mentioning the target.
            if (quotedMessageId) {
                // If it was a reply, the bot should reply to the *same* message that the user replied to.
                await sock.sendMessage(
                    msg.key.remoteJid,
                    { text: `${randomInsult}` },
                    { quoted: {
                        key: {
                            remoteJid: msg.key.remoteJid,
                            id: quotedMessageId,
                            participant: targetJid
                        },
                        message: {
                            conversation: "Original Message" // Placeholder, actual content isn't needed for quoting
                        }
                    }}
                );
            } else {
                await sock.sendMessage(
                    msg.key.remoteJid,
                    { 
                        text: `@${targetJid.split('@')[0]} ${randomInsult}`,
                        mentions: [targetJid]
                    },
                    { quoted: msg } // Quote the user's command message
                );
            }

        } catch (error) {
            console.error('❌ خطأ في تنفيذ أمر "هينيه":', error);
            await sock.sendMessage(msg.key.remoteJid, {
                text: `❌ حدث خطأ أثناء تنفيذ الأمر: ${error.message || error.toString()}`
            }, { quoted: msg });
        }
    }
};