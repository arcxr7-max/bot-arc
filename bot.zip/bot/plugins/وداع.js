const farewelledParticipants = new Set();
let farewellActive = false;

module.exports = {
  command: 'وداع',
  description: 'يرسل وداعًا عند مغادرة أحد الأعضاء للمجموعة.',
  category: 'group',

  async execute(sock, msg) {

            const groupId = msg.key.remoteJid;

    if (!farewellActive) {
      farewellActive = true;
      await sock.sendMessage(groupId, {
        text: '✅ تم تفعيل الوداع عند مغادرة الأعضاء.\n- اكتب "قفل الوداع" لتعطيله.'
      });

      // مستمع لخروج الأعضاء
      sock.ev.on('group-participants.update', async (update) => {
        if (!farewellActive || update.id !== groupId || update.action !== 'remove') return;

        const groupMetadata = await sock.groupMetadata(groupId);
        for (const participant of update.participants) {
          if (farewelledParticipants.has(participant)) continue;

          let ppUrl = await sock.profilePictureUrl(participant, 'image').catch(() => null);
          if (!ppUrl) {
            ppUrl = await sock.profilePictureUrl(groupId, 'image').catch(() => null);
          }

          const farewellMessage = `
*❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜*
❒ *╭┈⊰* 💔 الـــوداع 💔 *⊰┈ ✦*
*┊˹😔˼┊ وداعاً*
┊˹👤˼┊ @${participant.split('@')[0]}
┊📤 *نتمنى لك التوفيق*

> خرج من الجروب ┊˹🚪˼┊*
*❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜*
>  𝗔𝗥𝗖𝗘𝗡 🪶
`;

          const media = ppUrl
            ? { image: { url: ppUrl }, caption: farewellMessage }
            : { text: farewellMessage };

          await sock.sendMessage(groupId, {
            ...media,
            mentions: [participant]
          });

          farewelledParticipants.add(participant);
          setTimeout(() => farewelledParticipants.delete(participant), 60000);
        }
      });

      // مستمع للرسائل داخل الجروب لإيقاف الوداع
      sock.ev.on('messages.upsert', async ({ messages }) => {
        const message = messages[0];
        if (!message || !message.message || message.key.remoteJid !== groupId) return;

        const body = message.message?.conversation || message.message?.extendedTextMessage?.text || '';
        if (body.toLowerCase() === 'قفل الوداع') {
          farewellActive = false;
          farewelledParticipants.clear();
          await sock.sendMessage(groupId, { text: '⛔ تم تعطيل الوداع عند مغادرة الأعضاء.' });
        }
      });
    }
  }
};