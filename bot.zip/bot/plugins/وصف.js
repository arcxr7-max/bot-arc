const config = require('../config');
const { eliteNumbers } = require('../haykala/elite.js');

module.exports = {
  command: ['وصف'],
  description: 'تغيير وصف الجروب (للنخبة فقط).',
  category: 'tools',

  async execute(sock, msg, args = []) {
    try {
      // التحقق من النخبة
      const sender = msg.key.participant || msg.key.remoteJid;
      const senderNumber = sender.split('@')[0];

      if (!eliteNumbers.includes(senderNumber)) {
        return await sock.sendMessage(msg.key.remoteJid, {
          text: '❌ هذا الأمر مخصص للنخبة فقط.',
        }, { quoted: msg });
      }

      // التحقق من أن الرسالة داخل مجموعة
      if (!msg.key.remoteJid.endsWith('@g.us')) {
        return await sock.sendMessage(msg.key.remoteJid, {
          text: '🚫 هذا الأمر يعمل داخل المجموعات فقط.',
        }, { quoted: msg });
      }

      // قراءة النص
      const fullText =
        msg.message?.conversation ||
        msg.message?.extendedTextMessage?.text ||
        '';

      // محاولة قراءة الوصف من الرد
      const quotedMessage = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      let newDescription = '';

      if (quotedMessage?.conversation) {
        newDescription = quotedMessage.conversation.trim();
      } else if (quotedMessage?.extendedTextMessage?.text) {
        newDescription = quotedMessage.extendedTextMessage.text.trim();
      }

      // إذا لم يتم الرد، نأخذ الوصف من النص
      if (!newDescription && fullText) {
        const parts = fullText.trim().split(/\s+/);
        if (parts.length > 1) {
          newDescription = parts.slice(1).join(' ');
        }
      }

      if (!newDescription) {
        return await sock.sendMessage(msg.key.remoteJid, {
          text: '⚠️ يرجى الرد على رسالة أو كتابة الوصف الجديد بعد الأمر.',
        }, { quoted: msg });
      }

      // تحديث الوصف
      await sock.groupUpdateDescription(msg.key.remoteJid, newDescription);

      // ✅ تفاعل فقط
      await sock.sendMessage(msg.key.remoteJid, {
        react: { text: '✅', key: msg.key }
      });

    } catch (error) {
      console.error('❌ خطأ في أمر تغيير الوصف:', error);
      
      await sock.sendMessage(msg.key.remoteJid, {
        react: { text: '❌', key: msg.key }
      });
    }
  }
};