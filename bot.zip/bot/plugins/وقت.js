module.exports = {
    command: 'وقت',
    description: '⏰ عرض الوقت الحالي في أي مدينة',
    usage: '.وقت [اسم المدينة]',
    category: 'tools',

    async execute(sock, msg) {

                const chatId = msg.key.remoteJid;

        // قراءة النص مباشرة
        let fullText = '';
        if (msg.message?.conversation) fullText = msg.message.conversation;
        else if (msg.message?.extendedTextMessage?.text) fullText = msg.message.extendedTextMessage.text;
        else fullText = '';

        const city = fullText.replace(/^\.وقت\s*/, '').trim();

        if (!city) {
            // عرض الوقت الحالي للبوت إذا لم يحدد مدينة
            const now = new Date();
            const hours = now.getHours().toString().padStart(2, '0');
            const minutes = now.getMinutes().toString().padStart(2, '0');
            const seconds = now.getSeconds().toString().padStart(2, '0');
            
            const weekdays = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
            const months = ['يناير', 'فبراير', 'مارس', 'أبريل', 'ماي', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
            
            const message = `🕐 *الوقت الحالي*\n\n📅 ${weekdays[now.getDay()]}، ${now.getDate()} ${months[now.getMonth()]} ${now.getFullYear()}\n⏰ ${hours}:${minutes}:${seconds}\n\n📍 استخدم .وقت [اسم المدينة] لمعرفة وقت مدينة أخرى`;
            
            return sock.sendMessage(chatId, { text: message });
        }

        try {
            // استخدام API لجلب الوقت حسب المدينة
            const searchUrl = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1&language=ar&format=json`;
            const geoResponse = await fetch(searchUrl);
            const geoData = await geoResponse.json();

            if (!geoData.results || geoData.results.length === 0) {
                // إذا لم يتم العثور على المدينة
                const now = new Date();
                const hours = now.getHours().toString().padStart(2, '0');
                const minutes = now.getMinutes().toString().padStart(2, '0');
                const seconds = now.getSeconds().toString().padStart(2, '0');
                const weekdays = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
                const months = ['يناير', 'فبراير', 'مارس', 'أبريل', 'ماي', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
                
                return sock.sendMessage(chatId, { 
                    text: `❌ لم يتم العثور على مدينة "${city}"\n\n🕐 الوقت الحالي للبوت:\n📅 ${weekdays[now.getDay()]}، ${now.getDate()} ${months[now.getMonth()]} ${now.getFullYear()}\n⏰ ${hours}:${minutes}:${seconds}` 
                });
            }

            const location = geoData.results[0];
            const timezone = location.timezone;
            
            // جلب الوقت حسب المنطقة الزمنية
            const timeResponse = await fetch(`https://timeapi.io/api/TimeZone/zone?timeZone=${encodeURIComponent(timezone)}`);
            const timeData = await timeResponse.json();
            
            const datetime = new Date(timeData.currentLocalTime);
            
            const hours = datetime.getHours().toString().padStart(2, '0');
            const minutes = datetime.getMinutes().toString().padStart(2, '0');
            const seconds = datetime.getSeconds().toString().padStart(2, '0');
            
            const weekdays = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
            const months = ['يناير', 'فبراير', 'مارس', 'أبريل', 'ماي', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
            
            const weekday = weekdays[datetime.getDay()];
            const day = datetime.getDate();
            const month = months[datetime.getMonth()];
            const year = datetime.getFullYear();
            
            // اسم المدينة بالعربي أو الأصلي
            const cityName = location.name;
            const country = location.country;
            
            const message = `🕐 *الوقت في ${cityName}، ${country}*\n\n` +
                `📅 ${weekday}، ${day} ${month} ${year}\n` +
                `⏰ ${hours}:${minutes}:${seconds}\n` +
                `🌐 المنطقة: ${timezone}`;
            
            await sock.sendMessage(chatId, { text: message });
            
        } catch (error) {
            console.error('خطأ:', error);
            const now = new Date();
            const hours = now.getHours().toString().padStart(2, '0');
            const minutes = now.getMinutes().toString().padStart(2, '0');
            const seconds = now.getSeconds().toString().padStart(2, '0');
            const weekdays = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
            const months = ['يناير', 'فبراير', 'مارس', 'أبريل', 'ماي', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
            
            await sock.sendMessage(chatId, {
                text: `⚠️ حدث خطأ في جلب الوقت\n\n🕐 الوقت الحالي للبوت:\n📅 ${weekdays[now.getDay()]}، ${now.getDate()} ${months[now.getMonth()]} ${now.getFullYear()}\n⏰ ${hours}:${minutes}:${seconds}`
            });
        }
    }
};