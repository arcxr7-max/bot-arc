const config = require('../config');
module.exports = {
  command: ["يحبني"],
  description: "💘 يختار شخص بيحبك سراً في الجروب",
  usage: ".يحبني",

  async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
            const from = msg.key.remoteJid;

    if (!from.endsWith('@g.us')) {
      return sock.sendMessage(from, {
        text: "❌ هذا الأمر يعمل فقط في الجروبات."
      }, { quoted: msg });
    }

    try {
      const group = await sock.groupMetadata(from);
      const participants = group.participants.filter(p => p.id !== msg.sender);
      
      if (participants.length === 0) {
        return sock.sendMessage(from, {
          text: "❗ مفيش أعضاء تانيين."
        }, { quoted: msg });
      }

      // اختيار شخص عشوائي
      const chosen = participants[Math.floor(Math.random() * participants.length)];
      
      // استخراج الرقم فقط من الـ id (مثال: 1234567890@s.whatsapp.net يصبح 1234567890)
      const chosenNumber = chosen.id.split('@')[0];

      await sock.sendMessage(from, {
        text: `💘 @${chosenNumber} يحبك سراً! 🤫`,
        mentions: [chosen.id] // المنشن ضروري ليظهر الرقم كرابط قابل للضغط
      }, { quoted: msg });

    } catch (err) {
      await sock.sendMessage(from, {
        text: "⚠️ حصل خطأ."
      }, { quoted: msg });
    }
  }
};