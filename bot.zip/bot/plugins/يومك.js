const config = require('../config');
const fs = require('fs');
const path = require('path');

const pointsFile = path.join(__dirname, '../data/points.json');
const dailyFile = path.join(__dirname, '../data/daily.json');

function getPoints() {
    if (!fs.existsSync(pointsFile)) return {};
    return JSON.parse(fs.readFileSync(pointsFile, 'utf8'));
}

function savePoints(points) {
    fs.writeFileSync(pointsFile, JSON.stringify(points, null, 2));
}

function getDaily() {
    if (!fs.existsSync(dailyFile)) return {};
    return JSON.parse(fs.readFileSync(dailyFile, 'utf8'));
}

function saveDaily(data) {
    fs.writeFileSync(dailyFile, JSON.stringify(data, null, 2));
}

// مكافآت السلسلة اليومية (Streak)
function getStreakReward(day) {
    if (day >= 30) return 5000;
    if (day >= 15) return 2000;
    if (day >= 7) return 1000;
    if (day >= 3) return 500;
    return 0;
}

module.exports = {
    category: 'bank',
        command: 'يومي',
    description: '📅 احصل على مكافأتك اليومية',
    usage: '.يومي',
    
    async execute(sock, msg) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
                const chatId = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;
        const senderNumber = sender.split('@')[0];

        let daily = getDaily();
        let points = getPoints();
        const today = new Date().toDateString();

        // التحقق من أنه حصل على المكافأة اليوم
        if (daily[senderNumber] && daily[senderNumber].lastClaim === today) {
            return sock.sendMessage(chatId, {
                text: `⚠️ *لقد حصلت على مكافأتك اليوم بالفعل!*\n\n🔥 السلسلة الحالية: ${daily[senderNumber].streak || 1} يوم\n⏳ عاود غداً.`
            }, { quoted: msg });
        }

        // حساب السلسلة
        let streak = daily[senderNumber]?.streak || 0;
        const lastDate = daily[senderNumber]?.lastClaim;
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);

        if (lastDate === yesterday.toDateString()) {
            streak++;
        } else {
            streak = 1;
        }

        const baseReward = 100;
        const streakBonus = getStreakReward(streak);
        const totalReward = baseReward + streakBonus;

        // تحديث النقاط
        points[senderNumber] = (points[senderNumber] || 0) + totalReward;
        savePoints(points);

        // تحديث بيانات اليومية
        daily[senderNumber] = {
            lastClaim: today,
            streak: streak
        };
        saveDaily(daily);

        // بناء الرسالة
        let message = `📅 *المكافأة اليومية*\n\n💰 حصلت على: *+${totalReward}* نقطة\n🔥 السلسلة: *${streak}* يوم`;
        
        if (streakBonus > 0) {
            message += `\n🎁 مكافأة السلسلة: *+${streakBonus}* نقطة`;
        }
        
        message += `\n\n💰 رصيدك الحالي: *${points[senderNumber]}* نقطة`;

        await sock.sendMessage(chatId, { text: message }, { quoted: msg });
    }
};