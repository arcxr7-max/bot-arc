// استيراد مكتبة chalk للتلوين المباشر
const chalk = require('chalk');

// كائن يحتوي على دوال تسجيل الرسائل المختلفة
const logger = {
    // تسجيل رسائل النجاح باللون الأخضر
    success(message) {
        console.log(chalk.green('✓ ' + message));
    },
    
    // تسجيل رسائل الخطأ باللون الأحمر
    error(message, error = '') {
        console.error(chalk.red('✗ ' + message + (error ? ': ' + error : '')));
    },
    
    // تسجيل رسائل المعلومات باللون الأزرق السماوي (Cyan)
    info(message) {
        console.info(chalk.cyan('ℹ ' + message));
    },
    
    // تسجيل رسائل التحذير باللون الأصفر
    warn(message) {
        console.warn(chalk.yellow('⚠ ' + message));
    }
};

// تصدير الكائن logger
module.exports = logger;
