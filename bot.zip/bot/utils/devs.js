// utils/devs.js
const fs = require('fs');
const path = require('path');

const devsFile = path.join(__dirname, '../data/devs.json');

// قائمة المطورين الافتراضية
const defaultDevs = [
  "212612969896",
  "270527776174265",
  "212777634520",
  "59271169474674"
];

function loadDevs() {
    const dataDir = path.join(__dirname, '../data');
    if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
    }

    if (!fs.existsSync(devsFile)) {
        fs.writeFileSync(devsFile, JSON.stringify(defaultDevs, null, 2));
        return defaultDevs;
    }
    try {
        const data = JSON.parse(fs.readFileSync(devsFile, 'utf8'));
        if (Array.isArray(data)) {
            return data;
        }
        return defaultDevs;
    } catch (e) {
        return defaultDevs;
    }
}

function saveDevs(devs) {
    try {
        fs.writeFileSync(devsFile, JSON.stringify(devs, null, 2));
        return true;
    } catch (e) {
        console.error('❌ خطأ في حفظ المطورين:', e);
        return false;
    }
}

function isDev(number) {
    if (!number) return false;
    const cleanNumber = number.toString().split('@')[0];
    const devs = loadDevs();
    return devs.includes(cleanNumber);
}

function addDev(number) {
    if (!number) return false;
    const cleanNumber = number.toString().split('@')[0];
    const devs = loadDevs();
    if (devs.includes(cleanNumber)) return false;
    devs.push(cleanNumber);
    return saveDevs(devs);
}

function removeDev(number) {
    if (!number) return false;
    const cleanNumber = number.toString().split('@')[0];
    const devs = loadDevs();
    if (!devs.includes(cleanNumber)) return false;
    const newDevs = devs.filter(num => num !== cleanNumber);
    return saveDevs(newDevs);
}

function getDevs() {
    return loadDevs();
}

module.exports = { 
    loadDevs, 
    isDev, 
    addDev, 
    removeDev, 
    getDevs,
    saveDevs
};