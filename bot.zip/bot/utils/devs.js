const fs = require('fs');
const path = require('path');

const devsFile = path.join(__dirname, '../data/devs.json');

// قائمة المطورين الافتراضية
const defaultDevs = [
 "212612969896",
  "270527776174265"
];

function loadDevs() {
    if (!fs.existsSync(devsFile)) {
        fs.writeFileSync(devsFile, JSON.stringify(defaultDevs, null, 2));
        return defaultDevs;
    }
    return JSON.parse(fs.readFileSync(devsFile, 'utf8'));
}

function isDev(number) {
    const cleanNumber = number.toString().split('@')[0];
    const devs = loadDevs();
    return devs.includes(cleanNumber);
}

module.exports = { loadDevs, isDev };